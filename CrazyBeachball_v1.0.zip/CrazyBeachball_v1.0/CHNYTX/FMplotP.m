function FMplotP(AZ,IH,X0,Y0,R0,IP)
% fprintf('%f\n',AZ(1))
NN = length(AZ);
RAD = pi / 180;
AZP = RAD * AZ; 
IHP = RAD * IH;
rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xp=X0+rp.*sin(AZP); 
yp=Y0+rp.*cos(AZP);

if nargin < 6
    scatter(xp,yp);
else
%     % define color and symbol style
%     color_style1 = 'k';
%     color_style2 = 'k';
%     symbol_style1 = '+';
%     symbol_style2 = 'o';    
    for i = 1:NN
        if IP(i) < 0 
            symbol_style = 'o';
        else
            symbol_style = '+';
        end
        
        IPabs = abs(IP(i));
        msize = 10;
        if IPabs == 1 || IPabs == 2 || IPabs == 5 || IPabs == 9
            msize = 20;            
        end
        
        color_style = 'k';
        if IPabs == 9
            color_style = 'b';
        end
        
        scatter(xp(i),yp(i),msize,'MarkerEdgeColor',color_style,'Marker',symbol_style);  
        
%         if IP(i) > 0 && IP(i) <10
% %             scatter(xp(i),yp(i),60,color_style1,symbol_style1,'filled');
%             scatter(xp(i),yp(i),20,'MarkerEdgeColor',color_style1,'Marker',symbol_style1);           
% %             plot([xp(i)-R0/20 xp(i)+R0/20],[yp(i) yp(i)],color_style1,'Linewidth',2);
% %             plot([xp(i) xp(i)],[yp(i)-R0/20 yp(i)+R0/20],color_style1,'Linewidth',2);
%         elseif IP(i) > 10
%             scatter(xp(i),yp(i),10,'MarkerEdgeColor',color_style1,'Marker',symbol_style1);
% %             plot([xp(i)-R0/40 xp(i)+R0/40],[yp(i) yp(i)],color_style1,'Linewidth',2);
% %             plot([xp(i) xp(i)],[yp(i)-R0/40 yp(i)+R0/40],color_style1,'Linewidth',2);
%         elseif IP(i) < 0 && IP(i) > -10
%             scatter(xp(i),yp(i),20,'MarkerEdgeColor',color_style2,'Marker',symbol_style2);
% %             plot([xp(i)-R0/20 xp(i)+R0/20],[yp(i) yp(i)],color_style2,'Linewidth',2);            
%         elseif IP(i) < -10
%             scatter(xp(i),yp(i),10,'MarkerEdgeColor',color_style2,'Marker',symbol_style2); 
% %             plot([xp(i)-R0/40 xp(i)+R0/40],[yp(i) yp(i)],color_style2,'Linewidth',2);
%         else
%         end
    end
end
end