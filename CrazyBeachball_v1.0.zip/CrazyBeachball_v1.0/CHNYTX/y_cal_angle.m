function y_cal_angle
% calculate angle between two vectors


path(path,genpath('/scratch1/yucq-MIT/research/Matlab_codes/seizmo-master/'));

% %% subevent 1
% % rupture direction
% az0 = 205;
% pl0 = -26;
% % nodal plane 1
% [strike1 dip1 rake1] = deal(139, 31, -160);
% [strike2 dip2 rake2] = auxplane(strike1,dip1,rake1);


%% subevent 2
% rupture direction
az0 = 300;
pl0 = 36;
% nodal plane 1
% [strike1 dip1 rake1] = deal(148, 9, -144);
[strike1 dip1 rake1] = deal(147, 26, -147);
[strike2 dip2 rake2] = auxplane(strike1,dip1,rake1);


%%
% calculate plane normal
az1 = strike1 + 90;
pl1 = 90-dip1;
az2 = strike2 + 90;
pl2 = 90-dip2;

% angle between plane normal and rupture direction
% North: x; East: y; Down: z
vec0 = [cosd(pl0)*cosd(az0) cosd(pl0)*sind(az0) -sind(pl0)];
vec1 = [cosd(pl1)*cosd(az1) cosd(pl1)*sind(az1) -sind(pl1)];
vec2 = [cosd(pl2)*cosd(az2) cosd(pl2)*sind(az2) -sind(pl2)];

angle1 = abs(90 - acosd(dot(vec0,vec1)));
angle2 = abs(90 - acosd(dot(vec0,vec2)));

end