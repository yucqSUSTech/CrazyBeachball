function [ G ] = y_radiationpattern( strike, dip, rake, gamma, sigma, EAz, Eih, Wmode )

% Calculate theoretical radition pattern.
% INPUT
% strike, dip, rake: fault plane parameters
% gamma: tensile angle in degrees (0 degrees for pure shear faulting,
%             90 degrees for pure tensile opening).
% sigma: Poisson's ratio
% EAz: Azimuth
% Eih: Take-off angle
% IP: Polarities
% Wmode: Wave mode ('P', 'S', 'SH', or 'SV')
%
% OUTPUT
% P: Theoretical polarities
% 
% This radiation pattern code is modified from the 'rpgen.m' by Grzegorz Kwiatek
%
% Chunquan Yu, 04/13/2015

r2d = 180/pi;

strike = strike / r2d;
dip = dip / r2d;
rake = rake / r2d;
gamma = gamma / r2d;
EAz = EAz / r2d;
Eih = Eih / r2d;

switch upper(Wmode)
    case 'P'
        G = cos(Eih).*(cos(Eih).*(sin(gamma).*(2.*cos(dip).^2 - (2.*sigma)./(2.*sigma - 1)) + sin(2.*dip).*cos(gamma).*sin(rake)) - cos(EAz).*sin(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) + sin(EAz).*sin(Eih).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma))) + sin(EAz).*sin(Eih).*(cos(Eih).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma)) + cos(EAz).*sin(Eih).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) + sin(EAz).*sin(Eih).*(cos(gamma).*(sin(2.*strike).*cos(rake).*sin(dip) - sin(2.*dip).*cos(strike).^2.*sin(rake)) - sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*cos(strike).^2.*sin(dip).^2))) - cos(EAz).*sin(Eih).*(cos(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) - sin(EAz).*sin(Eih).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) + cos(EAz).*sin(Eih).*(cos(gamma).*(sin(2.*dip).*sin(rake).*sin(strike).^2 + sin(2.*strike).*cos(rake).*sin(dip)) + sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*sin(dip).^2.*sin(strike).^2)));
    case 'S'
        G = ((sin(EAz).*sin(Eih).*(cos(EAz).*cos(Eih).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - sin(Eih).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma)) + cos(Eih).*sin(EAz).*(cos(gamma).*(sin(2.*strike).*cos(rake).*sin(dip) - sin(2.*dip).*cos(strike).^2.*sin(rake)) - sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*cos(strike).^2.*sin(dip).^2))) - cos(Eih).*(sin(Eih).*(sin(gamma).*(2.*cos(dip).^2 - (2.*sigma)./(2.*sigma - 1)) + sin(2.*dip).*cos(gamma).*sin(rake)) + cos(EAz).*cos(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) - cos(Eih).*sin(EAz).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma))) + cos(EAz).*sin(Eih).*(sin(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) + cos(Eih).*sin(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - cos(EAz).*cos(Eih).*(cos(gamma).*(sin(2.*dip).*sin(rake).*sin(strike).^2 + sin(2.*strike).*cos(rake).*sin(dip)) + sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*sin(dip).^2.*sin(strike).^2)))).^2 + (cos(Eih).*(cos(EAz).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma)) + sin(EAz).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike))) - sin(EAz).*sin(Eih).*(sin(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - cos(EAz).*(cos(gamma).*(sin(2.*strike).*cos(rake).*sin(dip) - sin(2.*dip).*cos(strike).^2.*sin(rake)) - sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*cos(strike).^2.*sin(dip).^2))) + cos(EAz).*sin(Eih).*(sin(EAz).*(cos(gamma).*(sin(2.*dip).*sin(rake).*sin(strike).^2 + sin(2.*strike).*cos(rake).*sin(dip)) + sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*sin(dip).^2.*sin(strike).^2)) + cos(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)))).^2).^(1./2);
    case 'SH'
        G = cos(Eih).*(cos(EAz).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma)) + sin(EAz).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike))) - sin(EAz).*sin(Eih).*(sin(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - cos(EAz).*(cos(gamma).*(sin(2.*strike).*cos(rake).*sin(dip) - sin(2.*dip).*cos(strike).^2.*sin(rake)) - sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*cos(strike).^2.*sin(dip).^2))) + cos(EAz).*sin(Eih).*(sin(EAz).*(cos(gamma).*(sin(2.*dip).*sin(rake).*sin(strike).^2 + sin(2.*strike).*cos(rake).*sin(dip)) + sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*sin(dip).^2.*sin(strike).^2)) + cos(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)));
    case 'SV'
        G = sin(EAz).*sin(Eih).*(cos(EAz).*cos(Eih).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - sin(Eih).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma)) + cos(Eih).*sin(EAz).*(cos(gamma).*(sin(2.*strike).*cos(rake).*sin(dip) - sin(2.*dip).*cos(strike).^2.*sin(rake)) - sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*cos(strike).^2.*sin(dip).^2))) - cos(Eih).*(sin(Eih).*(sin(gamma).*(2.*cos(dip).^2 - (2.*sigma)./(2.*sigma - 1)) + sin(2.*dip).*cos(gamma).*sin(rake)) + cos(EAz).*cos(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) - cos(Eih).*sin(EAz).*(cos(gamma).*(cos(2.*dip).*cos(strike).*sin(rake) - cos(dip).*cos(rake).*sin(strike)) - sin(2.*dip).*cos(strike).*sin(gamma))) + cos(EAz).*sin(Eih).*(sin(Eih).*(cos(gamma).*(cos(2.*dip).*sin(rake).*sin(strike) + cos(dip).*cos(rake).*cos(strike)) - sin(2.*dip).*sin(gamma).*sin(strike)) + cos(Eih).*sin(EAz).*(cos(gamma).*(cos(2.*strike).*cos(rake).*sin(dip) + (sin(2.*dip).*sin(2.*strike).*sin(rake))./2) - sin(2.*strike).*sin(dip).^2.*sin(gamma)) - cos(EAz).*cos(Eih).*(cos(gamma).*(sin(2.*dip).*sin(rake).*sin(strike).^2 + sin(2.*strike).*cos(rake).*sin(dip)) + sin(gamma).*((2.*sigma)./(2.*sigma - 1) - 2.*sin(dip).^2.*sin(strike).^2)));
    otherwise
        fprintf('Wrong wave mode\n');
        return;
end

  
end

