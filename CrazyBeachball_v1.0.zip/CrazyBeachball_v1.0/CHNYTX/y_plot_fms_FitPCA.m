function [  ] = y_plot_fms_FitPCA(  )

% plot focal mechanism, polarities, and waveforms
% amplitude ratios
% absolute amplitudes
% separation times
% 

inputfile = '../Colombia20150310/Colombia20150310_P.dat';


FitPCAdir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/FitPCA';

listname = 'list_z_FitPCA_P.txt';

phasename = 'P';


[ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');

% get station name
% stnameonly = stname;
for i = 1:length(stname)
    stnamei = stname{i};
    ind = strfind(stnamei,'.');
    stnameonly{i} = stnamei(ind+1:end);
end

[pathstr, name, ext] = fileparts(inputfile); %#ok<NASGU>
% deal with polarity readings more than NN_threshold
NN=length(IP);     % NN=Total polarity readings

% change ray-upward points to ray-downward points, also remove data points,
% whose Eih are NaN.
temp = 1;
for i=1:NN
    if ~isnan(Eih(i)) % in case of Eih(i) is NaN. delete Eih(i) = NaN points
        if Eih(i)>90
            Eih(i)=180-Eih(i);  EAz(i)=EAz(i)+180;
            if EAz(i)>360,    EAz(i)=EAz(i)-360;    end
        end
        EAz_temp(temp,1) = EAz(i);        Eih_temp(temp,1) = Eih(i);        IP_temp(temp,1) = IP(i);
        temp = temp + 1;
    end
end
EAz_all = EAz_temp; Eih_all = Eih_temp; IP_all = IP_temp;


% plot nodal lines for the most probable cluster center
sol = [ 30 75  300 145 34  208  335 51   97 24  202 29  0.01 3.9 1.000 ];
SK1 = sol(1);
DA1 = sol(2);
SA1 = sol(3); 
SK2 = sol(4); 
DA2 = sol(5); 
SA2 = sol(6); 
PAZ = sol(7); 
PPL = sol(8); 
TAZ = sol(9); 
TPL = sol(10); 
BAZ = sol(11); 
BPL = sol(12);  
MDB = sol(13);  
RMS = sol(14);  
REL = sol(15); 

% plot parameters
X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
% R1=0.25; %radius of PTB circle
scrsz = get(0,'ScreenSize');
remin = 1/2*min(scrsz(3:4));

% P and T axes location on Schmidt net
RAD = pi / 180;
CPAZ_one = RAD * PAZ;    CPIH_one = RAD * ( 90 - PPL );
CTAZ_one = RAD * TAZ;    CTIH_one = RAD * ( 90 - TPL );
rp = R0 * sqrt(2)*sin(CPIH_one/2);    % Schmidt projection
rt = R0 * sqrt(2)*sin(CTIH_one/2);    % Schmidt projection
xp=X0+rp.*sin(CPAZ_one);    yp=Y0+rp.*cos(CPAZ_one);
xt=X0+rt.*sin(CTAZ_one);    yt=Y0+rt.*cos(CTAZ_one);


% %% temp plot
% f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
% set(f1,'name',['Polarities'],'NumberTitle','off');
% hbb = axes('Position',[0 0 1 1]);
% hold on;
% % plot great circle
% FMcircle(X0,Y0,R0); %axis equal;
% % plot nodal lines
% [xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
% [xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% % plot polarity readings on Schmidt net
% 
% FMplotP(EAz_all,Eih_all,X0,Y0,R0,IP_all);
% % FMplotP(EAz,Eih,X0,Y0,R0,IP);
% 
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
% xlim([X0-2*R0,X0+2*R0]);
% ylim([Y0-2*R0,Y0+2*R0]);
% axis off;
% 
% textname(EAz_all,Eih_all,X0,Y0,R0,stname);
% 
% axis([0 1 0 1]);
% 
% return;



%% Load in PCA results
% timewin = [-10 10];
% delta = 0.1;
% itime = reshape(timewin(1):delta:timewin(2),[],1);


if ~exist(fullfile(FitPCAdir,listname),'file')
    return;
end

lists = textread(fullfile(FitPCAdir,listname),'%s','commentstyle','shell');
num = 0;
for i = 1:length(lists)
    
    load(fullfile(FitPCAdir,lists{i}));
    
    stname_tmp = fit.staname;
    ind = find(strcmpi(stname_tmp,stnameonly));
    if isempty(ind)
        continue;
    end
    
    idx = ind(1);
    num = num + 1;
    EAz_P(num) = EAz(idx);
    Eih_P(num) = Eih(idx);
    stname_P{num} = stname_tmp;
    
    itime = fit.timeVector;
    idata = fit.data;
    isyn = fit.gaussSynthetic;
    
    iA0 = max(idata)-min(idata);
    if iA0 == 0
        iA0 = 1;
    end
    tr(num).data = idata/iA0;
    tr(num).syn = isyn/iA0;
    tr(num).time = itime;
    tr(num).A0 = iA0;
    tr(num).EAz = EAz(idx);
    tr(num).Eih = Eih(idx);
    tr(num).stname = stname_tmp;
    tr(num).amp1 = fit.amp1;
    tr(num).amp2 = fit.amp2;
    tr(num).ampratio = fit.amp1/fit.amp2;
    tr(num).polarity = fit.polarity;
    tr(num).ct1 = fit.centroid1;
    tr(num).ct2 = fit.centroid2;
    tr(num).dct = fit.centroid2-fit.centroid1;
    tr(num).dur1 = fit.durationEvent1;
    tr(num).dur2 = fit.durationEvent2;
    
end
    
    

% calculate point locations
EAZ_Fit = [tr.EAz];
IH_Fit = [tr.Eih];
RAD = pi / 180;
AZP = RAD * EAZ_Fit;
IHP = RAD * IH_Fit;
rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xd=X0+rp.*sin(AZP);
yd=Y0+rp.*cos(AZP);


%% Plotting

%% plot Centroid time difference
f1 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f1,'name','Centroid time difference','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
dct = [tr.dct];
axes(hbb)
scatter(xd,yd,20,dct,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
ylabel(h,'Centroid time difference (s)');


%% plot event centroid time - Event 1
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Centroid time of event 1','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
ct1 = [tr.ct1];
axes(hbb)
scatter(xd,yd,20,ct1,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
ylabel(h,'Centroid time of event 1 (s)');  


%% plot event centroid time - Event 2
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Centroid time of event 2','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
ct2 = [tr.ct2];
axes(hbb)
scatter(xd,yd,20,ct2,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
ylabel(h,'Centroid time of event 2 (s)'); 
    

%% plot amplitude ratios
f2 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f2,'name','Amplitude ratios','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
lratios = log10([tr.ampratio]);
axes(hbb)
scatter(xd,yd,20,lratios,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
% caxis([-log10(2) log10(2)]);
ylabel(h,'Log_{10}(A1/A2)');   


%% plot absolute amplitudes - Event 1
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Absolute amplitude of event 1','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
absamp1 = log10([tr.amp1]);
axes(hbb)
scatter(xd,yd,20,absamp1,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
% caxis([-log10(2) log10(2)]);
ylabel(h,'Log_{10}(A1)');  


%% plot absolute amplitudes - Event 2
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Absolute amplitude of event 2','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
absamp2 = log10([tr.amp2]);
axes(hbb)
scatter(xd,yd,20,absamp2,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
% caxis([-log10(2) log10(2)]);
ylabel(h,'Log_{10}(A2)');  


%% plot event duration - Event 1
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Duration of event 1','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
dur1 = [tr.dur1];
axes(hbb)
scatter(xd,yd,20,dur1,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
ylabel(h,'Duration of event 1 (s)');  


%% plot event duration - Event 2
f3 = figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
set(f3,'name','Duration of event 2','NumberTitle','off');
hbb = axes('Position',[0 0 1 1]);
hold on;
% plot great circle
FMcircle(X0,Y0,R0); %axis equal;
% plot nodal lines
[xs,ys]=FMnodline(SK1,DA1,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline I
[xs,ys]=FMnodline(SK2,DA2,X0,Y0,R0);  plot(xs,ys,'r','LineWidth',2); %--cluster center nodline II
% text(xp,yp,'P','color','k','FontSize',16);
% text(xt,yt,'T','color','k','FontSize',16);
xlim([X0-2*R0,X0+2*R0]);
ylim([Y0-2*R0,Y0+2*R0]);
axis off;
axis([0 1 0 1]);
% hold(hbb,'on');
plot_bb_FitPCA(hbb, [tr.EAz], [tr.Eih], X0, Y0, R0, tr );

% plot amplitude ratios of event 1 to event 2
dur2 = [tr.dur2];
axes(hbb)
scatter(xd,yd,20,dur2,'o','filled');
h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
ylabel(h,'Duration of event 2 (s)'); 


end

