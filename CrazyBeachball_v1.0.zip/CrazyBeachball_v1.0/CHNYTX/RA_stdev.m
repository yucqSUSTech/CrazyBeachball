function [rms] = RA_stdev( S )

%% README
%calculate select solutions'  rotation angle stdev

% INPUT:
% S: n-by-d matrix of selected solutions, where n is the number of selected
% solutions, d indicates six components of each solution's stresstensor.

% OUTPUT:
% rms: root mean square of minimum rotation angle between selected
% solutions and their cluster center

rad = pi/180;
num = size(S,1);  %S is a n-by-6 matrix ,where 6 represents 6 components of stress matrix
if num == 1
    ES = S;
else
    ES = mean(S);  % find mean ES
end
ES_matrix = [ES(1) ES(2) ES(3) ; ES(2) ES(4) ES(5) ; ES(3) ES(5) ES(6)];

[E_V,E_D] = eig(ES_matrix); %#ok<NASGU>
E_p = [E_V(1,1),E_V(2,1),E_V(3,1)]; %pbt
E_b = [E_V(1,2),E_V(2,2),E_V(3,2)];
E_t = cross(E_p,E_b);

%% root mean square
rms = 0; 
for i = 1:num
    S_matrix = [S(i,1) S(i,2) S(i,3); S(i,2) S(i,4) S(i,5); S(i,3) S(i,5) S(i,6)];
    [V,D] = eig(S_matrix); %#ok<NASGU>
    p = [V(1,1),V(2,1),V(3,1)];
    b = [V(1,2),V(2,2),V(3,2)];
    t = cross(p,b);
    
    [ array ] = sort([ p*E_p', t*E_t' , b*E_b' ],'descend');
    trA = array(1)+abs(array(2)+array(3));
    c_RA = (trA-1)/2;  %trA = 1 + 2*cos(rotation_angle)    
    rms = rms + ( acos(c_RA)/rad )^2;
end 
rms = sqrt(rms/num);
end
