function [ strike2, dip2, rake2 ] = y_GS_Auxplane( strike1, dip1, rake1  )

% Calculate Auxiliary nodal plane
r2d = 180/pi;

s1 = (strike1+90)/r2d;
d1 = dip1/r2d;
r1 = rake1/r2d;

% calculate slip vector in nodal plane 1
sv1 = -cos(r1).*cos(s1)-sin(r1).*sin(s1).*cos(d1);
sv2 = cos(r1).*sin(s1)-sin(r1).*cos(s1).*cos(d1);
sv3 = sin(r1).*sin(d1);

% calculate strike and dip of nodal plane 2
ind = find(sv3 < 0);
pol = ones(size(sv3));
pol(ind) = -1;

strike2 = atan2(pol.*sv1,pol.*sv2)*r2d-90;
strike2 = mod(strike2,360);

dip2 = atan2(sqrt(sv1.^2 + sv2.^2),pol.*sv3)*r2d;

% calculate rake of nodal plane 2
% normal vector to nodal plane 1
n1 = sin(s1).*sin(d1);
n2 = cos(s1).*sin(d1);
n3 = cos(d1);
% horizontal vector of the intersection of nodal plane 2 with surface
h1 = -sv2;
h2 = sv1;
h3 = 0;

rake2 = acos((h1.*n1 + h2.*n2 + h3.*n3)./sqrt(h1.*h1 + h2.*h2 + h3.*h3))*r2d;
ind = find(sv3 <= 0);
rake2(ind) = -rake2(ind);

end

