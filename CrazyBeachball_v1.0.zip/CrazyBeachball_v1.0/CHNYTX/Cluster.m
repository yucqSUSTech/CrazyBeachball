function [cid,nr,centers] = Cluster(S,max_cluster_num,RA_range)

%% README
% [cid,nr,centers] = Cluster(S,max_cluster_num,RA_range) performs minimum rotation angle K-means
% clustering using the data given in S.                                             
%                                                                                   
% INPUTS: 
% S: n-by-d matrix of selected solutions, where n is the number of selected
% solutions, d(=6) indicates six components of each solution's stress tensor.  
% max_cluster_num: max cluster number, ultimate cluster number will be re-calculated.
% RA_range: threshold value for combining 'close' clusters.
                                                                             
% OUTPUTS:
% cid provides a set of n indexes indicating cluster membership for each solution. 
% nr is the number of solutions in each cluster. 
% centers is a matrix, each row corresponds to a cluster center.     

rad = pi/180;
n = size(S,1);    
if max_cluster_num > n
    pre_CN = n;
else
    pre_CN = max_cluster_num;%initial cluster number
end

% calculate rotation angle between every two solutions
rot_ang = zeros(n,n);
for i = 1:n 
    S11_i = S(i,1);    S12_i = S(i,2);    S13_i = S(i,3);    S22_i = S(i,4);    S23_i = S(i,5);    S33_i = S(i,6); 
    S_matrix_i = [S11_i S12_i S13_i ; S12_i S22_i S23_i ; S13_i S23_i S33_i];
    [S_V_i,S_D_i] = eig(S_matrix_i); %#ok<NASGU>
    S_p_i = [S_V_i(1,1),S_V_i(2,1),S_V_i(3,1)];
    S_b_i = [S_V_i(1,2),S_V_i(2,2),S_V_i(3,2)];
    S_t_i = cross(S_p_i,S_b_i);
    for j = (i+1):n
        S11_j = S(j,1);    S12_j = S(j,2);    S13_j = S(j,3);    S22_j = S(j,4);    S23_j = S(j,5);    S33_j = S(j,6); 
        S_matrix_j = [S11_j S12_j S13_j ; S12_j S22_j S23_j ; S13_j S23_j S33_j];
        [S_V_j,S_D_j] = eig(S_matrix_j); %#ok<NASGU>
        S_p_j = [S_V_j(1,1),S_V_j(2,1),S_V_j(3,1)];
        S_b_j = [S_V_j(1,2),S_V_j(2,2),S_V_j(3,2)];
        S_t_j = cross(S_p_j,S_b_j);
        
        % find the rotation angle between S_i and S_j
        [ array ] = sort([ S_p_i*S_p_j', S_b_i*S_b_j' , S_t_i*S_t_j' ],'descend');
        trA = array(1)+abs(array(2)+array(3));
        c_RA = (trA-1)/2;  %trA = 1 + 2*cos(rotate_angle)
        rot_ang(i,j) = acos(c_RA)/rad;
        rot_ang(j,i) = rot_ang(i,j);
    end
end
 
% flag is used to judge whether cluster centers need to be combined. 
% flag=0 :stop; flag=1 : go on.
flag = 1;
while flag == 1
    
    % Pick initial cluster centers, judged by rotation angle
    if pre_CN == 1
        pick = 1;
    else
        %find the two solutions, between which the rotation angle is
        %maximum. line and row are index
        [A,row] = max(max(rot_ang));
        [B,line] = max(rot_ang(:,row));
        pick = zeros(1,pre_CN);
        pick(1) = line;
        pick(2) = row;
        % find the third initial cluster center, then the fourth, fifth,
        % ...... step by step
        %judge criteria is the sum of rotation angle between new initial
        %cluster center and pre-exist initial cluster centers
        for k = 3:pre_CN
            ra_sum=zeros(1,n);
            for i = 1:n
                for l = 1:(k-1)
                    ra_sum(i) = ra_sum(i) + rot_ang(i,pick(l));
                end
            end
            [Z,IX] = sort(ra_sum,'descend');
            
            for i = 1:n %in case the new initial cluster center already existed.
                sign = 1;
                for l = 1:(k-1)
                    if IX(i) == pick(l);
                        sign = 0;
                    end
                end
                if sign == 1
                    pick(k) = IX(i);
                    break;
                end
            end
        end
    end
    CC = S(pick,:);   % initial cluster centers     
       
    % pre_allocation
    NR = zeros(1,pre_CN); 
    CID = ones(1,n);
    pre_cid = zeros(1,n);
    RA = zeros(1,pre_CN);     
    maxiter = 100;   % Set up maximum number of iterations.
    iter = 1;
    % K-means clustering
    while ~isequal(CID,pre_cid) && iter < maxiter 
        pre_cid = CID;        
        % For each solution, calculate the rotation angle to all cluster
        % centers 
        for i = 1:n 
            S11 = S(i,1);    S12 = S(i,2);    S13 = S(i,3);    S22 = S(i,4);    S23 = S(i,5);    S33 = S(i,6); 
            S_matrix = [S11 S12 S13 ; S12 S22 S23 ; S13 S23 S33];
            [S_V,S_D] = eig(S_matrix); %#ok<NASGU>
            S_p = [S_V(1,1),S_V(2,1),S_V(3,1)];
            S_b = [S_V(1,2),S_V(2,2),S_V(3,2)];
            S_t = cross(S_p,S_b);
            for j = 1:pre_CN
                CC11 = CC(j,1);    CC12 = CC(j,2);    CC13 = CC(j,3);    CC22 = CC(j,4);    CC23 = CC(j,5);    CC33 = CC(j,6);
                CC_matrix = [CC11 CC12 CC13 ; CC12 CC22 CC23 ; CC13 CC23 CC33];
                [CC_V,CC_D] = eig(CC_matrix); %#ok<NASGU>
                CC_p = [CC_V(1,1),CC_V(2,1),CC_V(3,1)];
                CC_b = [CC_V(1,2),CC_V(2,2),CC_V(3,2)];
                CC_t = cross(CC_p,CC_b);
                % find the rotation angle between S and CC
                [ array ] = sort([ S_p*CC_p', S_b*CC_b' , S_t*CC_t' ],'descend');
                trA = array(1)+abs(array(2)+array(3));
                c_RA = (trA-1)/2;  %trA = 1 + 2*cos(rotate_angle)
                RA(j) = acos(c_RA)/rad;
            end            
            % assign each solution to the nearest cluster center
            [m,indices] = min(RA); 
            CID(i) = indices;
        end
        % Find the new cluster centers
        for i = 1:pre_CN    
            % find all S in each cluster
            ind = find(CID==i);      
            if size(ind,2) == 0 % no point in this cluster
                CC(i,:) = S(i,:); %assign the i's S as a new cluster center
            elseif size(ind,2) == 1
                CC(i,:) = S(ind,:);
            else
                CC(i,:) = mean(S(ind,:));  % find the centroid
            end
            NR(i) = length(ind);  % Find the number in each cluster;
        end
        iter = iter + 1;
    end 
    
    % judge whether it is need do the iteration again for a new number of
    % cluster centers
    if  pre_CN ==1 %only one cluster center,then break
        flag =0;
    else
        next_CN = NextCN(CC,RA_range); % subroutine NextCN.m: calculate next cluster number with original centers
        if next_CN == pre_CN  %next cluster number is equal to previous cluster number, then break
            flag = 0;
        else
            pre_CN = next_CN;
        end
    end
end
cid = CID;
nr = NR;
centers = CC;
end
