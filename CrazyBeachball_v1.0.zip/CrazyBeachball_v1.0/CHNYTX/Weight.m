function [ coefficient ] = Weight( azimuth , zenith , IP , dangle , w2 )

%% README
%WEIGHT calculate the localized weight of all points, judged by points' density and class
% n1 = number of points(class I) in local area
% n2 = number of points (class II) in local area
% weight = 1/( n1 + w2*n2)

% INPUT:
% azimuth: points' azimuth
% zenith: points' zenith
% IP: points' polarity
% dangle: angle range used to define points' density
% w2: ratio of data class II to data class I
% 
% OUTPUT:
% coefficient: each point's weight

%%
num = size(azimuth,1);
coefficient = ones(1,num)/num;
if isempty(dangle) || dangle == 0
    return;
end

rad = pi/180;
az = azimuth*rad;%deg2rad
ih = zenith*rad;%deg2rad

% coefficient = zeros(1,num);

c_dangle = cos(dangle);

for i = 1:num
      
      local_num = 0;       
      n = [sin(ih(i))*cos(az(i)) , sin(ih(i))*sin(az(i)) , cos(ih(i))];%direction cosine of each point
      
      for j = 1:num
            m = [sin(ih(j))*cos(az(j)) , sin(ih(j))*sin(az(j)) , cos(ih(j))];
            if m*n' >= c_dangle
                  local_num = local_num + 1;
            end
      end

      if local_num == 0
            coefficient(i) = 0;
      else
            if ( abs( IP(i) ) < 10)
                coefficient(i) = 1/local_num;   %weight of class I point
            else
                coefficient(i) = w2/local_num; %weight of class II point
            end 
      end

end
         
effect_num = sum(coefficient);         
coefficient = coefficient / effect_num;%normalization

end
