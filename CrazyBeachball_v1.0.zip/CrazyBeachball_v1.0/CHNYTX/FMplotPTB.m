function FMplotPTB( name,PAZ,PPL,TAZ,TPL,BAZ,BPL,cid,NUM,X,Y,R )

% INPUT:
% name: name of the event
% PAZ: P axis's azimuth
% PPL: P axis's plunge angle
% TAZ: T axis's azimuth
% TPL: T axis's plunge angle
% BAZ: B axis's azimuth
% BPL: B axis's plunge angle
% cid: a set of n indexes indicating cluster membership for each solution
% NUM: number of clusters
% X,Y,R: x,y is the position of the graph's center, r is radius.

%%  Plot all possible P, B & T axes
% P-axis
XP = X-2*X/3;
YP = Y;
FMcircle(XP,YP,R);  hold on; 
XX = XP;
YY = YP + 3*R/2;
text(XX,YY,'P','color',[0 0 0]);
PIH = 90 - PPL;
% FMplotP(PAZ,PIH,XP,YP,R); % plot selected solutions' P axis
RAD = pi / 180;
AZP = RAD * PAZ; 
IHP = RAD * PIH;
rp = R * sqrt(2)*sin(IHP/2);    % Schmidt projection
xp=XP+rp.*sin(AZP); 
yp=YP+rp.*cos(AZP);


% T-axis
XT = X;
YT = Y;
FMcircle(XT,YT,R);  hold on; 
XX = XT;
YY = YT + 3*R/2;
text(XX,YY,'T','color',[0 0 0]);
TIH = 90 - TPL;
% FMplotP(TAZ,TIH,XT,YT,R); % plot selected solutions' T axis
AZT = RAD * TAZ; 
IHT = RAD * TIH;
rt = R * sqrt(2)*sin(IHT/2);    % Schmidt projection
xt=XT+rt.*sin(AZT); 
yt=YT+rt.*cos(AZT);


% B-axis
XB = X+2*X/3;
YB = Y;
FMcircle(XB,YB,R);  hold on; 
XX = XB;
YY = YB + 3*R/2;
text(XX,YY,'B','color',[0 0 0]);
BIH = 90 - BPL;
% FMplotP(BAZ,BIH,XB,YB,R); % plot selected solutions' B axis
AZB = RAD * BAZ; 
IHB = RAD * BIH;
rb = R * sqrt(2)*sin(IHB/2);    % Schmidt projection
xb=XB+rb.*sin(AZB); 
yb=YB+rb.*cos(AZB);

% plot P,T,B axis
for i = 1:NUM
    ind = find(cid==i);
    xpc = xp(ind); xtc=xt(ind); xbc=xb(ind);
    ypc = yp(ind); ytc=yt(ind); ybc=yb(ind);
    if i == 1
        scatter(xpc,ypc,'r');scatter(xtc,ytc,'r');scatter(xbc,ybc,'r');
    elseif i == 2
        scatter(xpc,ypc,'g');scatter(xtc,ytc,'g');scatter(xbc,ybc,'g');
    else
        scatter(xpc,ypc,'b');scatter(xtc,ytc,'b');scatter(xbc,ybc,'b');
    end
end


% title(name,'fontsize',12);
axis off;
end
