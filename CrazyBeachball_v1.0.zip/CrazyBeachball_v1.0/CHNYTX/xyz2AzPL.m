function [AZ,PL] = xyz2AzPL(V)
%-- Find Az & ih of an axis from its direction cosines ---
%  Az is from North clockwise positive
%  Ih-between Down-Z & Down-ray
% for lower hemisphere
rad=pi/180;
if V(3)<0
    V = -V;
end
AZ=atan2(V(2),V(1))/rad;
if AZ<0
    AZ=AZ+360; 
end
PL = 90 - atan2(sqrt(V(1)^2+V(2)^2),V(3))/rad;
end
