function [ SK1 DA1 SA1  SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL ] = Parameters( S )
% 1,2 represent two conjugate planes
%SK:strike ; DA:dip angle ; SA: slip angle ; 
%PAZ: azimuth of P axis ; PPL: angle between P axis and horizontal plane;
%TAZ: azimuth of T axis ; TPL: angle between T axis and horizontal plane;
%BAZ: azimuth of B axis ; BPL: angle between B axis and horizontal plane;
rad=pi/180;
n = size(S,1);
%prelocation
PAZ=zeros(n,1);PPL=zeros(n,1);
BAZ=zeros(n,1);BPL=zeros(n,1);
TAZ=zeros(n,1);TPL=zeros(n,1);
SK1=zeros(n,1);DA1=zeros(n,1);SA1=zeros(n,1);
SK2=zeros(n,1);DA2=zeros(n,1);SA2=zeros(n,1);

for i = 1:n    
    S11 = S(i,1);    S12 = S(i,2);    S13 = S(i,3);    S22 = S(i,4);    S23 = S(i,5);    S33 = S(i,6);
    S_matrix = [S11 S12 S13 ; S12 S22 S23 ; S13 S23 S33];
    
    [V,D] = eig(S_matrix); %#ok<NASGU>
    p = [V(1,1),V(2,1),V(3,1)];
    b = [V(1,2),V(2,2),V(3,2)];
    t = cross(p,b);
    
    [PAZ(i),PPL(i)] = xyz2AzPL(p);
    [BAZ(i),BPL(i)] = xyz2AzPL(b);
    [TAZ(i),TPL(i)] = xyz2AzPL(t);
    
    %% calculate SK and DA of two conjugate planes
    M = (t-p)/sqrt(2);
    [MAZ,MPL] = xyz2AzPL(M);  %subroutine xyz2AzIh.m
    DA1(i)=90-MPL; 
    SK1(i)=MAZ+90; 
    if SK1(i)>360
        SK1(i)=SK1(i)-360;
    end

    N = (t+p)/sqrt(2);  
    [NAZ,NPL] = xyz2AzPL(N);  %subroutine xyz2AzIh.m 
    DA2(i)=90-NPL; 
    SK2(i)=NAZ+90; 
    if SK2(i)>360
        SK2(i)=SK2(i)-360;
    end

    %% calculate SA of two conjugate planes
    % let M,N upward, normal to the lower plate of plane1 and plane2 respectively.   %M(3)>0,N(3)>0 means downward
    if M(3)>0, M=-M;  end
    if N(3)>0, N=-N;  end
    
    % calculate the slip vector of plane 1 and 2 . % upper plate relative to lower plate
    if t*M'<0, t=-t;  end
    if p*M'>0, p=-p;  end
    SV1 = (t+p)/sqrt(2); %slip vector along plane 1
    
    if t*N'<0, t=-t;  end
    if p*N'>0, p=-p;  end
    SV2 = (t+p)/sqrt(2);%slip vector along plane 2
    
    phi1 = [cos(SK1(i)*rad),sin(SK1(i)*rad),0];
    SA1(i) = acos(SV1*phi1')/rad;
    phi2 = [cos(SK2(i)*rad),sin(SK2(i)*rad),0];
    SA2(i) = acos(SV2*phi2')/rad;
    if SV1(3)>0
        SA1(i) = 360-SA1(i);
    end
    if SV2(3)>0
        SA2(i) = 360-SA2(i);
    end
    
end
end
