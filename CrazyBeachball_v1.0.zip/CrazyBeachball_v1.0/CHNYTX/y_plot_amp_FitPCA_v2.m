function [  ] = y_plot_amp_FitPCA_v2(  )

% plot focal mechanism, polarities, and waveforms



FitPCAdir = '/media/yucq2/Data0/Colombia_20150310/Fromserver/FitPCA';

listname = 'list_z_FitPCA_P.txt';


np = 100;
em = set_vmodel_v2('iasp91');
r2d = 180/pi;

evdp = 157;
vp = interp1db(evdp,em.z,em.vp);
lists = textread(fullfile(FitPCAdir,listname),'%s','commentstyle','shell');

[rayp,taup,Xp] = phase_taup('P',evdp,np,em);
t1 = taup + rayp.* Xp;
d1 = Xp*r2d;
    
for i = 1:length(lists)
    
    load(fullfile(FitPCAdir,lists{i}));
    
    
    rayp0(i) = interp1(d1,rayp,fit.dist,'linear',nan);
    
    amp1(i) = fit.amp1;
    amp2(i) = fit.amp2;
    az(i) = fit.az;
    
end
theta = asind(rayp0*vp/(em.re-evdp));

[X1,Y1] = pol2cart(az*pi/180,abs(amp1));
[X2,Y2] = pol2cart(az*pi/180,abs(amp2));
[X3,Y3] = pol2cart(az*pi/180,abs(amp1./amp2));
[c1,ind_amp1] = max(abs(amp1));
[c2,ind_amp2] = max(abs(amp2));
[c3,ind_amp3] = max(abs(amp1./amp2));

msize = 20;
figure;

% t = linspace(0,2*pi,100);
% h_fake = polar(t,c1*ones(size(t)));
% hold on;
% set(h_fake,'Visible','off');
% scatter(X1,Y1,msize,theta,'filled');
% view([90 -90]);

% t = linspace(0,2*pi,100);
% h_fake = polar(t,c2*ones(size(t)));
% hold on;
% set(h_fake,'Visible','off');
% scatter(X2,Y2,msize,theta,'filled');
% view([90 -90]);

t = linspace(0,2*pi,100);
h_fake = polar(t,c3*ones(size(t)));
hold on;
set(h_fake,'Visible','off');
scatter(X3,Y3,msize,theta,'filled');
view([90 -90]);


h = colorbar('location','eastoutside','position',[0.9 0.3 0.02 0.4]);
ylabel(h,'Take off angle (^o)');


% figure
% h1 = polar(az*pi/180,abs(amp1),'ko');
% set(h1,'MarkerFacecolor','r');
% view([90 -90]);
% h2 = polar(az*pi/180,abs(amp2),'ko');
% set(h2,'MarkerFacecolor','r');
% view([90 -90]);
% h3 = polar(az*pi/180,abs(amp1./amp2),'ko');
% set(h3,'MarkerFacecolor','r');
% view([90 -90]);
   

end

