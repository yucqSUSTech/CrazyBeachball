function [  ] = test(  )
%TEST Summary of this function goes here
%   Detailed explanation goes here

%%
% for i = 1:10
%     
%     
%     strike1 = 360*rand;
%     dip1 = 90*rand;
%     rake1 = 360*rand - 180;
%     
%     [strike,dip,rake]=y_GS_Auxplane(strike1, dip1, rake1);
%     [strike2,dip2,rake2]=auxplane(strike1, dip1, rake1);
%     
%     m = sqrt((strike-strike2).^2 + (dip-dip2).^2 + (rake-rake2).^2)
%     
% end

%%
% [strike dip rake] = deal(144, 27, -149);
% 
% 
% inputfile = '../Colombia20150310/Colombia20150310_P.dat';
% [ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');
% % change to lower hemisphere projection
% ind = find(Eih>90);
% Eih(ind) = 180-Eih(ind);
% EAz(ind) = mod(EAz(ind)+180,360);
%     
% Wmode = 'P';
% gamma = 0;
% sigma = 0.25;
% 
% [ G ] = y_radiationpattern( strike, dip, rake, gamma, sigma, EAz, Eih, Wmode );
% 
% strike2 = strike-10;
% dip2 = dip;
% rake2 = rake;
% 
% [ G2 ] = y_radiationpattern( strike2, dip2, rake2, gamma, sigma, EAz, Eih, Wmode );
% 
% 
% lratios = log10(abs(G./G2));
% 
% % figure;
% % plot parameters
% X0 = 0.5; Y0 = 0.5; R0 = 0.25; % Center & Radius of great circle
% % R1=0.25; %radius of PTB circle
% scrsz = get(0,'ScreenSize');
% remin = 1/2*min(scrsz(3:4));
% % plot focal mechanism solutions
% figure('Position',[scrsz(3)/2-remin/2 scrsz(4)/2-remin/2 remin remin]);
% axes('Position',[0 0 1 1]);
% hold on;
% FMcircle(X0,Y0,R0);
% % axis equal;
%     
% % NN = length(EAz);
% RAD = pi / 180;
% AZP = RAD * EAz;
% IHP = RAD * Eih;
% rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
% xp=X0+rp.*sin(AZP);
% yp=Y0+rp.*cos(AZP);
% 
% scatter(xp,yp,20,lratios,'o','filled');
% h = colorbar('location','eastoutside','position',[0.85 0.3 0.02 0.4]);
% caxis([-log10(2) log10(2)]);
% ylabel(h,'Log_{10}(A1/A2)');


%%
figure;
x=-10:0.1:10;
y1=gaussmf(x,[1.2 0]);
y2=0.4*gaussmf(x,[0.8 -2]);
subplot(2,1,1);
plot(x,y1+y2)
subplot(2,1,2);
plot(x,y1-y2)

end

