function para = y_GS_para

%% README
% parameters
% NN_threshold: minimum number of data points
% Nzenith: number of B axis's zenith test, dzenith = 90/Nzenith
% Nrotation: number of division of 90 rotation angle around B axis, drotation = 90/Nrotation. (due to centrosymmetry of polarity and interchangable of P and T axes, the ration angle changes from 360 to 90 )
% w2: relative points' weight (weight(class II)/weight(class I))
% dangle: parameter which is used to determine solidangle
% discrepancy_range: used for choosing selected solutions.
% min_number: minimum number of selected solutions
% max_number: maximum number of selected solutions
% max_cluster_num: maximum number of cluster centers
% RA_range: the minimum distance between two cluster centers.
% jack_knife: jack knife technique switch
% jack-knife == 'delete': iteratively remove one point
% jack-knife == 'reverse': iteratively change one point's polarity
% jack-knife == 'none' or others: do not apply jack knife technique
% DIS_good: the maximum weighted discrepancy ratio of Class A solutions
% DIS_bad: the maximum weighted discrepancy ratio of Class B solutions
% RMS_good: the maximum RMS of Class A solutions

%% parameters 
% minimum number of data points
para.NN_threshold = 10;

% Grid search parameters
% dstrike = 5;
% ddip = 5;
% drake = 5;
% para.strike = 0:dstrike:360-dstrike;
% para.dip = 0:ddip:90;
% para.rake = -180:drake:180-drake;
dstrike = 1;
ddip = 1;
drake = 1;
para.strike = 120:dstrike:160;
para.dip = 20:ddip:40;
para.rake = -180:drake:-140;
% % azimuth zenith are the ray direction from the source in the local NED frame with N for x , E for y and D for z
% % NUMBER of search steps for zenith of B-axis; Here, the number of search
% % steps for azimuth of B-axis is based on the zenith of B-axis.
% nzenith = 18;  %90/18=5(degree)
% % nzenith = 45; 
% % NUMBER of search steps for the rotation of P-T plane around B-axis in a
% % quadrant
% nrotation = 18; %90/18=5(degree)
% % nrotation = 45;

% % local size parameter for Weight.m
% w2 = 0.5;% relative weight for data, class II to class I
% dangle_deg = 5;% dangle is used to calculate the weight of each point by points' density
% % dangle_deg = [];% dangle is used to calculate the weight of each point by points' density
% dangle = dangle_deg*pi/180;

% range of inconsistent ratio of selected solutions 
para.incon_range = 0.01;

% minimum and maximum number of selected solutions
% para.min_number = 3;
% para.max_number = 100;
para.min_number = 1;
para.max_number = 3;
% max_number = 30;

% define maximum cluster number which is used for initial clustering
para.max_cluster_num = 3;

% define rotation angle range in order to combine cluster centers, where
% rotation angle of each two cluster centers less than RA_range will be combined.
para.RA_range = 30;


% % choose what kind of jack_knife technique: 
% % 1. no jack knife test 2. delete one arbitrary point 3. reverse one abitrary point's polarity 
% jack_knife = 'none';
% % jack_knife = 'delete';
% % jack_knife = 'reverse';

% % threshold of classifying the quality of solutions
% % class A: minimum discrepancy < DIS_good && RA_min < RA_good
% % class C: minimum discrepancy > DIS_bad || RA_max > RA_bad
% % class B: between A and C
% DIS_good = 0.15;
% DIS_bad = 0.3;
% RMS_good = 15;

% 
para.gamma = 0; % 0 for pure shear faulting
para.sigma = 0.25; % possion's ratio

end
