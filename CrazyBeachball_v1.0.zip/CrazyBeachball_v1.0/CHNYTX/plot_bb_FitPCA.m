function [  ] = plot_bb_FitPCA(hb, AZ, IH, X0, Y0, R0, tr )
%TEXTNAME Summary of this function goes here
%   Detailed explanation goes here

dx = 0.1;
dy = 0.1;
% text station name on the focal mechanism

% sort traces by azimuth
[AZ,ind] = sort(AZ,'ascend');
IH = IH(ind);
tr = tr(ind);

% colors = {'k','r','g','b','m','c'};
colors = {'r','g','b','m','c'};
ncolor = length(colors);

NN = length(AZ);
RAD = pi / 180;
AZP = RAD * AZ; 
IHP = RAD * IH;
rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xp=X0+rp.*sin(AZP); 
yp=Y0+rp.*cos(AZP);
rpt = R0 + R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xpt=X0+rpt.*sin(AZP); 
ypt=Y0+rpt.*cos(AZP);

for i = 1:NN
    axes(hb);
    line([xp(i) xpt(i)],[yp(i) ypt(i)],'linewidth',0.5,'linestyle','--','color',[.9 .9 .9]);
    axes('Position',[xpt(i)-dx/2 ypt(i)-dy/2 dx dy])
    hold on;
%     plot(tr(i).time,tr(i).data,'-','color',[rand rand rand]);
%     plot(tr(i).time,tr(i).data,'-','color',colors{mod(i-1,ncolor)+1},'linewidth',2);
    plot(tr(i).time,tr(i).data,'-','color','k','linewidth',1);
    dashline(tr(i).time,tr(i).syn,0.5,0.5,0.5,0.5,'color',colors{mod(i-1,ncolor)+1},'linewidth',1);
    ylim([-1 1]);
    axis off
    alpha(0.1);
end


end
