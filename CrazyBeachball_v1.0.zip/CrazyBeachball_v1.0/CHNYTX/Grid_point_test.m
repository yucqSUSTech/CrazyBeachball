function [fmsout]=Grid_point_test(stname , EAz , Eih , IP,NN_threshold,nzenith,nrotation,w2,dangle,discrepancy_range,min_number,max_number,max_cluster_num,RA_range,jack_knife,DIS_good,DIS_bad,RMS_good)
% ======================================================================= %
%  The main program used to invert the source mechanism solution in CHNYTX.
%
%  Written by Chunquan Yu, yucq@sustech.edu.cn 
%
%  Modified by Xianwei Zeng for CrazyBeachball, 12231216@mail.sustech.edu.cn
%                                                   2023/4/25
% ======================================================================= %
%% README
% INPUT:
% the defination of all other input parameters can be found in para.m


%% read inputfile
% [ stname , EAz , Eih , IP] = textread(inputfile,'%s %f %f %d');

% deal with polarity readings more than NN_threshold
NN=length(IP);     % NN=Total polarity readings
if NN < NN_threshold
    disp('Reading number is less than: ');disp(NN_threshold);
    return;
end
% change ray-upward points to ray-downward points, also remove data points,
% whose Eih are NaN.
temp = 1;
for i=1:NN
    if ~isnan(Eih(i)) % in case of Eih(i) is NaN. delete Eih(i) = NaN points
        if Eih(i)>90
            Eih(i)=180-Eih(i);  EAz(i)=EAz(i)+180;
            if EAz(i)>360,    EAz(i)=EAz(i)-360;    end
        end
        EAz_temp(temp,1) = EAz(i);        Eih_temp(temp,1) = Eih(i);        IP_temp(temp,1) = IP(i);
        temp = temp + 1;
    end
end
EAz = EAz_temp; Eih = Eih_temp; IP = IP_temp;


%% Calculate and store parameters of selected solutions
% calculate each points' weight. Subroutine Weight.m
[ray_weight] = Weight(EAz , Eih , IP , dangle , w2); 
% grid search for all solutions, choose selected solutions, and calculate their stress matrix and discrepancy
[ number , S_selected , discrepancy_selected_origin, discrepancy_selected_jack ] ...
    = grid_sub( EAz , Eih , IP , nzenith , nrotation , ray_weight ,discrepancy_range ,...
    min_number , max_number,jack_knife); 

disp('Lowest inconsistency ratio:'); disp(min(discrepancy_selected_origin));
disp('Number of selected solutions: ');  disp(number);

% Output FM solutions
[ SK1 DA1 SA1  SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL ] = Parameters( S_selected );

  
%% Calculate and store parameters of cluster centers
%subroutine Cluster.m;CID provides a set of n indexes indicating cluster membership for each point. NR is the number of observations in each cluster. CENTERS is a matrix, where each row corresponds to a cluster center.
[cid,nr,centers] = Cluster(S_selected,max_cluster_num,RA_range);
%subroutine Parameters.m: calculate parameters from stress matrix
[ CSK1 CDA1 CSA1  CSK2 CDA2 CSA2  CPAZ CPPL CTAZ CTPL CBAZ CBPL ] = Parameters( centers );
%subroutine INcon.m :calculate discrepancy of mean solution
center_discrepancy = INcon( centers,EAz,Eih,IP,ray_weight); 

NUM = size(centers,1); %number of cluster centers
Reliability = nr/sum(nr); % calculate the reliability of each cluster center, by the number of solutions in each cluster
[Sort_Reliability,INDEX] = sort(Reliability,'descend'); %sort Reliability, descend
RMS = zeros(1,NUM);%root mean square of rotation angle


%% polt and output selected solutions and all cluster centers
fmsout.fms = {};
fmsout.fms.sk1 = SK1;fmsout.fms.da1 = DA1;fmsout.fms.sa1 = SA1;
fmsout.fms.sk2 = SK2;fmsout.fms.da2 = DA2;fmsout.fms.sa2 = SA2;
fmsout.fms.paz = PAZ;fmsout.fms.ppl = PPL;
fmsout.fms.taz = TAZ;fmsout.fms.tpl = TPL;
fmsout.fms.baz = BAZ;fmsout.fms.bpl = BPL;
fmsout.fms.cid = cid;
fmsout.fms.disc = discrepancy_selected_origin;
if strcmp(jack_knife,'delete') || strcmp(jack_knife,'reverse')
    fmsout.fms.disc_jack = discrepancy_selected_jack;
end


for i = 1:NUM
    j = INDEX(i);
    idnm(i) = j;
    ind = find(cid==j);
    S_cluster = S_selected(ind,:); 
    RMS(j) = RA_stdev( S_cluster ); % subroutine RA_stdev.m , calculate rotation angle stdev in each cluster
    [csk1(i,1),cda1(i,1), csa1(i,1)  ,csk2(i,1) ,cda2(i,1) ,csa2(i,1)  ,cpaz(i,1) ,cppl(i,1) ,ctaz(i,1) ,ctpl(i,1) ,cbaz(i,1) ,cbpl(i,1) ,cdis(i,1) ,rms(i,1) ,rel(i,1)]=deal(CSK1(j) ,CDA1(j) ,CSA1(j)  ,CSK2(j) ,CDA2(j) ,CSA2(j)  ,CPAZ(j) ,CPPL(j) ,CTAZ(j) ,CTPL(j) ,CBAZ(j) ,CBPL(j) ,center_discrepancy(j) ,RMS(j), Reliability(j));
end
fmsout.fmsc = {};
fmsout.fmsc.sk1 = csk1;fmsout.fmsc.da1 = cda1;fmsout.fmsc.sa1 = csa1;
fmsout.fmsc.sk2 = csk2;fmsout.fmsc.da2 = cda2;fmsout.fmsc.sa2 = csa2;
fmsout.fmsc.paz = cpaz;fmsout.fmsc.ppl = cppl;
fmsout.fmsc.taz = ctaz;fmsout.fmsc.tpl = ctpl;
fmsout.fmsc.baz = cbaz;fmsout.fmsc.bpl = cbpl;
fmsout.fmsc.disc = cdis;
fmsout.fmsc.rms = rms;
fmsout.fmsc.rel = rel;
fmsout.fmsc.idnm = idnm;

end
