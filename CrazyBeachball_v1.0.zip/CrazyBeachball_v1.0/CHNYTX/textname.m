function [  ] = textname( AZ, IH, X0, Y0, R0, stname )
%TEXTNAME Summary of this function goes here
%   Detailed explanation goes here

% text station name on the focal mechanism

NN = length(AZ);
RAD = pi / 180;
AZP = RAD * AZ; 
IHP = RAD * IH;
rp = R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xp=X0+rp.*sin(AZP); 
yp=Y0+rp.*cos(AZP);
rpt = R0 + R0 * sqrt(2)*sin(IHP/2);    % Schmidt projection
xpt=X0+rpt.*sin(AZP); 
ypt=Y0+rpt.*cos(AZP);

for i = 1:NN
    line([xp(i) xpt(i)],[yp(i) ypt(i)],'linewidth',0.5,'linestyle','--','color',[.9 .9 .9]);
    text(xpt(i),ypt(i),char(stname(i)),'Fontsize',8);
end


end
