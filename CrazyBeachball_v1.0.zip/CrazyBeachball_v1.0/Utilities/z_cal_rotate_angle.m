function rotate_angle = z_cal_rotate_angle(s1,s2)
% ======================================================================= %
% calculate the rotation angle of the pbt coordinate system for two 
% focal mechanism solutions.
%
% required subfunction:
%        z_sdr2pbt()
%        z_mij2pbt()
% ======================================================================= %
% example:
%        z_cal_rotate_angle([strike1,dip1,rake1],[strike2,dip2,rake2])
%        z_cal_rotate_angle([m1_11,m1_12,m1_13,m1_22,m1_23,m1_33],
%                           [m2_11,m2_12,m2_13,m2_22,m2_23,m2_33])
%        z_cal_rotate_angle([m1_11,m1_12,m1_13;m1_21,m1_22,m1_23;m1_31,m1_32,m1_33],
%                           [m2_11,m2_12,m2_13;m2_21,m2_22,m2_23;m2_31,m2_32,m2_33])
%   
%                                         Xianwei Zeng  2022/11/3
% ======================================================================= %
[p1,b1,t1] = s2pbt(s1);
[p2,b2,t2] = s2pbt(s2);

[ array ] = sort([ p1*p2', b1*b2' , t1*t2' ],'descend');
trA = array(1)+abs(array(2)+array(3));
c_RA = (trA-1)/2;  %trA = 1 + 2*cos(rotate_angle)
rotate_angle = rad2deg(acos(c_RA));


function [p,b,t] = s2pbt(s)
    [row,column] = size(s);
    if (row==1&&column==3)||(row==3&&column==1)
        [p,b,t] = z_sdr2pbt(s,2);
    else
        [p,b,t] = z_mij2pbt(s,2);
    end
end
end