function [AZ,PL] = z_xyz2AzPL(varargin) %  (V) or (x,y,z)
% ======================================================================= %
%    Input must be degree
% ======================================================================= %
%-- Find Az & ih of an axis from its direction cosines ---
%  Az is from North clockwise positive
%  PL(plunge)-between horizontal plane & Down-ray
%  for lower hemisphere
%  
% example:
%       xyz2AzPL([x y z]) or xyz2AzPL(x,y,z)
%                                                         ZengXW 2022/9/5
% ======================================================================= %
if nargin==1
    V = varargin{1};
elseif nargin==3
    V = [varargin{1} varargin{2} varargin{3}];
else
    error('Input parameter error!')
end

rad=pi/180;
if V(3)<0
    V = -V;
end
AZ=atan2(V(2),V(1))/rad;
if AZ<0
    AZ=AZ+360; 
end
PL = 90 - atan2(sqrt(V(1)^2+V(2)^2),V(3))/rad;
end
