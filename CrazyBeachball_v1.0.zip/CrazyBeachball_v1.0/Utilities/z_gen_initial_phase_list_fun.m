function z_gen_initial_phase_list_fun(evlist,vmodel,phase,channel_file)
% ======================================================================= %
% The function is used to generate an initial seismic phase list.
% 
%                                               Xianwei Zeng           
%                                                2024/06/01
% ======================================================================= %
    fid = fopen(evlist,'r');
    C = textscan(fid,'%s %*[^\n]','CommentStyle','#');
    fclose(fid);
    events = C{1};
    
    em = set_vmodel_v3_0 ( vmodel );
    np = 200;
    xdep = 660;
    pfm_r0 = 0.5;
    pfm_x0 = 0;
    pfm_y0 = 0;
    r2d = 180/pi;
    
    nev = length(events);

    for iev = 1 : nev
        fprintf('Processing %d/%d\n',iev,nev);
        if ~exist(events{iev},'dir') || ~exist(fullfile(events{iev},channel_file),'file')
            fprintf('No data in %s\n',events{iev});
            continue
        end
    
        fid = fopen(fullfile(events{iev},channel_file),'r');
        C = textscan(fid,'%s %*[^\n]','CommentStyle','#');
        fclose(fid);
        lists = C{1};
    
        fid0 = fopen(fullfile(events{iev},[channel_file '_' phase '.txt']),'w');
        fprintf(fid0,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz snr0 xcoeff0 take-off_angle pol_x0 pol_y0 first_arrival_P-phase polarity_quality\n');
    
        num = 0;
        for ist = 1 : length(lists)
            if ~exist(fullfile(events{iev},lists{ist}),'file')
                fprintf('No file %s found!\n',fullfile(events{iev},lists{ist}));
                continue
            end
    
            sachd = irdsachd(fullfile(events{iev},lists{ist}));
    
            [dist,baz] = distance(sachd.stla,sachd.stlo,sachd.evla,sachd.evlo,[6378.137*180/pi/6371 0.0818191908426215]); %WGS84 reference ellipsoid
            az = azimuth(sachd.evla,sachd.evlo,sachd.stla,sachd.stlo,[6378.137*180/pi/6371 0.0818191908426215]); %WGS84 reference ellipsoid
    
            if num==0 || sachd.evdp~=evdp
                num = 1;
                evdp = sachd.evdp;
                if evdp >= 999
                    fprintf('Evdp >= 999! Please check event depth. Depth units should be km!\n');
                    fprintf('Divide event depth by 1000!\n');
                    evdp = evdp/1000; % if evdp>999, convert m to km
                end
                
                [rayp,taup,Xp] = phase_taup(phase,evdp,np,em,xdep);
                t1 = taup + rayp.* Xp;
                d1 = Xp*r2d;
                
                [ rayp, d1, t1 ] = y_firstarrival_interp( rayp, d1, t1 );
                
                rayp = rayp/(pi*6371/180)/r2d;
                d1 = rem(d1,360);
                ind_major = find(d1>180);
                d1(ind_major) = 360-d1(ind_major);
    
                vz = find_vz_interp(em.z,em.vp,evdp);
    
                [p_Pg,t_Pg,d_Pg] = phase_taup('Pg',evdp,np,em,xdep);
                t_Pg = t_Pg + p_Pg.*d_Pg;
                d_Pg = d_Pg * r2d;
            
                [p_Pn,t_Pn,d_Pn] = phase_taup('Pn',evdp,np,em,xdep);
                t_Pn = t_Pn + p_Pn.*d_Pn;
                d_Pn = d_Pn * r2d;
            
                [p_P,t_P,d_P] = phase_taup('P',evdp,np,em,xdep);
                t_P = t_P + p_P.*d_P;
                d_P = d_P * r2d;
            
                [ p_Pg2, d_Pg2, t_Pg2 ] = y_firstarrival_interp( p_Pg, d_Pg, t_Pg );
            end
    
            tt_Pg = interp1db(dist, d_Pg2,t_Pg2 );
            tt_Pn = interp1db(dist, d_Pn ,t_Pn);
            tt_P  = interp1db(dist, d_P  ,t_P );
            
            [~,idx] = min([tt_Pg,tt_Pn,tt_P]);
    
            if idx==1
                Pphase = 'Pg';
                tt_Pg2 = interp1db(dist,d_Pg(1:np),t_Pg(1:np));
                rayp0  = interp1db(dist,d_Pg2,p_Pg2);
    
                if isnan(tt_Pg2) || round(tt_Pg2,4)>round(tt_Pg,4)
                    takeoff = asind(min(rayp0/(em.re-evdp)*vz,1));
                else
                    takeoff = 180-asind(min(rayp0/(em.re-evdp)*vz,1));
                end
            elseif idx==2
                Pphase = 'Pn';
                rayp0 = interp1db(dist,d_Pn,p_Pn);
                takeoff = asind(min(rayp0/(em.re-evdp)*vz,1));
            else
                Pphase = 'P';
                rayp0 = interp1db(dist,d_P,p_P);
                takeoff = asind(min(rayp0/(em.re-evdp)*vz,1));
            end
    
            if takeoff>90
                cal_takeoff = 180-takeoff ;
                cal_az      = az-180;
            else
                cal_takeoff = takeoff ;
                cal_az      = az;
            end
    
            rp = pfm_r0 .* sqrt(2).*sin(pi./180.*cal_takeoff./2);
            pol_x0 = pfm_x0+rp.*sind(cal_az); 
            pol_y0 = pfm_y0+rp.*cosd(cal_az);
                
            tt = interp1db(dist,d1,t1);
            st_p = interp1db(dist,d1,rayp);
    
            fprintf(fid0,'%s %f %f %f 1 %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s I\n',...
                lists{ist},tt,0.0,tt,deblank(reshape(sachd.kstnm,1,[])),...
                deblank(reshape(sachd.knetwk,1,[])),st_p,...
                sachd.stla,sachd.stlo,sachd.stel,...
                sachd.evla,sachd.evlo,sachd.evdp,...
                dist,az,baz,1.0,1.0,takeoff,pol_x0,pol_y0,Pphase);
        end
        fclose(fid0);
    end
end