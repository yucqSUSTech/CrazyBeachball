function [p,b,t] = z_sdr2pbt(varargin) %(strike,dip,rake,mode)
% ======================================================================= %
% For all coordinate system:
%                              x: North
%                              y: East
%                              z: Vertical
%  Required subfunctions:
%                          xyz2AzIh.m
%  mode:
%  if mode is equal to 1, the output is spherical coordinates (AZ and IH)
%  if mode is equal to 2, the output is Cartesian coordinates (X, Y ,Z)
%  if mode is equal to 1, the output is spherical coordinates (AZ and PL)
%  
% ======================================================================= %
%
% Example:
%           z_sdr2pbt(strike,dip,rake)
%     or    z_sdr2pbt(strike,dip,rake,1);
%     or    z_sdr2pbt(strike,dip,rake,2);
%     or    z_sdr2pbt(strike,dip,rake,3);
%
%                                                Xianwei Zeng  2021/9/5
% ======================================================================= %

if nargin==1
    sdr = varargin{1};
    strike = sdr(1);dip = sdr(2); rake = sdr(3);
    mode = 1;
elseif nargin==2
    sdr = varargin{1};
    strike = sdr(1);dip = sdr(2); rake = sdr(3);
    mode = varargin{2};
elseif nargin==3
    strike = varargin{1};dip = varargin{2}; rake = varargin{3};
    mode = 1;
elseif nargin==4
    strike = varargin{1};dip = varargin{2}; rake = varargin{3};
    mode = varargin{4};
else
    error('Input parameter error!')
end

deg2rad = pi/180;
strike = strike*deg2rad;
dip = dip*deg2rad;
rake = rake*deg2rad;

n1 = -sin(dip)*sin(strike);
n2 = sin(dip)*cos(strike);
n3 = -cos(dip);

d1 = (cos(rake)*cos(strike)+sin(rake)*cos(dip)*sin(strike));
d2 = cos(rake)*sin(strike)-sin(rake)*cos(dip)*cos(strike);
d3 = -sin(rake)*sin(dip);

% p = n - d
p(1) = n1-d1;
p(2) = n2-d2;
p(3) = n3-d3;

% t = -(n+d)
t(1) = n1+d1;
t(2) = n2+d2;
t(3) = n3+d3;

% b = n x d
b = cross([n1 n2 n3],[d1 d2 d3]);

p = p/sqrt(sum(p.^2));
t = -t/sqrt(sum(t.^2));

if mode==1 % out azmuith and takeoff angle
    [Az,Ih] = z_xyz2AzIh(b);    b = [Az,Ih];
    [Az,Ih] = z_xyz2AzIh(p);    p = [Az,Ih];  
    [Az,Ih] = z_xyz2AzIh(t);    t = [Az,Ih];
elseif mode==2
    return
elseif mode==3
    [Az,Ih] = z_xyz2AzPL(b);    b = [Az,Ih];
    [Az,Ih] = z_xyz2AzPL(p);    p = [Az,Ih];  
    [Az,Ih] = z_xyz2AzPL(t);    t = [Az,Ih];
else

    error('Input mode error!')
end

end