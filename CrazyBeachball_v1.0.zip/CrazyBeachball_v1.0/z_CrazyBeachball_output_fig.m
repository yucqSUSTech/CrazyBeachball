function z_CrazyBeachball_output_fig

path = './data_demo/fms_data';
figpath = './fms_output/fig_demo';

if ~exist(figpath,'dir')
    mkdir(figpath)
end

dirs = dir(path);
dirs = {dirs.name};

for i = 1 : length(dirs)
    f_jpg = dir(fullfile(path,dirs{i},'*.jpg'));
    f_pdf = dir(fullfile(path,dirs{i},'*.pdf'));
    f_png = dir(fullfile(path,dirs{i},'*.png'));

    if ~isempty(f_jpg)
        f_jpg = {f_jpg.name};
        for j = 1 : length(f_jpg)
            copyfile(fullfile(path,dirs{i},f_jpg{j}),figpath)
        end
    end
    if ~isempty(f_pdf)
        f_pdf = {f_pdf.name};
        for j = 1 : length(f_pdf)
            copyfile(fullfile(path,dirs{i},f_pdf{j}),figpath)
        end
    end
    if ~isempty(f_png)
        f_png = {f_png.name};
        for j = 1 : length(f_png)
            copyfile(fullfile(path,dirs{i},f_png{j}),figpath)
        end
    end
end

end