CN：
CrazyBeachball中提供的HASH_v1.2对原始HASH做了略微修改，
主要是增加了路径的字符长度。
注意：
    如果在编译的过程中出现在‘uncert_subs.f’中的‘rota’变量报错的情况，
可以考虑将‘uncert_subs_v2.f’替换为‘uncert_subs.f’后重新编译。

原版HASH可以从以下链接获取：
    https://www.usgs.gov/node/279393

EN:
The version of HASH (v1.2) provided in CrazyBeachball includes 
slight modifications to the original HASH, primarily increasing 
the character length allowed for file paths.
Note: 
    If an error occurs related to the 'rota' variable in 
'uncert_subs.f' during compilation, consider replacing 'uncert_subs.f'
with 'uncert_subs_v2.f' and recompiling.

The original HASH can be obtained from the following link:
    https://www.usgs.gov/node/279393