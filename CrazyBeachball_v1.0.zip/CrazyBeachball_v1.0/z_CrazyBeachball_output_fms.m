function z_CrazyBeachball_output_fms

path = './data_demo/fms_data';
svpath = './fms_output';

svfile = 'fms_list_demo.txt';

if ~exist(svpath,'dir')
    mkdir(svpath);
end

dirs = dir(path);
dirs = {dirs.name};

% dirs = dir(fullfile(path,'2021*'));
% dirs = {dirs.name};


fid0 = fopen(fullfile(svpath,svfile),'w');
fprintf(fid0,'# num year mon day hour min sec lat lon dep mag method1 strike1 dip1 rake1 strike_auxiliary1 dip_auxiliary1 rake_auxiliary1 quality1 method2 strike2 dip2 rake2 quality2 rotation_angle2 quality_final\n');
idx = 1;
for i = 1 : length(dirs)
    if ~exist(fullfile(path,dirs{i}),'dir')
        continue
    end
    file = fullfile(path,dirs{i},'focal_mechanism_solutions.txt');
    if exist(file,'file')
        fid = fopen(file);
        fgetl(fid);fgetl(fid);fgetl(fid);
        line = replace(fgetl(fid),'#',num2str(idx,'%d'));
        strs = split(line);
        if length(strs)<23
            line = [line ' NaN NaN NaN NaN NaN NaN ' strs{end}];
        end
        idx = idx + 1;
        fprintf(fid0,[line '\n']);
        fclose(fid);
    end
end
fclose(fid0);
end