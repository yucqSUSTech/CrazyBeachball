function z_add_polarity_to_dir()
% ======================================================================= %
% This script is used to write P-wave first-motion polarity data into 
% phase files (e.g., 'list_z_PF.txt'). 
% 
% The polarity data can be obtained using deep learning methods or other 
% approaches. You can then use the 'z_gen_initial_phase_list.m' program 
% to generate phase files for each event. Finally, this script writes 
% the polarity data into the corresponding phase files.
% 
% Input file (polarity file):
%   event line: # year mon day hour min sec evla evlo evdp evmg eh ez rms num
%   phase line: network station polarity quality phase_type
%
%                                              Xianwei Zeng, 2024/12/03
% ======================================================================= %


%%% event list for Crazybeachball
evlist_file = './evs_info/fms_demo_evlist.txt'; 
%%% polarity file
pol_file = './evs_info/evs_polarity.txt';

%%% reference phase
phase = 'PF';
%%% filename list
channel_file = 'list_z';
%%% phase file
phase_file = [channel_file '_' phase '.txt'];

ev_dir_name = 1; 
%%% 1 -> YYMMDDTmmhhssZ
% for example: 
% event line: # 2011 03 23 15 34 18.742 23.52364 99.15353 7.262 3.6 0 0 0 1
% event dir: 20110323T153418Z
%%% 2 -> evid
% event line: # 2011 03 23 15 34 18.742 23.52364 99.15353 7.262 3.6 0 0 0 1
% event dir: 1


fid = fopen(evlist_file);
evlist = textscan(fid,'%s','CommentStyle','#');
evlist = evlist{1};
fclose(fid);

pol = {};
fid = fopen(pol_file);
while ~feof(fid)
    if ev_dir_name==1
        line = fgetl(fid);
        if ~isempty(line) && strcmp(line(1),'#')
            strs = split(line);
            evid = sprintf('ev%s%02s%02sT%02s%02s%02dZ',strs{2},strs{3},strs{4},strs{5},strs{6},floor(str2double(strs{7})));
            pol.(evid) = {};
        else
            strs = split(line);
            ntst = [strs{1} '_' strs{2}];
            pol.(evid).(ntst).nt = strs{1};
            pol.(evid).(ntst).st = strs{2};
            pol.(evid).(ntst).pol = strs{3};
            pol.(evid).(ntst).q = strs{4};
            pol.(evid).(ntst).type = strs{5};
        end
    else
        line = fgetl(fid);
        if strcmp(line{1},'#')
            strs = split(line);
            evid = ['ev' strs{end}];
            pol.(evid) = {};
        else
            pol.(evid).ntst = [strs{1} '_' strs{2}];
            pol.(evid).ntst.nt = strs{1};
            pol.(evid).ntst.st = strs{2};
            pol.(evid).ntst.pol = strs{3};
            pol.(evid).ntst.q = strs{4};
            pol.(evid).ntst.type = strs{5};
        end
    end
end

dirs = fieldnames(pol);
nev = length(evlist);
for iev = 1 : nev
    evpath = evlist{iev};
    [~,evdir] = fileparts(evpath);
    fprintf('Processing %s (%d/%d)\n',evdir,iev,nev);
    evdir = ['ev' evdir];
    if ~ismember(evdir,dirs) || ~exist(fullfile(evpath,phase_file),'file')
        continue
    end
    ntsts = fieldnames(pol.(evdir));

    write_line = {};
    fid = fopen(fullfile(evpath,phase_file),'r');
    write_line{1} = fgetl(fid);
    idx = 2;
    while ~feof(fid)
        line = fgetl(fid);
        strs = split(line);
        ntst = [strs{7} '_' strs{6}];
        if ~ismember(ntst,ntsts)
            continue
        end
        write_line{idx} = sprintf(...
            '%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',...
            strs{1},strs{2},strs{3},strs{4},pol.(evdir).(ntst).pol,strs{6},...
            strs{7},strs{8},strs{9},strs{10},strs{11},strs{12},...
            strs{13},strs{14},strs{15},strs{16},strs{17},strs{18},...
            strs{19},strs{20},strs{21},strs{22},pol.(evdir).(ntst).type,pol.(evdir).(ntst).q);
        idx = idx + 1;
    end
    fclose(fid);
    fid = fopen(fullfile(evpath,phase_file),'w');
    for ist = 1 : length(write_line)
        fprintf(fid,'%s\n',write_line{ist});
    end
    fclose(fid);
end
fprintf('Done!\n');
end