function z_CrazyBeachball_Main_v1_0()
% ======================================================================= %
%                                                                         %
%                         CrazyBeachball_v1.0                             %
%                                                                         %
% -- A MATLAB-GUI-based software for focal mechanism solution inversion   %
%                                                                         %
% Main script: CrazyBeachball_Main.m                                      %
% Subpackage: Utilities, CHNYTX, and HASH                                 %
%                                                                         %
% Purposes: (1) Waveform visualization                                    %
%           (2) Picking up the polarity                                   %
%           (3) Inversion and evaluation of focal mechanism solutions     %
%                                                                         %
% Features: (1) Easy to use                                               %
%           (2) Efficient                                                 %
%           (3) Quality control                                           %
%                                                                         %
% Usage: Run the following code in the command line window of MATLAB      %
%       >> CrazyBeachball_Main       % Open the main interface            %
%                                                                         %
% Written by Xianwei Zeng and Chunquan Yu.                                %
%                                                                         %
% Contact:                                                                %
%         12231216@mail.sustech.edu.cn                                    %
%         yucq@sustech.edu.cn                                             %
%                                                                         %
%                                                        2023/4/25        %
%                                                                         %
% References:                                                             %
% Zeng, X., and Yu C. (2025). 'CrazyBeachball: A MATLAB GUI-Based Software Package for Focal Mechanism Inversion ocal Mechanism Inversion.' Earthquake Science.
% Yu, C., Zheng, Y., Shang, X., 2017. Crazyseismic: A MATLAB GUI-Based Software Package for Passive Seismic Data Preprocessing. Seismological Research Letters 88, 410?415. doi:10.1785/0220160207
% Yu, C., et al. (2009). 'P-wave first-motion focal mechanism solutions and their quality evaluation.' Chinese Journal of Geophysics 52(5): 1402-1411. doi: 10.3969/j.issn.0001-5733.2009.05.030
% Hardebeck, J. L. and P. M. Shearer (2002). 'A new method for determining first-motion focal mechanisms.' Bulletin of the Seismological Society of America 92(6): 2264-2276. doi: https://doi.org/10.1785/0120010200
%                                                                         %
% ======================================================================= %

%% add path
path(path,genpath(pwd));

%% Import parameters
para = para_FMS;
tr = [];

%% Main program
%% Main figure setup
handle.f1               =	figure('Toolbar','figure','Units','normalized','keypressfcn', @Pick_short_cut,'Position',[.1 .1 .8 .8]);
                            set(handle.f1,'name','CrazyBeachball','NumberTitle','off');
handle.zoom             =   zoom(handle.f1);
handle.zoom.Enable      =   para.zoom;
handle.hax              =	axes('pos', [.2 .05 .45 .85]);
                            box(handle.hax,'on');
handle.h_hot            =	uicontrol('String','<html><b>CrazyBeachball</b></html>','keypressfcn',@Pick_short_cut,'Position',[.01 .91 .15 .08]);

%% plot focal mechanism solution panel
pfm_panel               =	uipanel('parent', handle.f1,'title', 'Plot FMS', 'Position', [0.71 .415 .28 .13]);
handle.pfm              =   axes(handle.f1,'pos', [.71 .55 .28 .44]);
                            set(handle.pfm,'Xticklabel',[],'Yticklabel',[],'Xtick',[],'Ytick',[])
                            box(handle.pfm,'on');
pfm_height = 0.33;
handle.pfm_plot_pol     =   uicontrol(pfm_panel,'Style','pushbutton','String','Plot_pol','callback',@pfm_callback_iniplot,'Position',[.0083 .67 .195 pfm_height]);
handle.pfm_pol_select_one   ...
                        =   uicontrol(pfm_panel,'Style','pushbutton','String','Select_pol','callback',@pfm_callback_select_one_pol,'Position',[.2066 .67 .195 pfm_height]);
handle.pfm_CHNYTX_cal   =   uicontrol(pfm_panel,'Style','pushbutton','String','CHNYTX(c)','callback',@pfm_callback_CHNYTX_cal_plot,'Position',[0.4049 .67 .195 pfm_height]);
% handle.pfm_HASH_cal     =   uicontrol(pfm_panel,'Style','pushbutton','String','HASH(h)','callback',@pfm_callback_HASH_cal_plot,'Position',[0.6032 .67 .195 pfm_height]);
handle.pfm_HASH_cal     =   uicontrol(pfm_panel,'Style','popupmenu','String',{'HASH1(h)','HASH2(h)'},'Callback',@pfm_callback_HASH_cal_list,'Position',[0.6032 .67 .195 pfm_height]);

handle.pfm_cal_two_method   ...
                        =   uicontrol(pfm_panel,'Style','pushbutton','String','TWO(t)','callback',@pfm_callback_cal_TWO_method,'Position',[0.8015 .67 .19 pfm_height]);
                            uicontrol(pfm_panel,'Style','pushbutton','String','Clear_pol','callback',@pfm_callback_clear,'Position',[.0083 .01 .195 pfm_height]);
handle.h_gpick          =   uicontrol(pfm_panel,'String','Gpick','callback',@Pick_callback_gpick,'Position',[0.2066 .34 .195 pfm_height]);
handle.pfm_CHNYTX_auto  =   uicontrol(pfm_panel,'Style','togglebutton','String','If_auto(C)','Value',para.pfm_CHNYTX_auto,'callback',@pfm_callback_CHNYTX_auto_cal,'Position',[0.4049 .34 .195 pfm_height]);
handle.pfm_HASH_auto    =   uicontrol(pfm_panel,'Style','togglebutton','String','If_auto(H)','Value',para.pfm_HASH_auto,'callback',@pfm_callback_HASH_auto_cal,'Position',[0.6032 .34 .195 pfm_height]);
handle.pfm_TWO_auto     =   uicontrol(pfm_panel,'Style','togglebutton','String','If_auto(T)','Value',para.pfm_TWO_auto,'callback',@pfm_callback_TWO_auto_cal,'Position',[0.8015 .34 .19 pfm_height]);
handle.pfm_auto_plot_pol ...
                        =   uicontrol(pfm_panel,'Style','togglebutton','String','If_auto(P)','callback',@pfm_callback_auto_plot,'Position',[.0083 .34 .195 pfm_height]);
handle.pfm_show_select_nm   ...
                        =   uicontrol(pfm_panel,'Style','togglebutton','String','Show_nm','callback',@pfm_callback_show_select_nm,'Position',[0.2066 .01 .195 pfm_height]);
                            uicontrol(pfm_panel,'Style','pushbutton','String','Clear(C)','callback',@pfm_callback_clear_CHNYTX,'Position',[0.4049 .01 .195 pfm_height]);
                            uicontrol(pfm_panel,'Style','pushbutton','String','Clear(H)','callback',@pfm_callback_clear_HASH,'Position',[0.6032 .01 .195 pfm_height]);
                            uicontrol(pfm_panel,'Style','pushbutton','String','Clear(T)','callback',@pfm_callback_clear_TWO,'Position',[0.8015 .01 .19 pfm_height]);

%% pbt figure setup 
handle.pbt              =   axes(handle.f1,'pos',[.71 .05 .156 .255]);
                            set(handle.pbt,'Xticklabel',[],'Yticklabel',[],'Xtick',[],'Ytick',[])
                            box(handle.pbt,'on'); %axis(handle.pbt,'equal')
                            xlim(handle.pbt,para.pbt_xlim);ylim(handle.pbt,para.pbt_xlim)

%% Plot waveform panel
plot_panel              =	uipanel('parent', handle.f1,'title', 'Plot waveform', 'Position', [0.01 .26 .15 .64]);
                            uicontrol(plot_panel,'String','Ini(i)','callback',@Pick_callback_iniplot,'Position',[.05 .90 .5 .1]);
handle.h_vmodel_list    =   uicontrol(plot_panel,'Style','popupmenu','String',para.vmodel_list,'callback',@Pick_callback_vmodel,'Value',1,'Position',[.55 .9525 .45 .038]);
ind = find(strcmp(para.intederi_list,para.intederi_type));
if ~ind
    fprintf('No intederi type %s in the list\n',para.intederi_type); return;
end
handle.h_intederi_list  =   uicontrol(plot_panel,'Style','popupmenu','String',para.intederi_list,'callback',@Pick_callback_intederi,'Value',ind,'Position',[.55 .905 .45 .038]);
ind = find(strcmp(para.phaselist,para.phase));
if ~ind
    fprintf('No phase %s in the list\n',para.phase); return;
end
                            uicontrol(plot_panel,'Style','text','String','Phase','Position',[.0 .85 .4 .04]);
handle.h_phase_list     =   uicontrol(plot_panel,'Style','popupmenu','String',para.phaselist,'callback',@Pick_callback_choosephase,'Value',ind,'Position',[.4 .85 .4 .04]);
handle.h_mark_show      =   uicontrol(plot_panel,'Style','togglebutton','String','Mark','callback',@Pick_callback_markphase,'Position',[.80 .80 .2 .04]);
handle.h_mark_phase     =   uicontrol(plot_panel,'Style','listbox','String',para.phaselist,'Position',[.80 .45 .2 .35],'max',1000);
                            uicontrol(plot_panel,'Style','text','String','All','Position',[.80 .4 .1 .035]);
handle.h_mark_all       =   uicontrol(plot_panel,'Style','checkbox','callback',@Pick_callback_markphase,'Position',[.90 .40 .1 .04]);
handle.h_textpara       =   uicontrol(plot_panel,'Style','togglebutton','String','Text','callback',@Pick_callback_textpara,'Position',[.80 .85 .2 .04]);
ind = find(strcmp(para.sortlist,para.sort_type));
if ~ind
    fprintf('No sort_type %s in the list\n',para.sort_type); return;
end
                            uicontrol(plot_panel,'Style','text','String','Sort','Position',[.0 .80 .4 .04]);
handle.h_sort_list      =   uicontrol(plot_panel,'Style','popup','String',para.sortlist,'callback',@Pick_callback_sort,'Value',ind,'Position',[.4 .80 .4 .04]);

ind = find(strcmp(para.plotype_list,para.plot_type));
if ~ind
    fprintf('No plot_type %s in the list\n',para.plot_type); return;
end
                            uicontrol(plot_panel,'Style','text','String','Ptype','Position',[.0 .75 .4 .04]);
handle.h_plotype_list   =   uicontrol(plot_panel,'Style','popup','String',para.plotype_list,'callback',@Pick_callback_plotype,'Value',ind,'Position',[.4 .75 .4 .04]);

ind = find(strcmp(para.normtype_list,para.norm_type));
if ~ind
    fprintf('No norm_type %s in the list\n',para.norm_type); return;
end
                            uicontrol(plot_panel,'Style','text','String','Norm','Position',[.0 .70 .4 .04]);
handle.h_normtype_list  =   uicontrol(plot_panel,'Style','popup','String',para.normtype_list,'callback',@Pick_callback_norm,'Value',ind,'Position',[.4 .70 .4 .04]);

                            uicontrol(plot_panel,'Style','text','String','Ntrace','Position',[.0 .65 .4 .04]);
handle.h_ntrace_num     =   uicontrol(plot_panel,'Style','edit','String',num2str(para.n_per_frame),'callback',@Pick_callback_tracenumber,'Position',[.4 .65 .4 .04],'BackgroundColor',para.bcolor);

                            uicontrol(plot_panel,'Style','text','String','Delta','Position',[.0 .60 .4 .04]);
handle.h_delta          =   uicontrol(plot_panel,'Style','edit','String',num2str(para.delta),'callback',@Pick_callback_delta,'Position',[.4 .6 .4 .04],'BackgroundColor',para.bcolor);

                            uicontrol(plot_panel,'Style','pushbutton','String','Filter','callback',@Pick_callback_filter,'Position',[.05 .55 .3 .04]);

ind = find(strcmp(para.filtertype_list,para.filter_type));
if ~ind
    fprintf('No filter_type %s in the list\n',para.filter_type); return;
end
handle.h_filter_type    =   uicontrol(plot_panel,'Style','popup','String',para.filtertype_list,'Value',ind,'Position',[.4 .55 .4 .04]);
                            uicontrol(plot_panel,'Style','text','String','Lowf','Position',[.0 .50 .4 .04]);
handle.h_filter_fl      =   uicontrol(plot_panel,'Style','edit','String',num2str(para.fl),'Position',[.4 .50 .4 .04],'BackgroundColor',para.bcolor);
                            uicontrol(plot_panel,'Style','text','String','Highf','Position',[.0 .45 .4 .04]);
handle.h_filter_fh      =   uicontrol(plot_panel,'Style','edit','String',num2str(para.fh),'Position',[.4 .45 .4 .04],'BackgroundColor',para.bcolor);
                            uicontrol(plot_panel,'Style','text','String','Order','Position',[.0 .40 .4 .04]);
handle.h_order          =   uicontrol(plot_panel,'Style','edit','String',num2str(para.order),'Position',[.4 .40 .4 .04],'BackgroundColor',para.bcolor);

                            uicontrol(plot_panel,'Style','text','String','Amplitude','Position',[.2 .35 .6 .04]);
                            uicontrol(plot_panel,'String','+(=)','callback',@Pick_callback_ampup,'Position',[.05 .30 .45 .05]);
                            uicontrol(plot_panel,'String','-(-)', 'callback',@Pick_callback_ampdown,'Position',[.5 .30 .45 .05]);

                            uicontrol(plot_panel,'Style','text','String','Zoom','Position',[.2 .26 .6 .04]);
                            uicontrol(plot_panel,'String','In([)','callback',@Pick_callback_timeup,'Position',[.05 .21 .45 .05]);
                            uicontrol(plot_panel,'String','Out(])', 'callback',@Pick_callback_timedown,'Position',[.5 .21 .45 .05]);

handle.theoplot_button  =   uicontrol(plot_panel,'Style','togglebutton','String','Theo_T','callback',@Pick_callback_theoplot,'Position',[.05 .16 .9 .04]);

handle.polarity         =	uicontrol(plot_panel,'Style','pushbutton','String','+/- (f)','callback',@Pick_callback_polarity,'Position',[.05 .11 .9 .04]);

handle.xy_button        =   uicontrol(plot_panel,'Style','togglebutton','String','X<->Y','callback',@Pick_callback_xyswitch,'Position',[.05 .06 .9 .04]);

handle.even_button      =   uicontrol(plot_panel,'Style','togglebutton','String','Even (e)','callback',@Pick_callback_even,'Position',[.05 .01 .9 .04]);

%% Window panel
win_panel               =   uipanel('parent', handle.f1,'title', 'Win', 'pos', [0.01 .05 .15 .2]);
                            uicontrol(win_panel,'Style','pushbutton','callback',@Pick_callback_window,'String','Window update','Position',[.05 .83 .9 .15]);
                            uicontrol(win_panel,'Style','text','String','Data','Position',[.0 .65 .3 .15]);
handle.h_timewin_L      =   uicontrol(win_panel,'Style','edit','String',num2str(para.timewin(1)),'Position',[.3 .65 .34 .15],'BackgroundColor',para.bcolor);
handle.h_timewin_R      =   uicontrol(win_panel,'Style','edit','String',num2str(para.timewin(2)),'Position',[.65 .65 .34 .15],'BackgroundColor',para.bcolor);

                            uicontrol(win_panel,'Style','text','String','Xlim','Position',[.0 .5 .3 .15]);
handle.h_xlim_L         =   uicontrol(win_panel,'Style','edit','String',num2str(para.x_lim(1)),'Position',[.3 .5 .34 .15],'BackgroundColor',para.bcolor);
handle.h_xlim_R         =   uicontrol(win_panel,'Style','edit','String',num2str(para.x_lim(2)),'Position',[.65 .5 .34 .15],'BackgroundColor',para.bcolor);

                            uicontrol(win_panel,'Style','text','String','Signal','Position',[.0 .35 .3 .15]);
handle.h_signalwin_L    =   uicontrol(win_panel,'Style','edit','String',num2str(para.signalwin(1)),'Position',[.3 .35 .34 .15],'BackgroundColor',para.bcolor);
handle.h_signalwin_R    =   uicontrol(win_panel,'Style','edit','String',num2str(para.signalwin(2)),'Position',[.65 .35 .34 .15],'BackgroundColor',para.bcolor);

                            uicontrol(win_panel,'Style','text','String','Noise','Position',[.0 .2 .3 .15]);
handle.h_noisewin_L     =   uicontrol(win_panel,'Style','edit','String',num2str(para.noisewin(1)),'Position',[.3 .2 .34 .15],'BackgroundColor',para.bcolor);
handle.h_noisewin_R     =   uicontrol(win_panel,'Style','edit','String',num2str(para.noisewin(2)),'Position',[.65 .2 .34 .15],'BackgroundColor',para.bcolor);

                            uicontrol(win_panel,'Style','text','String','Norm','Position',[.0 .05 .3 .15]);
handle.h_normwin_L      =   uicontrol(win_panel,'Style','edit','String',num2str(para.normwin(1)),'Position',[.3 .05 .34 .15],'BackgroundColor',para.bcolor);
handle.h_normwin_R      =   uicontrol(win_panel,'Style','edit','String',num2str(para.normwin(2)),'Position',[.65 .05 .34 .15],'BackgroundColor',para.bcolor);

%% input panel
in_pane                 =   uipanel('parent', handle.f1,'title', 'Input', 'pos', [0.71 .315 .28 .1]);

handle.h_evlist         =   uicontrol(in_pane,'Style','edit','String',para.evlistname,'callback',@Pick_callback_load_evlist_2,'Position',[.02 .55 .316 .45],'BackgroundColor',para.bcolor);
                            uicontrol(in_pane,'callback',@Pick_callback_load_evlist,'String','Load evlist','Position',[.02 .02 .316 .45]);

handle.h_listname       =   uicontrol(in_pane,'Style','edit','String',para.listname,'callback',@Pick_callback_load_listname_2,'Position',[.342 .55 .316 .45],'BackgroundColor',para.bcolor);
                            uicontrol(in_pane,'Style','pushbutton','String','Load listname','callback',@Pick_callback_load_listname,'Position',[0.342 .02 .316 .45]);

handle.h_copyphasefile  =   uicontrol(in_pane,'Style','edit','String',para.copylistapp,'Position',[.664 .55 .316 .45],'BackgroundColor',para.bcolor);
                            uicontrol(in_pane,'Style','pushbutton','String','Copy list','callback',@Pick_callback_copyphasefile,'Position',[0.664 .02 .316 .45]);
%% output panel
out_panel                =   uipanel('parent', handle.f1,'title', 'Output', 'pos', [.87 .048 .12 .266]);

                            uicontrol(out_panel,'Style','pushbutton','String','Delete(Ctrl+d)','callback',@Pick_callback_del_event,'Position',[0.02 .005 .96 .15]);

                            uicontrol(out_panel,'Style','pushbutton','String','Reset(r)','callback',@Pick_callback_reset_event,'Position',[0.02 .15 .96 .15]);

                            uicontrol(out_panel,'Style','pushbutton','String','Save Phase(s)','callback',@Pick_callback_save,'Position',[0.02 .44 .96 .15]);

                            uicontrol(out_panel,'Style','pushbutton','String','Save Fig','callback',@Pick_callback_savefig,'Position',[.46 .295 .52 .15]);
handle.save_fig         =   uicontrol(out_panel,'Style','popupmenu','String',para.save_fig_list,'Value',para.save_fig_idx,'Position',[.02 .275 .44 .15]);

handle.pfm_method_box   =   uicontrol(out_panel,'Style','popupmenu','String',para.pfm_method_list,'Value',3,'callback',@pfm_callback_select_pfm_out_method,'Position',[.4 .84 .58 .15]);%,'Position',[.02 .84 .98 .15]);
                            uicontrol(out_panel,'Style','text','String','Method','Position',[.02 .83 .38 .15]);

handle.pfm_out_idx      =   uicontrol(out_panel,'Style','popupmenu','String',para.pfm_out_list,'callback',@pfm_callback_select_pfm_out_idx,'Position',[.4 .705 .58 .15]);%,'Position',[.02 .705 .98 .15]);
                            uicontrol(out_panel,'Style','text','String','Solution','Position',[.02 .705 .38 .15]);

                            uicontrol(out_panel,'Style','pushbutton','String','Output FMS(o)','callback',@pfm_callback_compare_output,'Position',[0.02 .585 .96 .15]);

%% Events and frames
                            uicontrol(handle.f1,'Style','pushbutton','String','pre_ev(b)', 'callback',@Pick_callback_preevent,'Position', [.25 .95 .06 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','next_ev(n)', 'callback',@Pick_callback_nextevent,'Position', [.54 .95 .06 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','1st','callback',@Pick_callback_firstevent,'Position', [.20 .95 .05 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','last','callback',@Pick_callback_lastevent,'Position', [.6 .95 .05 .04]);

                            uicontrol(handle.f1,'Style','pushbutton','String','pre_ls(,)','callback',@Pick_callback_prepage,'Position', [.25 .90 .06 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','next_ls(.)','callback',@Pick_callback_nextpage,'Position', [.54 .90 .06 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','1st','callback',@Pick_callback_firstpage,'Position', [.20 .90 .05 .04]);
                            uicontrol(handle.f1,'Style','pushbutton','String','last','callback',@Pick_callback_lastpage,'Position', [.6 .90 .05 .04]);

                            uicontrol(handle.f1,'Style','text','String','ievent','Position',[.65 .97 .058 .025]);
handle.h_ievent         =   uicontrol(handle.f1,'Style','edit','String','0','callback',@Pick_callback_ievent,'Position',[.65 .95 .058 .02],'BackgroundColor',para.bcolor);

                            uicontrol(handle.f1,'Style','text','String','iframe','Position',[.65 .92 .058 .025]);
handle.h_iframe         =   uicontrol(handle.f1,'Style','edit','String','0','callback',@Pick_callback_iframe,'Position',[.65 .90 .058 .02],'BackgroundColor',para.bcolor);
                            uicontrol(handle.f1,'Style','pushbutton','String','Del frame','callback',@Pick_callback_delframe,'Position',[.65 .86 .058 .035]);
           

%% list box and delete trace
handle.h_listbox_list   =   uicontrol(handle.f1,'Style','popupmenu','String',para.listbox_list,'callback',@Pick_callback_replot,'Value',1,'Position',[.65 .825 .058 .035]);
handle.h_listbox        =   uicontrol(handle.f1,'Style','listbox','callback',@Pick_callback_listbox,'Value',1,'keypressfcn', @Pick_short_cut_listbox,'Position',[.65 .225 .058 .605],'max',1000);
handle.h_specify_phase_quality ...
                        =   uicontrol(handle.f1,'Style','popupmenu','String',para.specify_polarity_quality_listbox,'callback',@pfm_callback_specify_polarity_quality_to_trace,'Value',1,'Position',[.65 .185 .058 .035]);
handle.h_specify_phase  =   uicontrol(handle.f1,'Style','popupmenu','String',para.specify_phase_listbox,'callback',@pfm_callback_specify_phase_to_trace,'Value',1,'Position',[.65 .15 .058 .035]);

                            uicontrol(handle.f1,'Style','pushbutton','String','Del(d)','callback',@Pick_callback_deltrace,'Position',[.65 .12 .058 .035]);

                            uicontrol(handle.f1,'Style','pushbutton','String','Show(s)','callback',@Pick_callback_showtrace,'Position',[.65 .085 .058 .035]);

                            uicontrol(handle.f1,'Style','pushbutton','String','Flip(f)','callback',@Pick_callback_flip,'Position',[.65 .05 .058 .035]);

           
%% Callback functions:                 

    function pfm_callback_takeoff_angle(h,dummy)
        fprintf('Calculating take-off angle!\n')
        
        vz = find_vz_interp(para.em.z,para.em.vp,para.evdp);
    
        [p_Pg,t_Pg,d_Pg] = phase_taup('Pg',para.evdp,para.np,para.em,para.xdep);
        t_Pg = t_Pg + p_Pg.*d_Pg;
        d_Pg = d_Pg * para.r2d  ;
    
        [p_Pn,t_Pn,d_Pn] = phase_taup('Pn',para.evdp,para.np,para.em,para.xdep);
        t_Pn = t_Pn + p_Pn.*d_Pn;
        d_Pn = d_Pn * para.r2d  ;
    
        [p_P,t_P,d_P] = phase_taup('P',para.evdp,para.np,para.em,para.xdep);
        t_P = t_P + p_P.*d_P;
        d_P = d_P * para.r2d;
    
        [ rayp1, dist1, t1 ] = y_firstarrival_interp( p_Pg, d_Pg, t_Pg );
    %     dist1 = rem(dist1,360);
    %     ind_major = find(dist1>180);
    %     dist1(ind_major) = 360-dist1(ind_major);
    
    
        for i = 1 : para.nl
            tt_Pg = interp1db(tr(i).dist,dist1,t1  );
            tt_Pn = interp1db(tr(i).dist,d_Pn ,t_Pn);
            tt_P  = interp1db(tr(i).dist,d_P  ,t_P );
            
            [~,idx] = min([tt_Pg,tt_Pn,tt_P]);
    
            if idx==1
                tr(i).Pphase = 'Pg';
                tt_Pg2 = interp1db(tr(i).dist,d_Pg(1:para.np),t_Pg(1:para.np));
                rayp0  = interp1db(tr(i).dist,dist1,rayp1);
    
                if isnan(tt_Pg2) || round(tt_Pg2,4)>round(tt_Pg,4)
                    takeoff = asind(min(rayp0/(para.em.re-para.evdp)*vz,1));
                else
                    takeoff = 180-asind(min(rayp0/(para.em.re-para.evdp)*vz,1));
                end
            elseif idx==2
                tr(i).Pphase = 'Pn';
                rayp0 = interp1db(tr(i).dist,d_Pn,p_Pn);
                takeoff = asind(min(rayp0/(para.em.re-para.evdp)*vz,1));
            else
                tr(i).Pphase = 'P';
                rayp0 = interp1db(tr(i).dist,d_P,p_P);
                takeoff = asind(min(rayp0/(para.em.re-para.evdp)*vz,1));
            end
    
            tr(i).takeoff = takeoff;
            if takeoff>90
                cal_takeoff = 180-takeoff ;
                cal_az      = tr(i).az-180;
            else
                cal_takeoff = takeoff ;
                cal_az      = tr(i).az;
            end
            rp = para.pfm_r0 .* sqrt(2).*sin(pi./180.*cal_takeoff./2);
            tr(i).pol_x0 = para.pfm_x0+rp.*sind(cal_az); 
            tr(i).pol_y0 = para.pfm_y0+rp.*cosd(cal_az);
            tr(i).pq = 'I';
        end
        fprintf('End take-off angle calculation!\n')
    end


    function pfm_callback_replot(h,dummy)
%         uicontrol(handle.h_hot)

        if ~isempty(tr)
            pfm_callback_clear_pol(h,dummy)

            para.pfm_plot = 1;

            if ~isempty(tr(1).headers.kcmpnm) && ~ismember('Z',upper(tr(1).headers.kcmpnm))
                warning('The input file does not appear to be the Z channel!\n')
            end
            visible  = cell2mat({tr.visible} );
            polarity = cell2mat({tr.polarity});
            up       = find(visible==1&polarity>0);
            down     = find(visible==1&polarity<0);
            
            up_pol_x   = cell2mat({tr(up).pol_x0}  );
            up_pol_y   = cell2mat({tr(up).pol_y0}  );
            down_pol_x = cell2mat({tr(down).pol_x0});
            down_pol_y = cell2mat({tr(down).pol_y0});


            angle = 0 : 2 : 360;
            px = para.pfm_x0+para.pfm_r0*sind(angle);
            py = para.pfm_y0+para.pfm_r0*cosd(angle);

            plot(handle.pfm,px,py,'k','LineWidth',2);hold(handle.pfm, 'on');
            scatter(handle.pfm,para.pfm_x0,para.pfm_y0,100,'MarkerEdgeColor','k','Marker','x','LineWidth',2);hold(handle.pfm, 'on');

            plot(handle.pfm,up_pol_x,up_pol_y,para.pol_upcolor,down_pol_x,down_pol_y,para.pol_downcolor,'LineWidth',para.pol_markerlinewidth,'MarkerSize',para.pol_markersize);hold(handle.pfm, 'on');
% % %                 scatter(handle.pfm,up_pol_x,up_pol_y,para.pol_markersize,'MarkerEdgeColor',para.pol_upcolor,'Marker',para.pol_upmarker,'LineWidth',para.pol_markerlinewidth);hold(handle.pfm, 'on');
% % %                 scatter(handle.pfm,down_pol_x,down_pol_y,para.pol_markersize,'MarkerEdgeColor',para.pol_downcolor,'Marker',para.pol_downmarker,'LineWidth',para.pol_markerlinewidth);hold(handle.pfm, 'on');

            set(handle.pfm,'Xticklabel',[],'Yticklabel',[],'Xtick',[],'Ytick',[])

            if ~isempty(para.CHNYTX_out)
                C_num = pfm_plot_beachball(para.CHNYTX_out,'CHNYTX');
            end
            if ~isempty(para.HASH_out)
                H_num = pfm_plot_beachball(para.HASH_out,'HASH');
            end
            
            if get(handle.h_listbox,'Value')
                para.select_one_idx = [];
                j1 = (para.iframe -1) * para.n_per_frame +1;
                j2 = j1 + para.n_per_frame -1;
                j2 = min( j2, para.nl);
        
                index_selected = get(handle.h_listbox,'Value');
                j = j2 - index_selected + 1;
                
                visible  = cell2mat({tr.visible} );
                polarity = cell2mat({tr.polarity});
                plt_x    = cell2mat({tr.pol_x0}  );
                plt_y    = cell2mat({tr.pol_y0}  );
                idx_up   = (visible(j)==1&polarity(j)>0);
                idx_down = (visible(j)==1&polarity(j)<0);
        
                plot(handle.pfm,plt_x(j(idx_up)),plt_y(j(idx_up)),para.pfm_listbox_select_up_color,plt_x(j(idx_down)),plt_y(j(idx_down)),para.pfm_listbox_select_down_color,'Linewidth',para.pfm_listbox_select_linewidth,'Markersize',para.pfm_listbox_select_markersize);
                
                para.select_one_idx = [];
    
                if get(handle.pfm_show_select_nm,'Value')
                    nstnm = {tr(j).nstnm};
                    plt_x = cell2mat({tr(j).pol_x0});
                    plt_y = cell2mat({tr(j).pol_y0});
                    
                    dx = para.pfm_r0*2/9;
                    dy = para.pfm_r0/16 ;
                    for i = 1 : length(nstnm)
                        if ~tr(j(i)).visible
                            nstnm{i} = [];
                            continue
                        end
                        if plt_x(i)<para.pfm_x0 && plt_x(i)>-(para.pfm_r0+para.pfm_x0)*0.8
                            plt_x(i) = plt_x(i)-dx;
                        elseif plt_x(i)>para.pfm_x0 && plt_x(i)>-(para.pfm_r0+para.pfm_x0)*0.8
                            plt_x(i) = plt_x(i)+dx;
                        end
                        if plt_y(i)>para.pfm_y0
                            plt_y(i) = plt_y(i)+dy;
                        elseif plt_y(i)<para.pfm_y0
                            plt_y(i) = plt_y(i)-dy;
                        end
                    end
                    text(handle.pfm,plt_x,plt_y,nstnm,'HorizontalAlignment','center','VerticalAlignment','middle');
                    
                end

            elseif get(handle.pfm_pol_select_one,'Value')|| ~isempty(para.select_one_idx)
                if ~isempty(para.select_one_idx)
                    select_idx = para.select_one_idx    ;
                    plt_x      = tr(select_idx).pol_x0  ;
                    plt_y      = tr(select_idx).pol_y0  ;
                    polarity   = tr(select_idx).polarity;
    
    
                    if polarity>0
                        plot(handle.pfm,plt_x,plt_y,para.pfm_listbox_select_up_color,'Linewidth',para.pfm_listbox_select_linewidth,'Markersize',para.pfm_listbox_select_markersize);
                    else
                        plot(handle.pfm,plt_x,plt_y,para.pfm_listbox_select_down_color,'Linewidth',para.pfm_listbox_select_linewidth,'Markersize',para.pfm_listbox_select_markersize);
                    end
    
                    if get(handle.pfm_show_select_nm,'Value')
%                         para.select_one_idx = [];
                        nstnm = tr(select_idx).nstnm;
    
                        dx = para.pfm_r0*2/7;
                        dy = para.pfm_r0/14;
        
                        if plt_x<para.pfm_x0 && plt_x>-(para.pfm_r0+para.pfm_x0)*0.8
                            plt_x = plt_x-dx;
                        elseif plt_x>para.pfm_x0 && plt_x>-(para.pfm_r0+para.pfm_x0)*0.8
                            plt_x = plt_x+dx;
                        end
                        if plt_y>para.pfm_y0
                            plt_y = plt_y+dy;
                        elseif plt_y<para.pfm_y0
                            plt_y = plt_y-dy;
                        end
                        text(handle.pfm,plt_x,plt_y,[nstnm '.' num2str(para.select_one_iframe) '.' num2str(para.select_one_frame_idx)],'HorizontalAlignment','center','VerticalAlignment','middle');
                    end
                end
            end

            if ~isempty(para.optimal_fms)
                pfm_callback_plot_optimal_fms(h,dummy);
                plot(handle.pfm,[0.64,0.42,0.42,0.64,0.64],[0.64,0.64,0.5,0.5,0.64],'k','linewidth',1);
                text(handle.pfm,0.53,0.6,'Selected','HorizontalAlignment','center','VerticalAlignment','middle');
                plot(handle.pfm,[0.47,0.59],[0.54,0.54],para.pfm_selected_out_color,'linewidth',para.pfm_selected_out_linewidth);
            end

            plot(handle.pfm,[-0.64,-0.42,-0.42,-0.64,-0.64],[0.64,0.64,0.5,0.5,0.64],'k','linewidth',1);

            plot(handle.pfm,-0.6,0.6,para.pol_upcolor,'LineWidth',para.pol_markerlinewidth,'MarkerSize',para.pol_markersize);
            text(handle.pfm,-0.55,0.6,'Up','HorizontalAlignment','left','VerticalAlignment','middle');

            plot(handle.pfm,-0.6,0.54,para.pol_downcolor,'LineWidth',para.pol_markerlinewidth,'MarkerSize',para.pol_markersize);
            text(handle.pfm,-0.57,0.54,'Down','HorizontalAlignment','left','VerticalAlignment','middle');

%             C_num=3;
            if ~isempty(para.CHNYTX_out) && C_num>0
                if C_num==1
                    plot(handle.pfm,[-0.64,-0.42,-0.42,-0.64,-0.64],[-0.64,-0.64,-0.5,-0.5,-0.64],'k','linewidth',1);
                    text(handle.pfm,-0.53,-0.54,'CHNYTX','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[-0.59,-0.47],[-0.6,-0.6],'color',para.pfm_CHNYTX_mech_color{1},'linewidth',1)
                elseif C_num==2
                    plot(handle.pfm,[-0.64,-0.42,-0.42,-0.64,-0.64],[-0.64,-0.64,-0.45,-0.45,-0.64],'k','linewidth',1);
                    text(handle.pfm,-0.53,-0.49,'CHNYTX','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[-0.61,-0.49],[-0.55,-0.55],'color',para.pfm_CHNYTX_mech_color{1},'linewidth',1)
                    text(handle.pfm,-0.47,-0.55,'1');
                    plot(handle.pfm,[-0.61,-0.49],[-0.605,-0.605],'color',para.pfm_CHNYTX_mech_color{2},'linewidth',1)
                    text(handle.pfm,-0.47,-0.605,'2');
                elseif C_num==3
                    plot(handle.pfm,[-0.64,-0.42,-0.42,-0.64,-0.64],[-0.64,-0.64,-0.395,-0.395,-0.64],'k','linewidth',1);
                    text(handle.pfm,-0.53,-0.435,'CHNYTX','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[-0.61,-0.49],[-0.495,-0.495],'color',para.pfm_CHNYTX_mech_color{1},'linewidth',1)
                    text(handle.pfm,-0.47,-0.495,'1');
                    plot(handle.pfm,[-0.61,-0.49],[-0.55,-0.55],'color',para.pfm_CHNYTX_mech_color{2},'linewidth',1)
                    text(handle.pfm,-0.47,-0.55,'2');
                    plot(handle.pfm,[-0.61,-0.49],[-0.605,-0.605],'color',para.pfm_CHNYTX_mech_color{3},'linewidth',1)
                    text(handle.pfm,-0.47,-0.605,'3');
                end
            end
%             H_num=3;
            if ~isempty(para.HASH_out) && H_num>0
                if H_num==1
                    plot(handle.pfm,[0.64,0.42,0.42,0.64,0.64],[-0.64,-0.64,-0.5,-0.5,-0.64],'k','linewidth',1);
                    text(handle.pfm,0.53,-0.54,'HASH','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[0.59,0.47],[-0.6,-0.6],'color',para.pfm_HASH_mech_color{1},'linewidth',1)
                elseif H_num==2
                    plot(handle.pfm,[0.64,0.42,0.42,0.64,0.64],[-0.64,-0.64,-0.45,-0.45,-0.64],'k','linewidth',1);
                    text(handle.pfm,0.53,-0.49,'HASH','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[0.57,0.45],[-0.55,-0.55],'color',para.pfm_HASH_mech_color{1},'linewidth',1)
                    text(handle.pfm,0.59,-0.55,'1');
                    plot(handle.pfm,[0.57,0.45],[-0.605,-0.605],'color',para.pfm_HASH_mech_color{2},'linewidth',1)
                    text(handle.pfm,0.59,-0.605,'2');
                elseif H_num==3
                    plot(handle.pfm,[0.64,0.45,0.45,0.64,0.64],[-0.64,-0.64,-0.395,-0.395,-0.64],'k','linewidth',1);
                    text(handle.pfm,0.53,-0.435,'HASH','HorizontalAlignment','center','VerticalAlignment','middle');
                    plot(handle.pfm,[0.57,0.45],[-0.495,-0.495],'color',para.pfm_HASH_mech_color{1},'linewidth',1)
                    text(handle.pfm,0.59,-0.495,'1');
                    plot(handle.pfm,[0.57,0.45],[-0.55,-0.55],'color',para.pfm_HASH_mech_color{2},'linewidth',1)
                    text(handle.pfm,0.59,-0.55,'2');
                    plot(handle.pfm,[0.57,0.45],[-0.605,-0.605],'color',para.pfm_HASH_mech_color{3},'linewidth',1)
                    text(handle.pfm,0.59,-0.605,'3');
                end
            end
        else
            fprintf('No data input!\n');
        end

            axis(handle.pfm,'equal');
            xlim(handle.pfm,para.pfm_xlim);
            ylim(handle.pfm,para.pfm_ylim);
    end


    function pfm_callback_iniplot(h,dummy)
        uicontrol(handle.h_hot);
        pfm_callback_replot  (h,dummy);
        pfm_callback_plot_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_auto_plot(h,dummy)
        uicontrol(handle.h_hot);
        if ~get(handle.pfm_auto_plot_pol,'Value')
            value = get(handle.h_listbox,'Value');
            set(handle.h_listbox,'Value',[]);
            pfm_callback_replot(h,dummy);
            set(handle.h_listbox,'Value',value);
            pfm_callback_plot_pbt(h,dummy);
        else
            pfm_callback_replot(h,dummy);
            pfm_callback_plot_pbt(h,dummy);
        end
        uicontrol(handle.h_hot);
    end

    function pfm_callback_clear(h,dummy)
        uicontrol(handle.h_hot);
        pfm_callback_clear_pol(h,dummy);
        pfm_callback_clear_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_clear_pol(h,dummy)
        % clear handle.pfm
        cla(handle.pfm,'reset');
        box(handle.pfm,'on');
        set(handle.pfm,'XTick',[],'Ytick',[],'XTicklabel',[],'YTicklabel',[])
        para.pfm_plot = 0;
    end

    function pfm_callback_clear_pbt(h,dummy)
        % clear handle.pbt
        cla(handle.pbt,'reset');
        box(handle.pbt,'on');
        set(handle.pbt,'XTick',[],'Ytick',[],'XTicklabel',[],'YTicklabel',[])
        axis(handle.pbt,'equal');
        xlim(handle.pbt,para.pbt_xlim);
        ylim(handle.pbt,para.pbt_xlim);
    end

    function pfm_callback_clear_CHNYTX(h,dummy)
        uicontrol(handle.h_hot);
        para.CHNYTX_out = [];
        pfm_reset_output_listbox(h,dummy)
        pfm_callback_replot(h,dummy);
        pfm_callback_plot_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_clear_HASH(h,dummy)
        uicontrol(handle.h_hot);
        para.HASH_out = [];
        pfm_reset_output_listbox(h,dummy);
        pfm_callback_replot(h,dummy);
        pfm_callback_plot_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_clear_TWO(h,dummy)
        uicontrol(handle.h_hot);
        para.CHNYTX_out = [];
        para.HASH_out = [];
        pfm_reset_output_listbox(h,dummy);
        pfm_callback_replot(h,dummy);
        pfm_callback_plot_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_listbox_select(h,dummy)
        if ~para.pfm_plot
            return
        end
        pfm_callback_replot(h,dummy);
    end

    function pfm_callback_show_select_nm(h,dummy)
        if ~para.pfm_plot
            return
        end
        pfm_callback_replot(h,dummy);
%         para.select_one_idx = [];
        uicontrol(handle.h_hot);
    end

    function pfm_callback_select_one_pol(h,dummy)
        uicontrol(handle.h_hot);
        if ~isempty(tr)
            para.zoom = get(handle.zoom,'Enable');
            [sx,sy,~] = myginput(1,'crosshair');
    
            visible = cell2mat({tr.visible});
            pol_x = cell2mat({tr.pol_x0});
            pol_y = cell2mat({tr.pol_y0});
            visible_idx = find(visible==1);
            pol_x = pol_x(visible_idx);
            pol_y = pol_y(visible_idx);
    
            dist = sqrt((sx-pol_x).^2+(sy-pol_y).^2);
            [~,sidx] = min(dist);
            sidx = visible_idx(sidx);
            para.select_one_idx = sidx;

            fprintf('Selected station: %s\n',tr(sidx).nstnm)
    
            pfm_callback_select_one_to_trace_and_listbox(h,dummy);
            pfm_callback_listbox_select(h, dummy);
    
            % if para.fms_show_listbox
            %     uicontrol(handle.h_listbox)
            % else
            %     uicontrol(handle.h_hot)
            % end
            handle.zoom.Enable = para.zoom;
        else
            fprintf('No data input!\n')
        end
        uicontrol(handle.h_hot);
    end

    function pfm_callback_select_one_to_trace_and_listbox(h,dummy)
        if isempty(para.select_one_idx)
            return
        end
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1; 
        j2 = min( j2, para.nl);
        
        np = rem(para.select_one_idx,para.n_per_frame);
        if np==0
            para.select_one_iframe = round(para.select_one_idx/para.n_per_frame);
            show_idx = 1;
        else
            para.select_one_iframe = floor(para.select_one_idx/para.n_per_frame)+1;
            if para.select_one_iframe==para.nframes
                n_last_frame = para.nl-(para.nframes-1)*para.n_per_frame;
                show_idx = n_last_frame-(para.select_one_idx-(para.select_one_iframe-1)*para.n_per_frame)+1;
            else
                show_idx = para.select_one_iframe*para.n_per_frame-para.select_one_idx+1;
            end
        end
        para.select_one_frame_idx = show_idx;

        for i = j1:j2
            if tr(i).visible
                if length(handle.seis{i})==1
                    set( handle.seis{i} , 'color',para.color_show,'linewidth',para.linewidth_show);
                else
                    set( handle.seis{i}(1) , 'Facecolor',para.color_wig_up,'edgecolor','none','linewidth',para.linewidth_show);
                    set( handle.seis{i}(2) , 'Facecolor',para.color_wig_dn,'edgecolor','none','linewidth',para.linewidth_show);
                end
            end
        end
    
        if para.select_one_idx>=j1 && para.select_one_idx<=j2
            if length(handle.seis{para.select_one_idx})==1
                set( handle.seis{para.select_one_idx} , 'color',para.color_selected,'linewidth',para.linewidth_selected);
            else
                set( handle.seis{para.select_one_idx}(1) , 'Facecolor',para.color_selected,'edgecolor','none','linewidth',para.linewidth_selected);
                set( handle.seis{para.select_one_idx}(2) , 'Facecolor',para.color_selected,'edgecolor','none','linewidth',para.linewidth_selected);
            end
            set(handle.h_listbox,'Value',show_idx);
            % para.fms_show_listbox = 1;
            uicontrol(handle.h_listbox);
        else
            set(handle.h_listbox,'Value',[]);
            % para.fms_show_listbox = 0;
            uicontrol(handle.h_hot);
        end
    end

    function pfm_callback_change_page_plot_select_one(h,dummy)

        if isempty(para.select_one_idx)
            return
        end

        select_idx = para.select_one_idx    ;
        plt_x      = tr(select_idx).pol_x0  ;
        plt_y      = tr(select_idx).pol_y0  ;
        polarity   = tr(select_idx).polarity;


        if polarity>0
            plot(handle.pfm,plt_x,plt_y,para.pfm_listbox_select_up_color,'Linewidth',para.pfm_listbox_select_linewidth,'Markersize',para.pfm_listbox_select_markersize);
        else
            plot(handle.pfm,plt_x,plt_y,para.pfm_listbox_select_down_color,'Linewidth',para.pfm_listbox_select_linewidth,'Markersize',para.pfm_listbox_select_markersize);
        end

        if get(handle.pfm_show_select_nm,'Value')
            nstnm = tr(select_idx).nstnm;

            dx = para.pfm_r0*2/7;
            dy = para.pfm_r0/14 ;

            if plt_x<para.pfm_x0 && plt_x>-(para.pfm_r0+para.pfm_x0)*0.8
                plt_x = plt_x-dx;
            elseif plt_x>para.pfm_x0 && plt_x>-(para.pfm_r0+para.pfm_x0)*0.8
                plt_x = plt_x+dx;
            end
            if plt_y>para.pfm_y0
                plt_y = plt_y+dy;
            elseif plt_y<para.pfm_y0
                plt_y = plt_y-dy;
            end
            handle.pfm_select_show_nm = text(handle.pfm,plt_x,plt_y,[nstnm '.' num2str(para.select_one_iframe) '.' num2str(para.select_one_frame_idx)],'HorizontalAlignment','center','VerticalAlignment','middle');
        end
    end

    function pfm_callback_CHNYTX_cal_plot(h,dummy)
        uicontrol(handle.h_hot);
        if isempty(tr)
            fprintf('No data input!\n')
            return
        end
        pfm_callback_CHNYTX_cal(h,dummy);
        pfm_callback_replot(h,dummy);
        pfm_callback_plot_pbt(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_callback_CHNYTX_auto_cal(h,dummy)
%         if ~para.pfm_plot
%             return
%         end
        if get(handle.pfm_CHNYTX_auto,'Value')
            pfm_callback_CHNYTX_cal_plot(h,dummy);
        end
    end

    function pfm_callback_CHNYTX_cal(h,dummy)
        para.CHNYTX_out = [];
        pfm_reset_output_listbox(h,dummy);
        % para.optimal_fms = [];
        visible = cell2mat({tr.visible});

        idx      = find(visible==1);
        polarity = cell2mat({tr(idx).polarity});
        pq       = {tr(idx).pq};
        az       = cell2mat({tr(idx).az});
        takeoff  = cell2mat({tr(idx).takeoff});
        nstnm    = {tr(idx).nstnm};
        
        idx          = find(takeoff>90);
        az(idx)      = az(idx)-180;
        takeoff(idx) = 180 - takeoff(idx);

        idx           = find(strcmp(pq,'E'));
        polarity(idx) = sign(polarity(idx))*11;

        [NN_threshold,nzenith,nrotation,w2,dangle,discrepancy_range,...
        min_number,max_number,max_cluster_num,RA_range,jack_knife,.....
        DIS_good,DIS_bad,RMS_good] = CHNYTX_para;

        fms_out = Grid_point_test(nstnm , az , takeoff, polarity,NN_threshold,nzenith,nrotation,w2,dangle,discrepancy_range,min_number,max_number,max_cluster_num,RA_range,jack_knife,DIS_good,DIS_bad,RMS_good);

        fmsc_num = length(fms_out.fmsc.sk1);
        for iout = 1 : fmsc_num
            if fmsc_num<=para.CHNYTX_Ncg && fms_out.fmsc.rms(iout)<=para.CHNYTX_RMSg && fms_out.fmsc.disc(iout)<=para.CHNYTX_PSIg
                fms_out.fmsc.fmq{iout} = 'A';
            elseif fmsc_num>=para.CHNYTX_Ncb || fms_out.fmsc.disc(iout)>=para.CHNYTX_PSIb
                fms_out.fmsc.fmq{iout} = 'C';
            else
                fms_out.fmsc.fmq{iout} = 'B';
            end
        end
        para.CHNYTX_out = fms_out;
    end

    function pfm_callback_specify_phase_to_trace(h,dummy)
        uicontrol(handle.h_hot)

        index_selected = get(handle.h_listbox,'Value');

        if isempty(index_selected) || isempty(tr)
            return
        end

        vz = find_vz_interp(para.em.z,para.em.vp,para.evdp);

        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j  = j2 - index_selected + 1;

        idx = get(handle.h_specify_phase,'Value');

        if idx==1
            phase = 'Pg';
            [rayp,taup,dist] = phase_taup(phase,para.evdp,para.np,para.em,para.xdep);
            taup = taup + rayp.*dist;
            dist = dist*para.r2d;
            [ raypF, distF, taupF ] = y_firstarrival_interp( rayp, dist, taup );

            for i = j
                if ~tr(i).visible
                    continue
                end
                tt1 = interp1db(tr(j).dist,distF,taupF);
                tt2 = interp1db(tr(j).dist,dist(1:para.np),taup(1:para.np));
                pp  = interp1db(tr(j).dist,distF,raypF);
                if isnan(tt1) || isnan(tt2) || isnan(pp)
                    warning('%s cannot be specified seismic phase %s!',tr(i).nstnm,phase);
                    continue
                end

                if tt2<=tt1
                    takeoff = 180-asind(pp/(para.em.re-para.evdp)*vz);
                else
                    takeoff = asind(pp/(para.em.re-para.evdp)*vz);
                end

                if takeoff>90
                    cal_takeoff = 180-takeoff ;
                    cal_az      = tr(i).az-180;
                else
                    cal_takeoff = takeoff ;
                    cal_az      = tr(i).az;
                end
                rp = para.pfm_r0 .* sqrt(2).*sin(pi./180.*cal_takeoff./2);
                tr(i).pol_x0  = para.pfm_x0+rp.*sind(cal_az); 
                tr(i).pol_y0  = para.pfm_y0+rp.*cosd(cal_az);
                tr(i).Pphase  = 'Pg';
                tr(i).takeoff = takeoff;
            end
        else
            if idx==2
                phase = 'Pn';
            else
                phase = 'P';
            end
            [rayp,taup,dist] = phase_taup(phase,para.evdp,para.np,para.em,para.xdep);
            taup = taup + rayp.*dist;
            dist = dist*para.r2d;

            for i = j
                if ~tr(i).visible
                    continue
                end
                tt = interp1db(tr(j).dist,dist,taup);
                pp = interp1db(tr(j).dist,dist,rayp);
                if isnan(tt) || isnan(pp)
                    warning('%s cannot be specified seismic phase %s!',tr(i).nstnm,phase);
                    continue
                end

                takeoff = asind(pp/(para.em.re-para.evdp)*vz);

                cal_takeoff = takeoff ;
                cal_az      = tr(i).az;

                rp = para.pfm_r0 .* sqrt(2).*sin(pi./180.*cal_takeoff./2);
                tr(i).pol_x0  = para.pfm_x0+rp.*sind(cal_az); 
                tr(i).pol_y0  = para.pfm_y0+rp.*cosd(cal_az);
                tr(i).Pphase  = 'Pg';
                tr(i).takeoff = takeoff;
            end

        end
        if get(handle.h_textpara,'Value')
            Pick_callback_replot(h,dummy)
        end
        if get(handle.pfm_auto_plot_pol,'Value')
            pfm_callback_replot(h,dummy)
        end

        uicontrol(handle.h_listbox)
    end

    function pfm_callback_specify_polarity_quality_to_trace(h,dummy)
        uicontrol(handle.h_hot)
        index_selected = get(handle.h_listbox,'Value');

        if isempty(index_selected) || isempty(tr)
            return
        end


        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j  = j2 - index_selected + 1;

        idx = get(handle.h_specify_phase_quality,'Value');
        if idx==1
            pq = 'I';
        else
            pq = 'E';
        end

        for i = j
            if tr(i).visible
                tr(i).pq = pq;
            end
        end
        if get(handle.h_textpara,'Value')
            Pick_callback_replot(h,dummy);
        end
        if get(handle.pfm_auto_plot_pol,'Value')
            pfm_callback_replot (h,dummy);
        end
        uicontrol(handle.h_listbox);
    end

    function pfm_callback_HASH_cal_plot(h,dummy)
        pfm_callback_HASH_just_cal (h,dummy);
        pfm_callback_replot        (h,dummy);
        pfm_callback_plot_pbt      (h,dummy);
    end

    function pfm_callback_HASH_just_cal(h,dummy)
        if isempty(tr)
            fprintf('No data input!')
            return
        end
        value = get(handle.pfm_HASH_cal,'value');
        if value==1
            pfm_callback_HASH_cal_only_pol(h,dummy);
        elseif value==2
            pfm_callback_HASH_cal_add_amp(h,dummy);
        end
    end
        
    function pfm_callback_HASH_cal_list(h,dummy)
        uicontrol(handle.h_hot);
        if isempty(tr)
            fprintf('No data input!\n');
            uicontrol(handle.h_hot);
            return
        end
        pfm_callback_HASH_cal_plot(h,dummy)
        uicontrol(handle.h_hot);
    end

    function pfm_callback_HASH_auto_cal(h,dummy)
        if get(handle.pfm_HASH_auto,'Value')
            pfm_callback_HASH_cal_list(h,dummy);
        else
            uicontrol(handle.h_hot);
        end
    end

    function pfm_callback_HASH_cal_add_amp(h,dummy)
        if ~exist(para.hash_bin_file_amp,'file')
            warning(['No executable program of HASH was detected. ' ...
                'Please download the installation package from the website ' ...
                'https://www.usgs.gov/node/279393'])
            return
        end

        para.HASH_out    = [];
        pfm_reset_output_listbox(h,dummy);
        % para.optimal_fms = [];

        % if exist(fullfile(para.events{para.ievent},para.hash_out_file),'file')
        %     delete(fullfile(para.events{para.ievent},para.hash_out_file))
        % end
        % 
        % if exist(fullfile(para.events{para.ievent},para.hash_out2_file),'file')
        %     delete(fullfile(para.events{para.ievent},para.hash_out2_file))
        % end

        if ~exist(fullfile(para.events{para.ievent},para.hash_amp_file_input),'file')
            warning('The amplitude file was not found! Please check the file name or switch method!')
            return;
        end
        fid = fopen(fullfile(para.events{para.ievent},para.hash_amp_file_input));
        C = textscan(fid,'%s %f %f %f %f %*[^\n]','CommentStyle','#');
        fclose(fid);

        ntst = C{1};
        P_amp_n = C{2};
        P_amp   = C{3};
        S_amp_n = C{4};
        S_amp   = C{5};

        amp_ntst_num = length(ntst);

        ntst_all = {tr.nstnm};
        for i = 1 : amp_ntst_num
            idx = find(strcmp(ntst{i},ntst_all));

            % if isempty(idx)
            %     warning('No information found for station %s, please check the station name in the amplitude file.',ntst{i})
            %     continue
            % end
            if ~isempty(idx)
                tr(idx).amp.P_amp_n = P_amp_n(i);
                tr(idx).amp.P_amp   = P_amp  (i);
                tr(idx).amp.S_amp_n = S_amp_n(i);
                tr(idx).amp.S_amp   = S_amp  (i);
            end
        end

        fid1 = fopen(fullfile(para.events{para.ievent},para.hash_st_file),'w');
        fid2 = fopen(fullfile(para.events{para.ievent},para.hash_phase_file),'w');
        fid3 = fopen(fullfile(para.events{para.ievent},para.hash_inp_file),'w');
        fid4 = fopen(fullfile(para.events{para.ievent},para.hash_amp_file),'w');
        fid5 = fopen(fullfile(para.events{para.ievent},para.hash_amp_statcor),'w');

        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_st_file));
        fprintf(fid3,'%s\n',para.hash_reverse_st);
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_amp_statcor));
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_amp_file));
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_phase_file));
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_out_file));

        fprintf(fid3,'%d\n%f\n%d\n%d\n%f\n%f\n%f\n%f\n%f\n%f\n%d\n',    ...
            para.hash_min_pol,                                          ...
            para.hash_mech_grid,                                        ...
            para.hash_trial_num,                                        ...
            para.hash_max_out,                                          ...
            para.hash_min_snr,                                          ...
            para.hash_bad_fraction,                                     ...
            para.hash_assumed_noise,                                    ...
            para.hash_max_dist,                                         ...
            para.hash_prob_angle,                                       ...
            para.hash_prob_threshold,                                   ...
            para.hash_vel_num);
        fprintf(fid3,'%s\n',fullfile(para.path,'HASH','vmodels',[para.mod '.vel']));

        fprintf(fid4,'1 %d\n',amp_ntst_num);

        mag = 3;

        evla_deg = floor(para.evla);
        evla_min = (para.evla-evla_deg)*60;
        if para.evla<0
            evla_char = 'S';
        else
            evla_char = 'N';
        end

        evlo_deg = floor(para.evlo);
        evlo_min = (para.evlo-evlo_deg)*60;
        if para.evlo<0
            evlo_char = 'W';
        else
            evlo_char = 'E';
        end

        if para.evdp<100
            evdp = para.evdp;
        else
            evdp = 99.99;
        end
        
        % fprintf(fid2,['1994 12111 415.50%2d%s%5.2f%3d%s%5.2f%5.2f'      ...
        fprintf(fid2,['1997 8252124 6.50%2d%s%5.2f%3d%s%5.2f%5.2f'      ...
            '                                                 '         ...
            ' 0.10  0.12'                                               ...
            '                                        '                  ...
            '%4.2f                     1\n'],                           ...
            abs(evla_deg),evla_char,evla_min,                           ...
            abs(evlo_deg),evlo_char,evlo_min,                           ...
            evdp,mag);

        ntst_all = {tr.nstnm};

        p_amp_ratio = [];
        p_x         = [];
        p_y         = [];
        for i = 1 : length(ntst_all)
            
            stnm = ['Z' num2str(i,'%03d')];
            fprintf(fid1,['%-4s   Z                                 '     ...
                '%9.5f %10.5f %5d                       NK\n'],         ...
                stnm,tr(i).headers.stla,tr(i).headers.stlo,round(tr(i).headers.stel));
            fprintf(fid5,'%-4s    Z XX  0.0000\n',stnm);

            if tr(i).visible==1
                if tr(i).polarity<0
                    fprintf(fid2,'%s NK    Z %s D\n',stnm,tr(i).pq);
                else
                    fprintf(fid2,'%s NK    Z %s U\n',stnm,tr(i).pq);
                end
            end
            
            if ~isempty(tr(i).amp)
                fprintf(fid4,['%-4s   Z NK                 '            ...
                    '%10.3f %10.3f %10.3f %10.3f\n'],                   ...
                    stnm,tr(i).amp.P_amp_n,tr(i).amp.P_amp,             ...
                    tr(i).amp.S_amp_n, tr(i).amp.S_amp);
                p_amp_ratio = [ p_amp_ratio, log10(tr(i).amp.S_amp/tr(i).amp.P_amp)];
                p_x         = [ p_x, tr(i).pol_x0 ];
                p_y         = [ p_y, tr(i).pol_y0 ];
            end
        end
        fprintf(fid2,'                                                                       1\n');

        fclose(fid1);
        fclose(fid2);
        fclose(fid3);
        fclose(fid4);
        fclose(fid5);

        system([para.hash_bin_file_amp ' < ' fullfile(para.events{para.ievent},para.hash_inp_file)]);


        file1 = dir(fullfile(para.events{para.ievent},para.hash_out_file));
        if isempty(file1) || file1.bytes==0
            warning('There is no optimal solution in HASH!')
        else
            HASH_out = {};
            fid1 = fopen(fullfile(file1.folder,file1.name),'r');
            C = textscan(fid1,['%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ' ...
                '%f %f %f %f %f %f %f %s %f %f %f %f %*[^\n]'],para.pfm_fms_num);
            fclose(fid1);
            HASH_out.fmsc.sk1 = C{22};
            HASH_out.fmsc.da1 = C{23};
            HASH_out.fmsc.sa1 = C{24};

            [HASH_out.fmsc.sk2,HASH_out.fmsc.da2,HASH_out.fmsc.sa2] = y_GS_Auxplane(C{22},C{23},C{24});
            for iout = 1 : length(C{22})
                [pp,bb,tt] = z_sdr2pbt(HASH_out.fmsc.sk1(iout),HASH_out.fmsc.da1(iout),HASH_out.fmsc.sa1(iout),3);
                HASH_out.fmsc.paz(iout)  =  pp(1);
                HASH_out.fmsc.ppl(iout)  =  pp(2);
                HASH_out.fmsc.baz(iout)  =  bb(1);
                HASH_out.fmsc.bpl(iout)  =  bb(2);
                HASH_out.fmsc.taz(iout)  =  tt(1);
                HASH_out.fmsc.tpl(iout)  =  tt(2);
            end
            HASH_out.fmsc.fp_er          =  C{25}; 
            HASH_out.fmsc.ap_er          =  C{26};
            HASH_out.fmsc.n_pol          =  C{27};
            HASH_out.fmsc.weight_per_pol =  C{28};
            HASH_out.fmsc.fmq            =  C{29};
            HASH_out.fmsc.prob           =  C{30};
            HASH_out.fmsc.st_dr          =  C{31};
            HASH_out.fmsc.amp_num        =  C{32};
            HASH_out.fmsc.avg_amp_misfit =  C{33};
            
            para.HASH_out = HASH_out;
        end

        delete(fullfile(file1.folder,file1.name));
        delete(fullfile(para.events{para.ievent},para.hash_st_file    ));
        delete(fullfile(para.events{para.ievent},para.hash_phase_file ));
        delete(fullfile(para.events{para.ievent},para.hash_inp_file   ));
        delete(fullfile(para.events{para.ievent},para.hash_amp_file   ));
        delete(fullfile(para.events{para.ievent},para.hash_amp_statcor));

        if ~isempty(p_amp_ratio) && para.pfm_amp_save_fig
            fprintf('Printing figure of S/P distribution ...\n')
            scnsize = get(0,'ScreenSize');
            width = min(scnsize(3:4))/2;
    
            fig = figure('Position',[1,1,width*6/5,width],'Visible','off');
            ax = axes(fig);
            set(fig,'color','w')
            
            p_amp_ratio(p_amp_ratio<0.1)=0.1;
            
            x0 = para.pfm_x0;
            y0 = para.pfm_y0;
            r0 = para.pfm_r0;
            
            angle = 0 : 2 : 360;
            px = x0+r0*sind(angle);
            py = y0+r0*cosd(angle);
            
            plot(ax,px,py,'k','LineWidth',2);
            hold(ax, 'on');
            scatter(ax,x0,y0,100,'MarkerEdgeColor','k','Marker','x','LineWidth',2);
            hold(ax, 'on');
            
            axis(ax,'equal')
            axis(ax,'off')
            set(ax,'yticklabels',[],'xticklabels',[],'xtick',[],'ytick',[])
            
            scatter_y = -0.63;
            text_y    =  -0.7;
            scatter(ax,   p_x,       p_y, p_amp_ratio*80,'MarkerEdgeColor','k','Marker','o','linewidth',para.pol_markerlinewidth);hold(ax,'on');
            scatter(ax,  -0.3, scatter_y,        0.25*80,'MarkerEdgeColor','k','Marker','o','linewidth',para.pol_markerlinewidth);hold(ax,'on');
            scatter(ax,  -0.1, scatter_y,         0.5*80,'MarkerEdgeColor','k','Marker','o','linewidth',para.pol_markerlinewidth);hold(ax,'on');
            scatter(ax,   0.1, scatter_y,        0.75*80,'MarkerEdgeColor','k','Marker','o','linewidth',para.pol_markerlinewidth);hold(ax,'on');
            scatter(ax,   0.3, scatter_y,           1*80,'MarkerEdgeColor','k','Marker','o','linewidth',para.pol_markerlinewidth);hold(ax,'on');
            text(ax,     0, -0.56, 'Log(S/P)','fontsize',15,'fontweight','bold','HorizontalAlignment','center','VerticalAlignment','middle');hold(ax,'on');
            text(ax,  -0.3, text_y,     '0.25','fontsize',15,'fontweight','bold','HorizontalAlignment','center','VerticalAlignment','middle');hold(ax,'on');
            text(ax,  -0.1, text_y,      '0.5','fontsize',15,'fontweight','bold','HorizontalAlignment','center','VerticalAlignment','middle');hold(ax,'on');
            text(ax,   0.1, text_y,     '0.75','fontsize',15,'fontweight','bold','HorizontalAlignment','center','VerticalAlignment','middle');hold(ax,'on');
            text(ax,   0.3, text_y,        '1','fontsize',15,'fontweight','bold','HorizontalAlignment','center','VerticalAlignment','middle');hold(ax,'on');
            
            if isfield(para.HASH_out,'fmsc') && ~isempty(para.HASH_out.fmsc)
                lc = para.pfm_HASH_mech_color;
                for ij = 1 : length(para.HASH_out.fmsc.sk1)
                    [xs1,ys1] = FMnodline(para.HASH_out.fmsc.sk1(ij),para.HASH_out.fmsc.da1(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                    [xs2,ys2] = FMnodline(para.HASH_out.fmsc.sk2(ij),para.HASH_out.fmsc.da2(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                    px1 = [xs1,NaN,xs2];
                    py1 = [ys1,NaN,ys2];
                    hold(ax,'on');
                    plot(ax,px1,py1,'color',lc{ij},'linewidth',para.pfm_mechanism_linewidth);
                end
            end

            if isfield(para.CHNYTX_out,'fmsc') && ~isempty(para.CHNYTX_out.fmsc)
                lc = para.pfm_CHNYTX_mech_color;
                for ij = 1 : length(para.CHNYTX_out.fmsc.sk1)
                    [xs1,ys1] = FMnodline(para.CHNYTX_out.fmsc.sk1(ij),para.CHNYTX_out.fmsc.da1(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                    [xs2,ys2] = FMnodline(para.CHNYTX_out.fmsc.sk2(ij),para.CHNYTX_out.fmsc.da2(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                    px1 = [xs1,NaN,xs2];
                    py1 = [ys1,NaN,ys2];
                    hold(ax,'on');
                    plot(ax,px1,py1,'color',lc{ij},'linewidth',para.pfm_mechanism_linewidth);
                end
            end

            para.pfm_amp_xlim = [-0.55,0.55];
            para.pfm_amp_ylim = [-0.75,0.55];

            xlim(ax,para.pfm_amp_xlim)
            ylim(ax,para.pfm_amp_ylim)


            [a,b,c] = fileparts(para.events{para.ievent});
            if isempty(b)
                [~,b,c] = fileparts(a);
            end

            evnm_tmp = ['HASH_result_amp_' [b,c]];

            if para.export_graphics
                if strcmp(para.pfm_amp_save_format,'pdf')
                    exportgraphics(fig,fullfile(para.events{para.ievent},[evnm_tmp '.pdf']),'BackgroundColor','none','ContentType','Vector');
                elseif strcmp(para.pfm_amp_save_format,'png')
                    exportgraphics(fig,fullfile(para.events{para.ievent},[evnm_tmp '.png']),'Resolution',para.pfm_amp_save_pixel);
                elseif strcmp(para.pfm_amp_save_format,'jpg')
                    exportgraphics(fig,fullfile(para.events{para.ievent},[evnm_tmp '.jpg']),'Resolution',para.pfm_amp_save_pixel);
                else
                    warning('The image output format is incorrect!')
                end
            else
                save_fig_pixel = ['-r' num2str(para.pfm_amp_save_pixel),'%d'];
                if strcmp(para.pfm_amp_save_format,'pdf')
                    print(fig,save_fig_pixel,'-fillpage','-dpdf',fullfile(para.events{para.ievent},[evnm_tmp '.pdf']));
                elseif strcmp(para.pfm_amp_save_format,'png')
                    print(fig,save_fig_pixel,'-dpng',fullfile(para.events{para.ievent},[evnm_tmp '.png']));
                elseif strcmp(para.pfm_amp_save_format,'jpg')
                    print(fig,save_fig_pixel,'-djpeg',fullfile(para.events{para.ievent},[evnm_tmp '.jpg']));
                else
                    warning('The image output format is incorrect!')
                end
            end
            close(fig);
            fprintf('Done!\n')
        end
    end

    function pfm_callback_HASH_cal_only_pol(h,dummy)
        
        if ~exist(para.hash_bin_file,'file')
            warning(['No executable program of HASH was detected. ' ...
                'Please download the installation package from the website ' ...
                'https://www.usgs.gov/node/279393'])
            return
        end
        para.HASH_out = [];
        pfm_reset_output_listbox(h,dummy);
        % para.optimal_fms = [];

        if exist(fullfile(para.events{para.ievent},para.hash_out_file),'file')
            delete(fullfile(para.events{para.ievent},para.hash_out_file))
        end
        if exist(fullfile(para.events{para.ievent},para.hash_out2_file),'file')
            delete(fullfile(para.events{para.ievent},para.hash_out2_file))
        end

%         para.hash_max_az_gap = 150;
        
        fid1 = fopen(fullfile(para.events{para.ievent},para.hash_st_file),'w');
        fid2 = fopen(fullfile(para.events{para.ievent},para.hash_phase_file),'w');
        fid3 = fopen(fullfile(para.events{para.ievent},para.hash_inp_file),'w');

        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_st_file));
        fprintf(fid3,'%s\n',para.hash_reverse_st);
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_phase_file));
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_out_file));
        fprintf(fid3,'%s\n',fullfile(para.events{para.ievent},para.hash_out2_file));
        fprintf(fid3,'%d\n%d\n%d\n%f\n%d\n%d\n%f\n%f\n%f\n%f\n%d\n',    ...
            para.hash_min_pol,                                          ...
            para.hash_max_az_gap,                                       ...
            para.hash_max_takeoff_gap,                                  ...
            para.hash_mech_grid,                                        ...
            para.hash_trial_num,                                        ...
            para.hash_max_out,                                          ...
            para.hash_bad_fraction,                                     ...
            para.hash_max_dist,                                         ...
            para.hash_prob_angle,                                       ...
            para.hash_prob_threshold,                                   ...
            para.hash_vel_num);

        fprintf(fid3,'%s\n',fullfile(para.path,'HASH','vmodels',[para.mod '.vel']));
        fclose(fid3);

        mag = 3;

        evla_deg = floor(para.evla);
        evla_min = (para.evla-evla_deg)*60;
        if para.evla<0
            evla_char = 'S';
        else
            evla_char = 'N';
        end
        evlo_deg = floor(para.evlo);
        evlo_min = (para.evlo-evlo_deg)*60;
        if para.evlo<0
            evlo_char = 'W';
        else
            evlo_char = 'E';
        end
        if para.evdp<100
            evdp = para.evdp;
        else
            evdp = 99.99;
        end
        
        fprintf(fid2,['1997 8252124 6.50%2d%s%5.2f%3d%s%5.2f%5.2f'      ...
            '                                                 '         ...
            ' 0.10  0.12'                                               ...
            '                                        '                  ...
            '%4.2f                     1\n'],                           ...
            abs(evla_deg),evla_char,evla_min,                           ...
            abs(evlo_deg),evlo_char,evlo_min,                           ...
            evdp,mag);
        idx = 0;
        visible = cell2mat({tr.visible});
        j = find(visible==1);
        for i = j
            idx = idx + 1;
            stnm = ['Z' num2str(idx,'%03d')];
            fprintf(fid1,['%s   Z                                 ' ...
                '%9.5f %10.5f %5d                       NK\n'],...
                stnm,tr(i).headers.stla,tr(i).headers.stlo,round(tr(i).headers.stel));
            if tr(i).polarity<0
                fprintf(fid2,'%s NK    Z %s D\n',stnm,tr(i).pq);
            else
                fprintf(fid2,'%s NK    Z %s U\n',stnm,tr(i).pq);
            end
        end
        fprintf(fid2,'                                                                       1\n');
        fclose(fid1);
        fclose(fid2);
        system([para.hash_bin_file ' < ' fullfile(para.events{para.ievent},para.hash_inp_file)]);

        file1 = dir(fullfile(para.events{para.ievent},para.hash_out_file));
        file2 = dir(fullfile(para.events{para.ievent},para.hash_out2_file));
        if isempty(file1) || isempty(file2) || file1.bytes==0 || file2.bytes==0
            warning('There is no optimal solution in HASH!')
        else
            HASH_out = {};
            fid1 = fopen(fullfile(file1.folder,file1.name),'r');
            C = textscan(fid1,['%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ' ...
                '%f %f %f %f %f %f %f %s %f %f %*[^\n]'],para.pfm_fms_num);
            fclose(fid1);
            HASH_out.fmsc.sk1 = C{22};
            HASH_out.fmsc.da1 = C{23};
            HASH_out.fmsc.sa1 = C{24};

            [HASH_out.fmsc.sk2,HASH_out.fmsc.da2,HASH_out.fmsc.sa2] = y_GS_Auxplane(C{22},C{23},C{24});
            for iout = 1 : length(C{22})
                [pp,bb,tt] = z_sdr2pbt(HASH_out.fmsc.sk1(iout),HASH_out.fmsc.da1(iout),HASH_out.fmsc.sa1(iout),3);
                HASH_out.fmsc.paz(iout) = pp(1);
                HASH_out.fmsc.ppl(iout) = pp(2);
                HASH_out.fmsc.baz(iout) = bb(1);
                HASH_out.fmsc.bpl(iout) = bb(2);
                HASH_out.fmsc.taz(iout) = tt(1);
                HASH_out.fmsc.tpl(iout) = tt(2);
            end
            HASH_out.fmsc.fp_er          = C{25}; 
            HASH_out.fmsc.ap_er          = C{26};
            HASH_out.fmsc.n_pol          = C{27};
            HASH_out.fmsc.weight_per_pol = C{28};
            HASH_out.fmsc.fmq            = C{29};
            HASH_out.fmsc.prob           = C{30};
            HASH_out.fmsc.st_dr          = C{31};
            
            fid2 = fopen(fullfile(file2.folder,file2.name),'r');
            C = textscan(fid2,'%f %f %f %*[^\n]','HeaderLines',1);
            fclose(fid2);
            HASH_out.fms.sk1 = C{1};
            HASH_out.fms.da1 = C{2};
            HASH_out.fms.sa1 = C{3};
            [HASH_out.fms.sk2,HASH_out.fms.da2,HASH_out.fms.sa2] = y_GS_Auxplane(C{1},C{2},C{3});
            for iout = 1 : length(C{1})
                [pp,bb,tt] = z_sdr2pbt(HASH_out.fms.sk1(iout),HASH_out.fms.da1(iout),HASH_out.fms.sa1(iout),3);
                HASH_out.fms.paz(iout) = pp(1);
                HASH_out.fms.ppl(iout) = pp(2);
                HASH_out.fms.baz(iout) = bb(1);
                HASH_out.fms.bpl(iout) = bb(2);
                HASH_out.fms.taz(iout) = tt(1);
                HASH_out.fms.tpl(iout) = tt(2);
            end

            para.HASH_out = HASH_out;
        end
        delete(fullfile(file1.folder,file1.name));
        delete(fullfile(file2.folder,file2.name));
        delete(fullfile(para.events{para.ievent},para.hash_st_file));
        delete(fullfile(para.events{para.ievent},para.hash_phase_file));
        delete(fullfile(para.events{para.ievent},para.hash_inp_file));
            
    end

    function pfm_callback_cal_TWO_method(h,dummy)
        uicontrol(handle.h_hot);
        if isempty(tr)
            return
        end
        pfm_callback_CHNYTX_cal(h,dummy);
        pfm_callback_HASH_just_cal(h,dummy);
        pfm_callback_replot(h,dummy);
        pfm_callback_plot_pbt(h,dummy)
        uicontrol(handle.h_hot);
    end

    function pfm_callback_TWO_auto_cal(h,dummy)
        if get(handle.pfm_TWO_auto,'Value')
            set(handle.pfm_CHNYTX_auto,'Value',1);
            set(handle.pfm_HASH_auto,  'Value',1);
            pfm_callback_cal_TWO_method(h,dummy)
        else
            set(handle.pfm_CHNYTX_auto,'Value',0);
            set(handle.pfm_HASH_auto,  'Value',0);
        end
    end

    function ij = pfm_plot_beachball(fms_out,method)
        if strcmp(method,'CHNYTX')
            lc = para.pfm_CHNYTX_mech_color;
        elseif strcmp(method,'HASH')
            lc = para.pfm_HASH_mech_color;
        end

        if isempty(fms_out.fmsc.sk1)
            fprintf('There are no results from MFPMS!\n')
            ij = 0;
            return
        else
            for ij = 1 : length(fms_out.fmsc.sk1)
                [xs1,ys1] = FMnodline(fms_out.fmsc.sk1(ij),fms_out.fmsc.da1(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                [xs2,ys2] = FMnodline(fms_out.fmsc.sk2(ij),fms_out.fmsc.da2(ij),para.pfm_x0,para.pfm_y0,para.pfm_r0);
                px1 = [xs1,NaN,xs2];
                py1 = [ys1,NaN,ys2];
                plot(handle.pfm,px1,py1,'color',lc{ij},'linewidth',para.pfm_mechanism_linewidth);
            end
        end
    end

    function pfm_callback_update_pfm(h,dummy)
        TWO_c    = get(handle.pfm_TWO_auto   ,'Value');
        CHNYTX_c = get(handle.pfm_CHNYTX_auto,'Value');
        HASH_c   = get(handle.pfm_HASH_auto  ,'Value');
        para.select_one_idx = [];

        if exist(fullfile(para.events{para.ievent},para.fms_outfile),'file')
            if get(handle.pfm_auto_plot_pol,'Value')
                pfm_callback_replot(h,dummy);
                pfm_callback_plot_pbt(h,dummy);
            else
                pfm_callback_clear(h,dummy);
            end
        else
            para.CHNYTX_out  = [];
            para.HASH_out    = [];
            pfm_reset_output_listbox(h,dummy);
            % para.optimal_fms = [];
    
            if TWO_c || CHNYTX_c || HASH_c
                if TWO_c
                    pfm_callback_CHNYTX_cal(h,dummy);
                    pfm_callback_HASH_just_cal(h,dummy);
                elseif CHNYTX_c
                    pfm_callback_CHNYTX_cal(h,dummy);
                else
                    pfm_callback_HASH_just_cal(h,dummy);
                end
                pfm_callback_replot(h,dummy);
                pfm_callback_plot_pbt(h,dummy);
            elseif get(handle.pfm_auto_plot_pol,'Value')
                pfm_callback_replot(h,dummy);
                pfm_callback_clear_pbt(h,dummy);
            else
                pfm_callback_clear(h,dummy);
            end
        end
        para.pfm_out_list = {''};
        set(handle.pfm_out_idx,'String',para.pfm_out_list,'value',1)
    end


    function pfm_callback_update_pfm_2(h,dummy)

%         para.CHNYTX_out = [];
%         para.HASH_out = [];
%         para.optimal_pfm = [];
        TWO_c    = get(handle.pfm_TWO_auto   ,'Value');
        CHNYTX_c = get(handle.pfm_CHNYTX_auto,'Value');
        HASH_c   = get(handle.pfm_HASH_auto  ,'Value');

        if TWO_c || CHNYTX_c || HASH_c
            if TWO_c
                pfm_callback_CHNYTX_cal(h,dummy);
                pfm_callback_HASH_just_cal(h,dummy);
            elseif CHNYTX_c
                pfm_callback_CHNYTX_cal(h,dummy);
            else
                pfm_callback_HASH_just_cal(h,dummy);
            end
            pfm_callback_plot_pbt(h,dummy);
            pfm_callback_replot(h,dummy);
%             pfm_plot_pbt(h,dummy);
        elseif get(handle.pfm_auto_plot_pol,'Value')
            pfm_callback_replot(h,dummy);
%             pfm_pbt_clear_all(h,dummy);
        end
    end

    function pfm_callback_plot_pbt(h,dummy)
        pfm_callback_clear_pbt(h,dummy);
        if isempty(para.CHNYTX_out) && isempty(para.HASH_out)
            return
        end

        x0 = para.pfm_x0;y0 = para.pfm_y0;r0 = para.pfm_r0;
        angle = 0 : 2 : 360;
        px = x0+r0*sind(angle);
        py = y0+r0*cosd(angle);
        plot(handle.pbt,px,py,'k','LineWidth',2);hold(handle.pbt, 'on');
        scatter(handle.pbt,x0,y0,100,'MarkerEdgeColor','k','Marker','x','LineWidth',2);hold(handle.pbt, 'on');
        csize  = para.pbt_csize;
        ssize  = para.pbt_ssize;

        if ~isempty(para.CHNYTX_out)
            lc = para.pfm_CHNYTX_mech_color;
            cnum = length(para.CHNYTX_out.fmsc.sk1);
            if cnum==length(unique(para.CHNYTX_out.fms.cid))
                for i = 1 : cnum
                    if i <= length(lc)
                        fcolor = lc{i};
                    else
                        fcolor = lc{end};
                    end

                    cidnm = para.CHNYTX_out.fmsc.idnm(i);

                    idx  = find(cidnm==para.CHNYTX_out.fms.cid);
                    spaz = para.CHNYTX_out.fms.paz(idx)   ;
                    spih = 90-para.CHNYTX_out.fms.ppl(idx);
                    staz = para.CHNYTX_out.fms.taz(idx)   ;
                    stih = 90-para.CHNYTX_out.fms.tpl(idx);
                    sbaz = para.CHNYTX_out.fms.baz(idx)   ;
                    sbih = 90-para.CHNYTX_out.fms.bpl(idx);

                    spr = r0.*sqrt(2).*sind(spih./2);
                    str = r0.*sqrt(2).*sind(stih./2);
                    sbr = r0.*sqrt(2).*sind(sbih./2);
                    spx  = x0 + spr.*sind(spaz);
                    spy = y0 + spr.*cosd(spaz) ;
                    stx  = x0 + str.*sind(staz);
                    sty = y0 + str.*cosd(staz) ;
                    sbx  = x0 + sbr.*sind(sbaz);
                    sby = y0 + sbr.*cosd(sbaz) ;

                    scatter(handle.pbt,spx,spy,'SizeData',ssize,'MarkerEdgeColor',fcolor,'Marker',para.pmarker,'LineWidth',1);hold(handle.pbt, 'on');
                    scatter(handle.pbt,stx,sty,'SizeData',ssize,'MarkerEdgeColor',fcolor,'Marker',para.tmarker,'LineWidth',1);hold(handle.pbt, 'on');
                    scatter(handle.pbt,sbx,sby,'SizeData',ssize,'MarkerEdgeColor',fcolor,'Marker',para.bmarker,'LineWidth',1);hold(handle.pbt, 'on');

                    cpaz = para.CHNYTX_out.fmsc.paz(i)   ;
                    cpih = 90-para.CHNYTX_out.fmsc.ppl(i);
                    ctaz = para.CHNYTX_out.fmsc.taz(i)   ;
                    ctih = 90-para.CHNYTX_out.fmsc.tpl(i);
                    cbaz = para.CHNYTX_out.fmsc.baz(i)   ;
                    cbih = 90-para.CHNYTX_out.fmsc.bpl(i);

                    cpr = r0*sqrt(2)*sind(cpih/2);
                    ctr = r0*sqrt(2)*sind(ctih/2);
                    cbr = r0*sqrt(2)*sind(cbih/2);
                    cpx = x0 + cpr*sind(cpaz);
                    cpy = y0 + cpr*cosd(cpaz);
                    ctx = x0 + ctr*sind(ctaz);
                    cty = y0 + ctr*cosd(ctaz);
                    cbx = x0 + cbr*sind(cbaz);
                    cby = y0 + cbr*cosd(cbaz);

                    scatter(handle.pbt,cpx,cpy,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.pmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
                    scatter(handle.pbt,ctx,cty,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.tmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
                    scatter(handle.pbt,cbx,cby,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.bmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
                end
            else
                warning('Number of the cluser is different with the classes of the selected focal mechanism!\n');
            end
        end

        if ~isempty(para.HASH_out)
            lc = para.pfm_HASH_mech_color;
            cnum = length(para.HASH_out.fmsc.sk1);
            if isfield(para.HASH_out,'fms') && ~isempty(para.HASH_out.fms)
                spaz = para.HASH_out.fms.paz;
                spih = 90-para.HASH_out.fms.ppl;
                staz = para.HASH_out.fms.taz;
                stih = 90-para.HASH_out.fms.tpl;
                sbaz = para.HASH_out.fms.baz;
                sbih = 90-para.HASH_out.fms.bpl;
                spr = r0.*sqrt(2).*sind(spih./2);
                str = r0.*sqrt(2).*sind(stih./2);
                sbr = r0.*sqrt(2).*sind(sbih./2);

                spx = x0 + spr.*sind(spaz);
                spy = y0 + spr.*cosd(spaz);
                stx = x0 + str.*sind(staz);
                sty = y0 + str.*cosd(staz);
                sbx = x0 + sbr.*sind(sbaz);
                sby = y0 + sbr.*cosd(sbaz);
                scatter(handle.pbt,spx,spy,'SizeData',ssize,'MarkerEdgeColor',lc{1},'Marker',para.pmarker,'LineWidth',1);hold(handle.pbt, 'on');
                scatter(handle.pbt,stx,sty,'SizeData',ssize,'MarkerEdgeColor',lc{1},'Marker',para.tmarker,'LineWidth',1);hold(handle.pbt, 'on');
                scatter(handle.pbt,sbx,sby,'SizeData',ssize,'MarkerEdgeColor',lc{1},'Marker',para.bmarker,'LineWidth',1);hold(handle.pbt, 'on');
            end

            for i = 1 : cnum
                if i<=length(lc)
                    fcolor = lc{i};
                else
                    fcolor = lc{end};
                end
                cpaz = para.HASH_out.fmsc.paz(i);
                cpih = 90-para.HASH_out.fmsc.ppl(i);
                ctaz = para.HASH_out.fmsc.taz(i);
                ctih = 90-para.HASH_out.fmsc.tpl(i);
                cbaz = para.HASH_out.fmsc.baz(i);
                cbih = 90-para.HASH_out.fmsc.bpl(i);
                cpr = r0*sqrt(2)*sind(cpih/2);
                ctr = r0*sqrt(2)*sind(ctih/2);
                cbr = r0*sqrt(2)*sind(cbih/2);
                cpx = x0 + cpr*sind(cpaz);
                cpy = y0 + cpr*cosd(cpaz);
                ctx = x0 + ctr*sind(ctaz);
                cty = y0 + ctr*cosd(ctaz);
                cbx = x0 + cbr*sind(cbaz);
                cby = y0 + cbr*cosd(cbaz);
                scatter(handle.pbt,cpx,cpy,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.pmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
                scatter(handle.pbt,ctx,cty,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.tmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
                scatter(handle.pbt,cbx,cby,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'Marker',para.bmarker,'LineWidth',1,'MarkerFaceColor',fcolor);hold(handle.pbt, 'on');
            end
        end

        scatter(handle.pbt,0.42,0.51,'SizeData',ssize,'MarkerEdgeColor','k','Marker',para.pmarker,'Linewidth',1);hold(handle.pbt,'on');
        scatter(handle.pbt,0.42,0.445,'SizeData',ssize,'MarkerEdgeColor','k','Marker',para.bmarker,'Linewidth',1);hold(handle.pbt,'on');
        scatter(handle.pbt,0.42,0.38,'SizeData',ssize,'MarkerEdgeColor','k','Marker',para.tmarker,'Linewidth',1);hold(handle.pbt,'on');
        text(handle.pbt,0.47,0.51,'P','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');
        text(handle.pbt,0.47,0.45,'B','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');
        text(handle.pbt,0.47,0.385,'T','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');

        rectangle(handle.pbt,'position',[0.39,0.35,0.15,0.19],'linewidth',1);hold(handle.pbt,'on');
        % scatter(handle.pbt,0.28,-0.5,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'MarkerFaceColor',para.pfm_CHNYTX_mech_color{1},'Marker','o','Linewidth',1);hold(handle.pbt,'on');
        % text(handle.pbt,0.32,-0.49,'center','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');
        % rectangle(handle.pbt,'position',[0.24,-0.54,0.30,0.09],'linewidth',1);

        if ~isempty(para.HASH_out)
            scatter(handle.pbt,0.30,-0.495,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'MarkerFaceColor',para.pfm_HASH_mech_color{1},'Marker','o','Linewidth',1);hold(handle.pbt,'on');
            text(handle.pbt,0.34,-0.49,'H\_opt','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');
            rectangle(handle.pbt,'position',[0.26,-0.54,0.28,0.09],'linewidth',1);
        end

        if ~isempty(para.CHNYTX_out)
            scatter(handle.pbt,-0.50,-0.495,'SizeData',csize,'MarkerEdgeColor',para.pbt_c_edge_color,'MarkerFaceColor',para.pfm_CHNYTX_mech_color{1},'Marker','o','Linewidth',1);hold(handle.pbt,'on');
            text(handle.pbt,-0.46,-0.49,'H\_opt','HorizontalAlignment','left','VerticalAlignment','middle');hold(handle.pbt,'on');
            rectangle(handle.pbt,'position',[-0.54,-0.54,0.28,0.09],'linewidth',1);
        end

        axis(handle.pbt,'equal');
               
        xlim(handle.pbt,para.pbt_xlim)
        ylim(handle.pbt,para.pbt_xlim)
        set(handle.pbt,'Xticklabel',[],'Yticklabel',[],'Xtick',[],'Ytick',[])
    end

    function pfm_callback_select_pfm_out_method(h,dummy)
        uicontrol(handle.h_hot);
        method_idx = get(handle.pfm_method_box,'Value');
        
        if method_idx==1 && ~isempty(para.CHNYTX_out)
            pfm_num = length(para.CHNYTX_out.fmsc.sk1);
            fprintf('CHNYTX method selected!\n')
        elseif method_idx==2 && ~isempty(para.HASH_out)
            pfm_num = length(para.HASH_out.fmsc.sk1);
            fprintf('HASH method selected!\n')
        elseif method_idx==3
            para.optimal_fms = [];
            para.pfm_out_list = {''};
            set(handle.pfm_out_idx,'String',para.pfm_out_list,'value',1)
            pfm_callback_replot(h,dummy);
            return;
        else
            para.pfm_out_list = {''};
            set(handle.pfm_out_idx,'String',para.pfm_out_list,'Value',1);
            fprintf('There is no inversion result through this method!\n')
            return
        end
        if pfm_num>0
            para.pfm_out_list = cell(pfm_num,1);
            for ij = 1 : pfm_num
                para.pfm_out_list{ij} = ['result' num2str(ij)];
            end
            set(handle.pfm_out_idx,'String',para.pfm_out_list,'Value',1);
        else
            fprintf('There is no inversion result through this method!\n')
            return
        end
        pfm_callback_select_pfm_out_idx(h,dummy)
        uicontrol(handle.h_hot);
    end

    function pfm_callback_select_pfm_out_idx(h,dummy)
        uicontrol(handle.h_hot);
        out_idx    = get(handle.pfm_out_idx   ,'Value');
        method_idx = get(handle.pfm_method_box,'Value');

        if isempty(para.pfm_out_list{out_idx})
            return;
        end

        if method_idx==1
            para.optimal_fms.sk1 = para.CHNYTX_out.fmsc.sk1(out_idx);
            para.optimal_fms.sk2 = para.CHNYTX_out.fmsc.sk2(out_idx);
            para.optimal_fms.da1 = para.CHNYTX_out.fmsc.da1(out_idx);
            para.optimal_fms.da2 = para.CHNYTX_out.fmsc.da2(out_idx);
            para.optimal_fms.sa1 = para.CHNYTX_out.fmsc.sa1(out_idx);
            para.optimal_fms.sa2 = para.CHNYTX_out.fmsc.sa2(out_idx);
            para.optimal_fms.oq  = para.CHNYTX_out.fmsc.fmq{out_idx};
        elseif method_idx==2
            para.optimal_fms.sk1 = para.HASH_out.fmsc.sk1(out_idx);
            para.optimal_fms.sk2 = para.HASH_out.fmsc.sk2(out_idx);
            para.optimal_fms.da1 = para.HASH_out.fmsc.da1(out_idx);
            para.optimal_fms.da2 = para.HASH_out.fmsc.da2(out_idx);
            para.optimal_fms.sa1 = para.HASH_out.fmsc.sa1(out_idx);
            para.optimal_fms.sa2 = para.HASH_out.fmsc.sa2(out_idx);
            para.optimal_fms.oq  = para.HASH_out.fmsc.fmq{out_idx};
        end

        value = get(handle.h_listbox,'Value');
        set(handle.h_listbox,'Value',[]);
        pfm_callback_replot(h,dummy);
        set(handle.h_listbox,'Value',value);
%         pfm_callback_plot_optimal_fms(h,dummy);
        uicontrol(handle.h_hot);
    end

    function pfm_reset_output_listbox(h,dummy)
        para.pfm_out_list = {''};
        para.optimal_fms = [];
        set(handle.pfm_out_idx,'String',para.pfm_out_list,'value',1)
        set(handle.pfm_method_box,'Value',3)
    end

    function pfm_callback_plot_optimal_fms(h,dummy)
        [xs1,ys1] = FMnodline(para.optimal_fms.sk1,para.optimal_fms.da1,para.pfm_x0,para.pfm_y0,para.pfm_r0);
        [xs2,ys2] = FMnodline(para.optimal_fms.sk2,para.optimal_fms.da2,para.pfm_x0,para.pfm_y0,para.pfm_r0);
        px1 = [xs1,NaN,xs2];
        py1 = [ys1,NaN,ys2];
        plot(handle.pfm,px1,py1,para.pfm_selected_out_color,'linewidth',para.pfm_selected_out_linewidth);
    end

    function pfm_callback_compare_output(h,dummy)
        uicontrol(handle.h_hot); 
        out_idx    = get(handle.pfm_out_idx   ,'Value');
        method_idx = get(handle.pfm_method_box,'Value');

        if isempty(para.pfm_out_list{out_idx})
            return
        end

        sk1   = para.optimal_fms.sk1;
        sk2   = para.optimal_fms.sk2;
        da1   = para.optimal_fms.da1;
        da2   = para.optimal_fms.da2;
        sa1   = para.optimal_fms.sa1;
        sa2   = para.optimal_fms.sa2;
        fms_q = para.optimal_fms.oq ;

        if method_idx==1
            if ~isempty(para.HASH_out)
                sk     = para.HASH_out.fmsc.sk1;
                da     = para.HASH_out.fmsc.da1;
                sa     = para.HASH_out.fmsc.sa1;
                fms_q2 = para.HASH_out.fmsc.fmq;
                out_type = 2;
            else
                out_type = 1;
            end
            out_method  = 'CHNYTX';
            if get(handle.pfm_HASH_cal,'value')==1
                out_method2 = 'HASH_pol';
            else
                out_method2 = 'HASH_amp';
            end
        elseif method_idx==2
            if ~isempty(para.CHNYTX_out)
                sk     = para.CHNYTX_out.fmsc.sk1;
                da     = para.CHNYTX_out.fmsc.da1;
                sa     = para.CHNYTX_out.fmsc.sa1;
                fms_q2 = para.CHNYTX_out.fmsc.fmq;
                out_type = 2;
            else
                out_type = 1;
            end
            if get(handle.pfm_HASH_cal,'value')==1
                out_method  = 'HASH_pol';
            else
                out_method  = 'HASH_amp';
            end
            out_method2 = 'CHNYTX';
        end

        svpath = para.events{para.ievent};

        if exist(fullfile(svpath,para.fms_outfile),'file')
            delete(fullfile(svpath,para.fms_outfile));
        end
        if exist(fullfile(svpath,para.CHNYTX_acceptable_fms),'file')
            delete(fullfile(svpath,para.CHNYTX_acceptable_fms));
        end
        if exist(fullfile(svpath,para.HASH_acceptable_fms),'file')
            delete(fullfile(svpath,para.HASH_acceptable_fms));
        end
        
        fid    = fopen(fullfile(svpath,para.fms_outfile),'w');
        header = tr(1).headers;
        evdate = datetime(header.nzyear,1,1,0,0,0)+header.nzjday-1;

        if out_type == 2
            fprintf(fid,['#(Headline) year month day hour minute second latitude longitude depth ' ...
                'magnitude method1 strike1 dip1 rake1 strike1_auxiliary dip1_auxiliary ' ...
                'rake1_auxiliary quality1 method2 strike2 dip2 rake2 quality2 ' ...
                'rotation_angle quality_final\n']);
            fprintf(fid,['# CHNYTX_line(sort by reliability) strike dip rake strike_auxiliary dip_auxiliary ' ...
                'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl inconsistency_ratio ' ...
                'cluster_RMS alternative_solution_ratio cluster_id quality\n']);
            fprintf(fid,['# HASH_line(sort by probability) strike dip rake strike_auxiliary dip_auxiliary ' ...
                'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl fault_plane_uncertainty ' ...
                'auxiliary_plane_uncertainty numbers_of_P weighted_percent_misfit_of_first_motions ' ...
                'quality probability 100*station_distribution_ratio (number_of_S/P_ratios 100*average_log10(S/P)_misfit)\n']);
            min_angle = 180  ;
            min_sk    = sk(1);
            min_da    = da(1);
            min_sa    = sa(1);
            min_q     = ''   ;
            for ij = 1 : length(sk)
                rotate_angle = z_cal_rotate_angle([sk1,da1,sa1],[sk(ij),da(ij),sa(ij)]);
                if rotate_angle<min_angle
                    min_sk    = sk(ij);
                    min_da    = da(ij);
                    min_sa    = sa(ij);
                    min_angle = rotate_angle;
                    min_q     = fms_q2{ij};
                end
            end

            if isempty(min_q)
                warning('Error in calculating ratate angle!')
                return
            end

            if strcmp(fms_q,'A') && strcmp(min_q,'A') && min_angle<=para.out_rotate_angle
                para.optimal_fms.cq = 'A';
            elseif min_angle>para.out_rotate_angle
                para.optimal_fms.cq = 'C';
            else
                para.optimal_fms.cq = 'B';
            end

            fprintf(fid,['# %d %d %d %d %d %.6f ' ...
                '%.8f %.8f %.3f %.3f ' ...
                '%s %.1f %.1f %.1f %.1f %.1f %.1f %s ' ...
                '%s %.1f %.1f %.1f %s %.3f %s\n'],...
                header.nzyear,month(evdate),day(evdate), ... 
                header.nzhour,header.nzmin,header.nzsec+header.nzmsec/1000,... 
                header.evla,header.evlo,header.evdp,header.mag,...
                out_method,sk1,da1,sa1,sk2,da2,sa2,fms_q, ...
                out_method2,min_sk,min_da,min_sa,min_q,min_angle,para.optimal_fms.cq);
            for ic = 1 : length(para.CHNYTX_out.fmsc.sk1)
                fprintf(fid,['CHNYTX %.1f %.1f %.1f ' ...
                    '%.1f %.1f %.1f ' ...
                    '%.6f %.6f ' ...
                    '%.6f %.6f ' ...
                    '%.6f %.6f ' ...
                    '%.6f %.6f %.6f %d %s\n'],...
                para.CHNYTX_out.fmsc.sk1(ic),para.CHNYTX_out.fmsc.da1(ic),para.CHNYTX_out.fmsc.sa1(ic),...
                para.CHNYTX_out.fmsc.sk2(ic),para.CHNYTX_out.fmsc.da2(ic),para.CHNYTX_out.fmsc.sa2(ic),...
                para.CHNYTX_out.fmsc.paz(ic),para.CHNYTX_out.fmsc.ppl(ic),...
                para.CHNYTX_out.fmsc.baz(ic),para.CHNYTX_out.fmsc.bpl(ic),...
                para.CHNYTX_out.fmsc.taz(ic),para.CHNYTX_out.fmsc.tpl(ic),...
                para.CHNYTX_out.fmsc.disc(ic),para.CHNYTX_out.fmsc.rms(ic),...
                para.CHNYTX_out.fmsc.rel(ic),para.CHNYTX_out.fmsc.idnm(ic),...
                para.CHNYTX_out.fmsc.fmq{ic});
            end
            if get(handle.pfm_HASH_cal,'value')==1
                for ih = 1 : length(para.HASH_out.fmsc.sk1)
                    fprintf(fid,['HASH_pol %.1f %.1f %.1f ' ...
                        '%.1f %.1f %.1f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%d %d %d %d %s %d %d\n'],...
                    para.HASH_out.fmsc.sk1(ih),para.HASH_out.fmsc.da1(ih),para.HASH_out.fmsc.sa1(ih), ...
                    para.HASH_out.fmsc.sk2(ih),para.HASH_out.fmsc.da2(ih),para.HASH_out.fmsc.sa2(ih), ...
                    para.HASH_out.fmsc.paz(ih),para.HASH_out.fmsc.ppl(ih),...
                    para.HASH_out.fmsc.baz(ih),para.HASH_out.fmsc.bpl(ih),...
                    para.HASH_out.fmsc.taz(ih),para.HASH_out.fmsc.tpl(ih),...
                    para.HASH_out.fmsc.fp_er(ih),para.HASH_out.fmsc.ap_er(ih),...
                    para.HASH_out.fmsc.n_pol(ih),para.HASH_out.fmsc.weight_per_pol(ih),...
                    para.HASH_out.fmsc.fmq{ih},para.HASH_out.fmsc.prob(ih),...
                    para.HASH_out.fmsc.st_dr(ih));
                end
            else
                for ih = 1 : length(para.HASH_out.fmsc.sk1)
                    fprintf(fid,['HASH_amp %.1f %.1f %.1f '                 ...
                        '%.1f %.1f %.1f '                               ...
                        '%.6f %.6f '                                    ...
                        '%.6f %.6f '                                    ...
                        '%.6f %.6f '                                    ...
                        '%d %d %d %d %s %d %d %d %d\n'],                ...
                    para.HASH_out.fmsc.sk1(ih),                         ...
                    para.HASH_out.fmsc.da1(ih),                         ...
                    para.HASH_out.fmsc.sa1(ih),                         ...
                    para.HASH_out.fmsc.sk2(ih),                         ...
                    para.HASH_out.fmsc.da2(ih),                         ...
                    para.HASH_out.fmsc.sa2(ih),                         ...
                    para.HASH_out.fmsc.paz(ih),                         ...
                    para.HASH_out.fmsc.ppl(ih),                         ...
                    para.HASH_out.fmsc.baz(ih),                         ...
                    para.HASH_out.fmsc.bpl(ih),                         ...
                    para.HASH_out.fmsc.taz(ih),                         ...
                    para.HASH_out.fmsc.tpl(ih),                         ...
                    para.HASH_out.fmsc.fp_er(ih),                       ...
                    para.HASH_out.fmsc.ap_er(ih),                       ...
                    para.HASH_out.fmsc.n_pol(ih),                       ...
                    para.HASH_out.fmsc.weight_per_pol(ih),          ...
                    para.HASH_out.fmsc.fmq{ih},                         ...
                    para.HASH_out.fmsc.prob(ih),                        ...
                    para.HASH_out.fmsc.st_dr(ih),                       ...
                    para.HASH_out.fmsc.amp_num(ih),                     ...
                    para.HASH_out.fmsc.avg_amp_misfit(ih));
                end
            end
            fclose(fid);
            fprintf('The focal mechanism solution file has been output!\n')
            fprintf('   The minimum rotation angle: %.2f\n',min_angle)
            fprintf('   The quality of the optimal solution: %s\n',para.optimal_fms.cq)
        else
            if strcmp(out_method,'CHNYTX')
                
                fprintf(fid,['# (Headline) year month day hour minute second latitude longitude depth ' ...
                    'magnitude method1 strike1 dip1 rake1 strike1_auxiliary dip1_auxiliary ' ...
                    'rake1_auxiliary quality1\n']);
                fprintf(fid,['# CHNYTX_line(sort by reliability) strike dip rake strike_auxiliary dip_auxiliary ' ...
                    'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl inconsistency_ratio ' ...
                    'cluster_RMS alternative_solution_ratio cluster_id quality\n']);
                fprintf(fid,['# HASH_line(sort by probability) strike dip rake strike_auxiliary dip_auxiliary ' ...
                    'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl fault_plane_uncertainty ' ...
                    'auxiliary_plane_uncertainty numbers_of_P weighted_percent_misfit_of_first_motions ' ...
                    'quality probability 100*station_distribution_ratio (number_of_S/P_ratios 100*average_log10(S/P)_misfit)\n']);

                fprintf(fid,['# %d %d %d %d %d %.6f ' ...
                '%.8f %.8f %.3f %.3f ' ...
                '%s %.1f %.1f %.1f %.1f %.1f %.1f %s\n'],...
                header.nzyear,month(evdate),day(evdate), ... % year month day
                header.nzhour,header.nzmin,header.nzsec+header.nzmsec/1000,... % hour minute second
                header.evla,header.evlo,header.evdp,header.mag,...
                out_method,sk1,da1,sa1,sk2,da2,sa2,fms_q);

                for ic = 1 : length(para.CHNYTX_out.fmsc.sk1)
                    fprintf(fid,['CHNYTX %.1f %.1f %.1f ' ...
                        '%.1f %.1f %.1f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f %.6f %d %s\n'],...
                    para.CHNYTX_out.fmsc.sk1(ic),para.CHNYTX_out.fmsc.da1(ic),para.CHNYTX_out.fmsc.sa1(ic),...
                    para.CHNYTX_out.fmsc.sk2(ic),para.CHNYTX_out.fmsc.da2(ic),para.CHNYTX_out.fmsc.sa2(ic),...
                    para.CHNYTX_out.fmsc.paz(ic),para.CHNYTX_out.fmsc.ppl(ic),...
                    para.CHNYTX_out.fmsc.baz(ic),para.CHNYTX_out.fmsc.bpl(ic),...
                    para.CHNYTX_out.fmsc.taz(ic),para.CHNYTX_out.fmsc.tpl(ic),...
                    para.CHNYTX_out.fmsc.disc(ic),para.CHNYTX_out.fmsc.rms(ic),...
                    para.CHNYTX_out.fmsc.rel(ic),para.CHNYTX_out.fmsc.idnm(ic),...
                    para.CHNYTX_out.fmsc.fmq{ic});
                end
            else

                fprintf(fid,['#(Headline) year month day hour minute '  ...
                    'second latitude longitude depth magnitude '        ...
                    'method1 strike1 dip1 rake1 strike1_auxiliary '     ...
                    'dip1_auxiliary rake1_auxiliary quality1\n']);
                fprintf(fid,['# CHNYTX_line(sort by reliability) '      ...
                    'strike dip rake strike_auxiliary dip_auxiliary '   ...
                    'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl '     ...
                    'inconsistency_ratio cluster_RMS '                  ...
                    'alternative_solution_ratio cluster_id quality\n']);
                fprintf(fid,['# HASH_line(sort by probability) strike ' ...
                    'dip rake strike_auxiliary dip_auxiliary '          ...
                    'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl '     ...
                    'fault_plane_uncertainty '                          ...
                    'auxiliary_plane_uncertainty numbers_of_P '         ...
                    'weighted_percent_misfit_of_first_motions '         ...
                    'quality probability '                              ...
                    '100*station_distribution_ratio '                   ...
                    '(number_of_S/P_ratios '                            ...
                    '100*average_log10(S/P)_misfit)\n']);

                fprintf(fid,['# %d %d %d %d %d %.6f '                   ...
                '%.8f %.8f %.3f %.3f '                                  ...
                '%s %.1f %.1f %.1f %.1f %.1f %.1f %s\n'],               ...
                header.nzyear,month(evdate),day(evdate),                ... 
                header.nzhour,header.nzmin,header.nzsec+header.nzmsec/1000,... 
                header.evla,header.evlo,header.evdp,header.mag,         ...
                out_method,sk1,da1,sa1,sk2,da2,sa2,fms_q);

                if get(handle.pfm_HASH_cal,'value')==1
                    for ih = 1 : length(para.HASH_out.fmsc.sk1)
                        fprintf(fid,['HASH_pol %.1f %.1f %.1f '                ...
                            '%.1f %.1f %.1f '                           ...
                            '%.6f %.6f '                                ...
                            '%.6f %.6f '                                ...
                            '%.6f %.6f '                                ...
                            '%d %d %d %d %s %d %d\n'],                  ...
                        para.HASH_out.fmsc.sk1(ih),                     ...
                        para.HASH_out.fmsc.da1(ih),                     ...
                        para.HASH_out.fmsc.sa1(ih),                     ...
                        para.HASH_out.fmsc.sk2(ih),                     ...
                        para.HASH_out.fmsc.da2(ih),                     ...
                        para.HASH_out.fmsc.sa2(ih),                     ...
                        para.HASH_out.fmsc.paz(ih),                     ...
                        para.HASH_out.fmsc.ppl(ih),                     ...
                        para.HASH_out.fmsc.baz(ih),                     ...
                        para.HASH_out.fmsc.bpl(ih),                     ...
                        para.HASH_out.fmsc.taz(ih),                     ...
                        para.HASH_out.fmsc.tpl(ih),                     ...
                        para.HASH_out.fmsc.fp_er(ih),                   ...
                        para.HASH_out.fmsc.ap_er(ih),                   ...
                        para.HASH_out.fmsc.n_pol(ih),                   ...
                        para.HASH_out.fmsc.weight_per_pol(ih),          ...
                        para.HASH_out.fmsc.fmq{ih},                     ...
                        para.HASH_out.fmsc.prob(ih),                    ...
                        para.HASH_out.fmsc.st_dr(ih));
                    end
                else
                    for ih = 1 : length(para.HASH_out.fmsc.sk1)
                        fprintf(fid,['HASH_amp %.1f %.1f %.1f '                ...
                            '%.1f %.1f %.1f '                           ...
                            '%.6f %.6f '                                ...
                            '%.6f %.6f '                                ...
                            '%.6f %.6f '                                ...
                            '%d %d %d %d %s %d %d %d %d\n'],            ...
                        para.HASH_out.fmsc.sk1(ih),                     ...
                        para.HASH_out.fmsc.da1(ih),                     ...
                        para.HASH_out.fmsc.sa1(ih),                     ...
                        para.HASH_out.fmsc.sk2(ih),                     ...
                        para.HASH_out.fmsc.da2(ih),                     ...
                        para.HASH_out.fmsc.sa2(ih),                     ...
                        para.HASH_out.fmsc.paz(ih),                     ...
                        para.HASH_out.fmsc.ppl(ih),                     ...
                        para.HASH_out.fmsc.baz(ih),                     ...
                        para.HASH_out.fmsc.bpl(ih),                     ...
                        para.HASH_out.fmsc.taz(ih),                     ...
                        para.HASH_out.fmsc.tpl(ih),                     ...
                        para.HASH_out.fmsc.fp_er(ih),                   ...
                        para.HASH_out.fmsc.ap_er(ih),                   ...
                        para.HASH_out.fmsc.n_pol(ih),                   ...
                        para.HASH_out.fmsc.weight_per_pol(ih),          ...
                        para.HASH_out.fmsc.fmq{ih},                     ...
                        para.HASH_out.fmsc.prob(ih),                    ...
                        para.HASH_out.fmsc.st_dr(ih),                   ...
                        para.HASH_out.fmsc.amp_num(ih),                 ...
                        para.HASH_out.fmsc.avg_amp_misfit(ih));
                    end
                end
            end
            fclose(fid);
            fprintf('The focal mechanism solution file has been output!\n')
            fprintf('   The quality of the optimal solution: %s\n',fms_q)
        end
        
        if ~isempty(para.CHNYTX_out)
            if isfield(para.CHNYTX_out,'fms') && ~isempty(para.CHNYTX_out.fms)
                fid2 = fopen(fullfile(svpath,para.CHNYTX_acceptable_fms),'w');
                fprintf(fid2,['#(sort by inconsistency_ratio) strike dip rake strike_auxiliary dip_auxiliary ' ...
                    'rake_auxiliary p_az p_pl b_az b_pl t_az t_pl ' ...
                    'inconsistency_ratio cluster_id\n']);
                for ic = 1 : length(para.CHNYTX_out.fms.sk1)
                    fprintf(fid2,['%.1f %.1f %.1f ' ...
                        '%.1f %.1f %.1f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %.6f ' ...
                        '%.6f %d\n'],...
                        para.CHNYTX_out.fms.sk1(ic),para.CHNYTX_out.fms.da1(ic),para.CHNYTX_out.fms.sa1(ic),...
                        para.CHNYTX_out.fms.sk2(ic),para.CHNYTX_out.fms.da2(ic),para.CHNYTX_out.fms.sa2(ic),...
                        para.CHNYTX_out.fms.paz(ic),para.CHNYTX_out.fms.ppl(ic),...
                        para.CHNYTX_out.fms.baz(ic),para.CHNYTX_out.fms.bpl(ic),...
                        para.CHNYTX_out.fms.taz(ic),para.CHNYTX_out.fms.tpl(ic),...
                        para.CHNYTX_out.fms.disc(ic),para.CHNYTX_out.fms.cid(ic));
                end
                fclose(fid);
            end
        end
        if ~isempty(para.HASH_out)
            if isfield(para.HASH_out,'fms') && ~isempty(para.HASH_out.fms)
                fid3 = fopen(fullfile(svpath,para.HASH_acceptable_fms),'w');
                fprintf(fid3,['#(sort by probability) strike dip rake ' ...
                    'strike_auxiliary dip_auxiliary rake_auxiliary '    ...
                    'p_az p_pl b_az b_pl t_az t_pl\n']);
                for ih = 1 : length(para.HASH_out.fms.sk1)
                    fprintf(fid3,['%.1f %.1f %.1f '                     ...
                        '%.1f %.1f %.1f '                               ...
                        '%.6f %.6f '                                    ...
                        '%.6f %.6f '                                    ...
                        '%.6f %.6f\n'],                                 ...
                        para.HASH_out.fms.sk1(ih),                      ...
                        para.HASH_out.fms.da1(ih),                      ...
                        para.HASH_out.fms.sa1(ih),                      ...
                        para.HASH_out.fms.sk2(ih),                      ...
                        para.HASH_out.fms.da2(ih),                      ...
                        para.HASH_out.fms.sa2(ih),                      ...
                        para.HASH_out.fms.paz(ih),                      ...
                        para.HASH_out.fms.ppl(ih),                      ...
                        para.HASH_out.fms.baz(ih),                      ...
                        para.HASH_out.fms.bpl(ih),                      ...
                        para.HASH_out.fms.taz(ih),                      ...
                        para.HASH_out.fms.tpl(ih));
                end
                fclose(fid3);
            end
        end
        fprintf('Done!\n')
        uicontrol(handle.h_hot); 
    end

    function pfm_callback_load_save_file(h,dummy)
        para.optimal_fms = [];
        para.CHNYTX_out = [];
        para.HASH_out = [];
        fms_file = dir(fullfile(para.events{para.ievent},para.fms_outfile));
        if ~isempty(fms_file) && fms_file.bytes~=0
            fid = fopen(fullfile(para.events{para.ievent},para.fms_outfile));
            fgetl(fid); fgetl(fid); fgetl(fid); line = fgetl(fid);
            strs = split(line);
            para.optimal_fms.sk1 = str2double(strs{13});
            para.optimal_fms.da1 = str2double(strs{14});
            para.optimal_fms.sa1 = str2double(strs{15});
            para.optimal_fms.sk2 = str2double(strs{16});
            para.optimal_fms.da2 = str2double(strs{17});
            para.optimal_fms.sa2 = str2double(strs{18});
            idxc = 1;
            idxh = 1;
            while ~feof(fid)
                line = fgetl(fid);
                strs = split(line);
                if strcmp(strs{1},'CHNYTX')
                    para.CHNYTX_out.fmsc.sk1(idxc) = str2double(strs{2});
                    para.CHNYTX_out.fmsc.da1(idxc) = str2double(strs{3});
                    para.CHNYTX_out.fmsc.sa1(idxc) = str2double(strs{4});
                    para.CHNYTX_out.fmsc.sk2(idxc) = str2double(strs{5});
                    para.CHNYTX_out.fmsc.da2(idxc) = str2double(strs{6});
                    para.CHNYTX_out.fmsc.sa2(idxc) = str2double(strs{7});

                    para.CHNYTX_out.fmsc.paz(idxc) = str2double(strs{8});
                    para.CHNYTX_out.fmsc.ppl(idxc) = str2double(strs{9});
                    para.CHNYTX_out.fmsc.baz(idxc) = str2double(strs{10});
                    para.CHNYTX_out.fmsc.bpl(idxc) = str2double(strs{11});
                    para.CHNYTX_out.fmsc.taz(idxc) = str2double(strs{12});
                    para.CHNYTX_out.fmsc.tpl(idxc) = str2double(strs{13});

                    para.CHNYTX_out.fmsc.disc(idxc) = str2double(strs{14});
                    para.CHNYTX_out.fmsc.rms (idxc) = str2double(strs{15});
                    para.CHNYTX_out.fmsc.rel (idxc) = str2double(strs{16});
                    para.CHNYTX_out.fmsc.idnm(idxc) = str2double(strs{17});
                    para.CHNYTX_out.fmsc.fmq {idxc} = strs{18};

                    idxc = idxc + 1;
                else
                    if strcmp(strs{1},'HASH_pol')
                        set(handle.pfm_HASH_cal,'value',1);
                    else
                        set(handle.pfm_HASH_cal,'value',2);
                    end
                    para.HASH_out.fmsc.sk1(idxh) = str2double(strs{2});
                    para.HASH_out.fmsc.da1(idxh) = str2double(strs{3});
                    para.HASH_out.fmsc.sa1(idxh) = str2double(strs{4});
                    para.HASH_out.fmsc.sk2(idxh) = str2double(strs{5});
                    para.HASH_out.fmsc.da2(idxh) = str2double(strs{6});
                    para.HASH_out.fmsc.sa2(idxh) = str2double(strs{7});

                    para.HASH_out.fmsc.paz(idxh) = str2double(strs{8});
                    para.HASH_out.fmsc.ppl(idxh) = str2double(strs{9});
                    para.HASH_out.fmsc.baz(idxh) = str2double(strs{10});
                    para.HASH_out.fmsc.bpl(idxh) = str2double(strs{11});
                    para.HASH_out.fmsc.taz(idxh) = str2double(strs{12});
                    para.HASH_out.fmsc.tpl(idxh) = str2double(strs{13});

                    para.HASH_out.fmsc.fp_er(idxh)  = str2double(strs{14});
                    para.HASH_out.fmsc.ap_er(idxh)  = str2double(strs{15});
                    para.HASH_out.fmsc.n_pol(idxh)  = str2double(strs{16});
                    para.HASH_out.fmsc.weight_per_pol(idxh) = str2double(strs{17});
                    para.HASH_out.fmsc.fmq{idxh}    = strs{18};
                    para.HASH_out.fmsc.prob(idxh)   = str2double(strs{19});
                    para.HASH_out.fmsc.st_dr(idxh)  = str2double(strs{20});
                    if length(strs)>20
                        para.HASH_out.fmsc.amp_num(idxh)  = str2double(strs{21});
                        para.HASH_out.fmsc.avg_amp_misfit(idxh)  = str2double(strs{22});
                    end

                    idxh = idxh + 1;
                end
            end
            fclose(fid);
        end

        CHNYTX_file = dir(fullfile(para.events{para.ievent},para.CHNYTX_acceptable_fms));
        if ~isempty(CHNYTX_file) && CHNYTX_file.bytes~=0 && isfield(para.CHNYTX_out,'fmsc')
            fid = fopen(fullfile(para.events{para.ievent},para.CHNYTX_acceptable_fms),'r');
            C = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %d %*[^\n]','CommentStyle','#');
            para.CHNYTX_out.fms.sk1 = C{1};
            para.CHNYTX_out.fms.da1 = C{2};
            para.CHNYTX_out.fms.sa1 = C{3};
            para.CHNYTX_out.fms.sk2 = C{4};
            para.CHNYTX_out.fms.da2 = C{5};
            para.CHNYTX_out.fms.sa2 = C{6};

            para.CHNYTX_out.fms.paz = C{7};
            para.CHNYTX_out.fms.ppl = C{8};
            para.CHNYTX_out.fms.baz = C{9};
            para.CHNYTX_out.fms.bpl = C{10};
            para.CHNYTX_out.fms.taz = C{11};
            para.CHNYTX_out.fms.tpl = C{12};
            para.CHNYTX_out.fms.disc = C{13};
            para.CHNYTX_out.fms.cid = C{14};
            fclose(fid);
        end

        HASH_file = dir(fullfile(para.events{para.ievent},para.HASH_acceptable_fms));
        if ~isempty(HASH_file) && HASH_file.bytes~=0 && isfield(para.HASH_out,'fmsc')
            fid = fopen(fullfile(para.events{para.ievent},para.HASH_acceptable_fms),'r');
            C = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %*[^\n]','CommentStyle','#');
            para.HASH_out.fms.sk1 = C{1};
            para.HASH_out.fms.da1 = C{2};
            para.HASH_out.fms.sa1 = C{3};
            para.HASH_out.fms.sk2 = C{4};
            para.HASH_out.fms.da2 = C{5};
            para.HASH_out.fms.sa2 = C{6};

            para.HASH_out.fms.paz = C{7};
            para.HASH_out.fms.ppl = C{8};
            para.HASH_out.fms.baz = C{9};
            para.HASH_out.fms.bpl = C{10};
            para.HASH_out.fms.taz = C{11};
            para.HASH_out.fms.tpl = C{12};
            fclose(fid);
        end

    end


    function Pick_callback_iniplot(h, dummy) 
        
        uicontrol(handle.h_hot)
        
        cla(handle.hax,'reset');
        
        if ~exist(para.evlist,'file')
            fprintf('Evlist not exist!\n');
            para.evlist = [];
            para.ievent = 1;
            cla(handle.hax,'reset');
            set(handle.h_listbox, 'String', []);
            return;
        end
        
        if ~isfield(para,'ievent') || isempty(para.events)
            fid = fopen(para.evlist,'r');
            C = textscan(fid,'%s %*[^\n]','CommentStyle','#');
            para.events = C{1};
            fclose(fid);
            para.nevent = length(para.events);
            para.ievent = 1;
        end
        
        [ind, flag_file] = find_event_list_phase(para.ievent, para.events, para.listname, para.phasefile,'forward');
        if isempty(ind)
            para.ievent = para.nevent;
            Pick_callback_lastevent (h, dummy) 
        else
            para.ievent = ind;
        end

        pfm_reset_output_listbox(h,dummy);
        
        if flag_file == 1
            flag_file2 = 1;
            fid = fopen(fullfile(para.events{para.ievent},para.listname),'r');
            C = textscan(fid,'%s %*[^\n]','CommentStyle','#');
            lists = C{1};
            fclose(fid);
        elseif flag_file == 2
            flag_file2 = 2;
            fid = fopen(fullfile(para.events{para.ievent},para.phasefile),'r');
%             C = textscan(fid,'%s %f %f %f %f %s %s %f %*[^\n]','CommentStyle','#','EmptyValue',0);
            C = textscan(fid,'%s %f %f %f %f %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s %s %*[^\n]','CommentStyle','#','EmptyValue',0);

            lists    = C{1}; 
            phtt     = C{2}; 
            phtshift = C{3};
            polarity = C{5};
            phrayp   = C{8};
            snr0     = C{18};
            xcoeff0  = C{19};
            if ~isempty(C{23}{1})
                takeoff = C{20};
                pol_x0  = C{21};
                pol_y0  = C{22};
                Pphase  = C{23};
                pq      = C{24};
            else
                flag_file2 = 1;
            end
%             phT = C{4}; stnm = C{6}; netwk = C{7};
            fclose(fid);   
        else
            fprintf('No event found!\n');
            para.ievent = 1;
            return;
        end
        
        tr = [];
        handle.seis = {[]};
        para.iframe = 1;
        
        fprintf('Load in data ...\n');
%         hmsg = msgbox('Loading ...','Message','non-modal'); 
        num = 0; 
        t1 = [];
        para.nl = 0;

        for j = 1:length(lists)
            
            filename = char(lists(j));
            if exist(fullfile(para.events{para.ievent},filename),'file')
                [sachd,sacdat] = irdsac(fullfile(para.events{para.ievent},filename));
            else
                fprintf('No file %s found!\n',fullfile(para.events{para.ievent},filename));
                continue;
            end
            
            if isempty(sacdat) || max(isnan(sacdat)) == 1 || sachd.npts <= 1
                continue;
            end            
                        
            % calculate epicenteral distance and back azimuth 
            % modified by Chunquan Yu (2019/11/09) to take into account
            % ellipticity
%             [dist,baz] = distance(sachd.stla,sachd.stlo,sachd.evla,sachd.evlo);
%             az = azimuth(sachd.evla,sachd.evlo,sachd.stla,sachd.stlo);
            [dist,baz] = distance(sachd.stla,sachd.stlo,sachd.evla,sachd.evlo,[6378.137*180/pi/6371 0.0818191908426215]); %WGS84 reference ellipsoid
            az = azimuth(sachd.evla,sachd.evlo,sachd.stla,sachd.stlo,[6378.137*180/pi/6371 0.0818191908426215]); %WGS84 reference ellipsoid
            if flag_file == 1              
                if  isempty(t1) || sachd.evdp ~= para.evdp
                    para.evdp = sachd.evdp;
                    if para.evdp >= 999
                        fprintf('Evdp >= 999! Please check event depth. Depth units should be km!\n');
                        fprintf('Divide event depth by 1000!\n');
                        para.evdp = para.evdp/1000; % if evdp>999, convert m to km
                    end
                    
                    [rayp,taup,Xp] = phase_taup(para.phase,para.evdp,para.np,para.em,para.xdep);
                    t1 = taup + rayp.* Xp;
                    d1 = Xp*para.r2d;
                    
                    [ rayp, d1, t1 ] = y_firstarrival_interp( rayp, d1, t1 );
                    
                    d1 = rem(d1,360);
                    ind_major = find(d1>180);
                    d1(ind_major) = 360-d1(ind_major);
                end
                
                tt = interp1db(dist,d1,t1);
                if isnan(tt)
                    continue;
                end
                
                num = num + 1;
                tr(num).tt       = tt ;
                tr(num).tshift   = 0  ;
                tr(num).polarity = 1  ;
                tr(num).pq       = 'I';
%                 tr(num).rayp = interp1db(dist,d1,rayp/(para.em.re-para.evdp));
                tr(num).rayp = interp1db(dist,d1,rayp/111.1949/para.r2d);

%                 if strcmp(para.phase,'P')||strcmp(para.phase,'PF')||strcmp(para.phase,'Pg')||strcmp(para.phase,'Pn')
%                     tr(num).takeoff = z_cal_takeoff_angle_interp(rayp0,d0,t0,para.np,para.em,dist,para.evdp);
%                 end
                
                tr(num).xcoeff0 = 1;
                tr(num).snr0    = 1;
            else
                num = num + 1;
                tr(num).tt     = phtt(j);
                tr(num).tshift = phtshift(j);

                if polarity(j) == 1 || polarity(j) == -1
                    tr(num).polarity = polarity(j);
                else
                    tr(num).polarity = 1;
                end
                tr(num).rayp = phrayp(j);
                tr(num).xcoeff0 = xcoeff0(j);
                tr(num).snr0 = snr0(j);
                
                if flag_file2==2
                    tr(num).takeoff = takeoff(j);
                    tr(num).Pphase  = Pphase{j} ;
                    tr(num).pol_x0  = pol_x0(j) ;
                    tr(num).pol_y0  = pol_y0(j) ;
                    tr(num).pq      = pq{j}     ;
                end
            end
            
            tr(num).headers  = sachd;
            tr(num).data_raw = sacdat;
            tr(num).visible  = 1;
            tr(num).A0       = 1;
            tr(num).range    = 1;
            stnm_tmp  = deblank(reshape(sachd.kstnm,1,[]));
            netwk_tmp = deblank(reshape(sachd.knetwk,1,[]));
            ind1 = find(double(stnm_tmp)==0);
            ind2 = find(double(netwk_tmp)==0);
            if ~isempty(ind1)
                stnm_tmp = stnm_tmp(1:ind1(1)-1);
            end
            if ~isempty(ind2)
                netwk_tmp = netwk_tmp(1:ind2(1)-1);
            end
            tr(num).stnm     = stnm_tmp;
            tr(num).netwk    = netwk_tmp;
            tr(num).nstnm    = [netwk_tmp,'.',stnm_tmp];
            tr(num).filename = filename;                        
            tr(num).dist     = dist;
            tr(num).baz      = baz;
            tr(num).az       = az;
%             tr(num).az = y_azconvert(az,1);
            
            tr(num).dtshift   = 0;           
            tr(num).time_raw  = [0:tr(num).headers.npts-1]'*tr(num).headers.delta + tr(num).headers.b - tr(num).headers.o - tr(num).tt;
            tr(num).delta_raw = tr(num).headers.delta;
            
            tr(num).ccmean = 1;
        end
                
        if num == 0
            fprintf('No trace found!\n');
            return;
        end
        
        para.nl = num; 
        para.nframes = ceil(para.nl/para.n_per_frame);
        
        para.evla = tr(1).headers.evla;
        para.evlo = tr(1).headers.evlo;
        para.evdp = tr(1).headers.evdp;
        para.mag  = tr(1).headers.mag;
        if para.evdp >= 999
            fprintf('Event deep larger than 999, divided by 1000 to convert unit from m to km!\n');
            para.evdp = para.evdp/1000;
        end
        fprintf('\nEvent: %s\n',para.events{para.ievent});
        fprintf('First trace info:\n');
        fprintf('gcarc=%5.2f; az= %5.2f; baz= %5.2f; \nevla=%5.2f; evlo=%6.2f; evdp=%.0f; mag=%3.1f\n',tr(1).dist,tr(1).az,tr(1).baz,para.evla,para.evlo,para.evdp,para.mag);
        fprintf('Number of traces: %d\n', para.nl);                
        
        para.flag.cut    = 1;
        para.flag.sort   = 1;
        para.flag.filter = 1;
        para.flag.snr    = 1;
        
        set(handle.h_listbox,'Value',[]);
        Pick_callback_preprocess (h, dummy);

        if flag_file2 == 1
            pfm_callback_takeoff_angle(h,dummy);
        end

        Pick_callback_markphase (h, dummy);
        
        pfm_callback_load_save_file(h,dummy);
        pfm_callback_update_pfm(h,dummy);

        uicontrol(handle.h_hot)
        
%         ylim([0 0.3])
%         delete(hmsg);
    end

    function Pick_callback_preprocess (h, dummy)
        
        if para.flag.cut == 1
            for j = 1:para.nl
                tr(j).delta = para.delta;

                tr(j).time_cut = reshape(para.timewin(1):tr(j).delta:para.timewin(end),[],1);
                
                if length(tr(j).data_raw) > 1
                    data_raw = detrend(tr(j).data_raw);
%                     data_raw = data_raw.*tukeywin(length(data_raw),0.1);
                    tr(j).data_cut = interp1(tr(j).time_raw-tr(j).tshift,data_raw,tr(j).time_cut,'linear',nan);
%                     tr(j).data_cut = interp1(tr(j).time_raw-tr(j).tshift,tr(j).data_raw,tr(j).time_cut,'linear',nan);
                else
                    tr(j).data_cut = zeros(size(tr(j).time_cut));
                end
                tr(j).dtshift = 0;

                nonnan = find(~isnan(tr(j).data_cut));
                if ~isempty(nonnan)
                    tr(j).data_cut(1:nonnan(1)-1) = tr(j).data_cut(nonnan(1));
                    tr(j).data_cut(nonnan(end)+1:end) = tr(j).data_cut(nonnan(end));
                else
                    tr(j).data_cut = zeros(size(tr(j).data_cut));
                end
                tr(j).data_cut = reshape(tr(j).data_cut,[],1);
                
                if strcmpi(para.intederi_type,'int')
                    tr(j).data_cut = y_intederi(tr(j).data_cut,tr(j).delta,'int');
                elseif strcmpi(para.intederi_type,'der')
                    tr(j).data_cut = y_intederi(tr(j).data_cut,tr(j).delta,'der');
                end
                
                tr(j).data = tr(j).data_cut;
                tr(j).time = tr(j).time_cut;
            end
            
        end
        
        if para.flag.filter == 1
            index_filtertype = get(handle.h_filter_type,'Value');
            para.filter_type = para.filtertype_list{index_filtertype};
            for j = 1:para.nl

                tr(j).data = tr(j).data_cut;
                
                if para.fh >= 1/tr(j).delta/2
                    continue;
                end
                if max(tr(j).data) - min(tr(j).data) ~= 0
                    tr(j).data = detrend(tr(j).data);
                    tr(j).data = tr(j).data .* tukeywin(length(tr(j).data), 0.1);
                    
                    if strcmpi(para.filter_type,'Two-Pass')
                        if para.fl > 0 && para.fh > para.fl
                            tr(j).data = filtering(tr(j).data,tr(j).delta,para.fl,para.fh,para.order);
                        elseif para.fh > 0 && para.fl == 0
                            tr(j).data = filtering(tr(j).data,tr(j).delta,para.fh,'low',para.order);
                        elseif para.fl > 0 && para.fh == 0
                            tr(j).data = filtering(tr(j).data,tr(j).delta,para.fl,'high',para.order);
                        else
                            % no filtering
                        end
                    elseif strcmpi(para.filter_type,'One-Pass') 
                        if para.fl > 0 && para.fh > para.fl
                            tr(j).data = filtering_1pass(tr(j).data,tr(j).delta,para.fl,para.fh,para.order);
                        elseif para.fh > 0 && para.fl == 0
                            tr(j).data = filtering_1pass(tr(j).data,tr(j).delta,para.fh,'low',para.order);
                        elseif para.fl > 0 && para.fh == 0
                            tr(j).data = filtering_1pass(tr(j).data,tr(j).delta,para.fl,'high',para.order);
                        else
                            % no filtering
                        end
                    elseif strcmpi(para.filter_type,'Min-Phase')
                        if para.fl > 0 && para.fh > para.fl
                            tr(j).data = miniphase_filtering(tr(j).data,tr(j).delta,para.fl,para.fh,para.order);
                        elseif para.fh > 0 && para.fl == 0
                            tr(j).data = miniphase_filtering(tr(j).data,tr(j).delta,para.fh,'low',para.order);
                        elseif para.fl > 0 && para.fh == 0
                            tr(j).data = miniphase_filtering(tr(j).data,tr(j).delta,para.fl,'high',para.order);
                        else
                            % no filtering
                        end
                    else
                        fprintf('No filter type: %s available!\n',para.filter_type);
                        return;
                    end
                    
                    if strcmpi(para.intederi_type,'sqrt')
                        tr(j).data = sign(tr(j).data).*abs(tr(j).data).^(1/2);
                    elseif strcmpi(para.intederi_type,'4th')
                        tr(j).data = sign(tr(j).data).*abs(tr(j).data).^(1/4);
                    end
                end
            end
        end
        
        if para.flag.snr == 1
            for j = 1:para.nl
                tr(j).snr = 0;
                data_signal = interp1(tr(j).time,tr(j).data,para.signalwin(1):tr(j).delta:para.signalwin(2),'linear',0);
                data_noise  = interp1(tr(j).time,tr(j).data,para.noisewin(1):tr(j).delta:para.noisewin(2),'linear',0);
                if std(data_noise) > 0
                    tr(j).snr = std(data_signal)/std(data_noise);
                end
            end
        end
        
        if para.flag.sort == 1
            para.offset = [];
            if strcmpi(para.sort_type,'dist')
                for j = 1:para.nl,   tr(j).offset = tr(j).dist; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Distance (^o)';
            elseif strcmpi(para.sort_type,'az')
                for j = 1:para.nl,   tr(j).offset = tr(j).az; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Azimuth (^o)';
            elseif strcmpi(para.sort_type,'baz')
                for j = 1:para.nl,   tr(j).offset = tr(j).baz; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Back azimuth (^o)';            
            elseif strcmpi(para.sort_type,'snr')
                for j = 1:para.nl,   tr(j).offset = tr(j).snr; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Snr';
            elseif strcmpi(para.sort_type,'ccmean')
                for j = 1:para.nl,   tr(j).offset = tr(j).ccmean; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'CC coefficient';
            elseif strcmpi(para.sort_type,'snr0')
                for j = 1:para.nl,   tr(j).offset = tr(j).snr0; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Snr predefined';
            elseif strcmpi(para.sort_type,'xcoeff0')
                for j = 1:para.nl,   tr(j).offset = tr(j).xcoeff0; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Xcoeff predefined';
            elseif strcmpi(para.sort_type,'rayp')
                for j = 1:para.nl,   tr(j).offset = tr(j).rayp; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Ray para. (s/km)';
            elseif strcmpi(para.sort_type,'stla')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.stla; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Station lat. (^o)';
            elseif strcmpi(para.sort_type,'stlo')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.stlo; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Station lon. (^o)';
            elseif strcmpi(para.sort_type,'nstnm')
                [c,indtmp] = sort({tr.nstnm});
                for j = 1:para.nl,   tr(indtmp(j)).offset = j; para.offset(indtmp(j)) = tr(indtmp(j)).offset; end
                para.ylabel_name = 'Station name';    
            elseif strcmpi(para.sort_type,'tshift')
                for j = 1:para.nl,   tr(j).offset = tr(j).tshift; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Time shift (s)';
            elseif strcmpi(para.sort_type,'evla')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.evla; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Event lat. (^o)';
            elseif strcmpi(para.sort_type,'evlo')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.evlo; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Event lon. (^o)';
            elseif strcmpi(para.sort_type,'evdp')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.evdp; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Event depth (km)';
            elseif strcmpi(para.sort_type,'mag')
                for j = 1:para.nl,   tr(j).offset = tr(j).headers.mag; para.offset(j) = tr(j).offset; end
                para.ylabel_name = 'Magnitude';
            else
                fprintf('No sort type: %s ; Change to dist sort!\n', para.sort_type);
                for j = 1:para.nl,   tr(j).offset = tr(j).dist;  end
                para.ylabel_name = 'Distance (^o)';
            end
            [para.offset,indx] = sort(para.offset,'ascend');
            tr = tr(indx);
            para.ylabel_name_backup = para.ylabel_name;
        end
        
    end

    function Pick_callback_replot (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        
        handle.seis = [];

        if para.even_switch ~= 0
            para.offset = 1:para.nl;
            para.ylabel_name = 'Num';
        else
            for j = 1:para.nl, para.offset(j) = tr(j).offset; end
            para.ylabel_name = para.ylabel_name_backup;
        end
        
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        indj = j1:j2; %% 1:10
        
        if isempty(indj)
            return;
        end
        
        stnm_tmp = {[]};
        indtmp = get(handle.h_listbox_list,'Value');
        for j = indj
            if strcmpi(para.listbox_list{indtmp},'nstnm')
                stnm_tmp{max(indj)-j+1} = [tr(j).netwk,'.',tr(j).stnm];
            elseif strcmpi(para.listbox_list{indtmp},'stnm')
                stnm_tmp{max(indj)-j+1} = tr(j).stnm;
            elseif strcmpi(para.listbox_list{indtmp},'fname')
                stnm_tmp{max(indj)-j+1} = tr(j).filename;
            end
        end
        set(handle.h_listbox, 'String', stnm_tmp);
        list_entries = get(handle.h_listbox,'String');
        
        cla(handle.hax,'reset');
        axes(handle.hax);
        box on;
        hold (handle.hax, 'on');
        
        for j = indj
            tr(j).time = tr(j).time - tr(j).dtshift;
            tr(j).dtshift = 0;
        end
        
        doff = ( max(para.offset(indj)) - min(para.offset(indj)) ) / length(indj) ;
        if doff == 0
            doff = 1;       
        end
        
        amp_range = [];
        for j = indj
            tmp = interp1(tr(j).time, tr(j).data, para.normwin(1):tr(j).delta:para.normwin(end),'linear',0);
            amp_range(j-j1+1) = max(tmp) - min(tmp);
            if amp_range(j-j1+1) == 0
                tr(j).visible = 0;
                tr(j).A0      = 0;
            else
                tr(j).A0 = doff/amp_range(j-j1+1);
            end
            tr(j).range = amp_range(j-j1+1);
        end
        if strcmpi(para.norm_type,'all')
            for j = indj
                tr(j).A0 = doff/median(amp_range(find(amp_range))) ;
            end
        elseif strcmpi(para.norm_type,'each')
        end
        
        for kk = 1:length(para.phase_mark)
            para.phase_mark(kk).imark=1;
        end
        
        fprintf('Plotting ...\n');
        xlim_tmpL = para.x_lim(1);
        xlim_tmpR = para.x_lim(2);
        ht = [];
        hp = [];
        ntmp = 0;
        for j = indj            
            time_tmp = reshape(min(para.x_lim):tr(j).delta:max(para.x_lim),[],1);
            data_tmp = interp1(tr(j).time, tr(j).data*tr(j).polarity*tr(j).A0*para.scale, time_tmp ,'linear',0);
            
            if strcmpi(para.plot_type,'trace')
                handle.seis{j} = plot( handle.hax, time_tmp, para.offset(j) + data_tmp, 'color', para.color_show,'linewidth', para.linewidth_show);
            else
%                 handle.seis{j} = single_wig4( time_tmp, para.offset(j) + data_tmp);
                handle.seis{j} = single_wig7( time_tmp, data_tmp, para.offset(j));
                set(handle.seis{j}(1),'Facecolor',para.color_wig_up,'Edgecolor','none','Linewidth',para.linewidth_show);
                set(handle.seis{j}(2),'Facecolor',para.color_wig_dn,'Edgecolor','none','Linewidth',para.linewidth_show);
            end
            
            if tr(j).visible == 0
                set(handle.seis{j},'visible','off');
                list_entries{j2-j+1}=[];
            end
            
            if para.theo_switch == 1 && tr(j).visible == 1 
                hold on;
                plot(handle.hax, -tr(j).tshift, para.offset(j), 'color',para.color_theo,'Marker',para.marker_theo,'Markersize',para.msize_theo);
            end
            
            if para.phase_show == 1 && ~isempty(para.phase_mark) && tr(j).visible == 1
%                 tt_ref = tr(j).tt;
                tt_ref = interp1db(tr(j).dist,para.phase_ref.d1,para.phase_ref.t1);
                for kk = 1:length(para.phase_mark)
                    tt_tmp = interp1db(tr(j).dist,para.phase_mark(kk).d1,para.phase_mark(kk).t1);
                    if ~isnan(tt_tmp)
                        if (tt_tmp-tt_ref > xlim_tmpL) && (tt_tmp-tt_ref < xlim_tmpR)
                            hold on;
                            plot(handle.hax,[tt_tmp-tt_ref tt_tmp-tt_ref], [para.offset(j)-doff/2 para.offset(j)+doff/2],'color',para.phase_mark(kk).color,'Linewidth',para.linewidth_show);
                            if para.phase_mark(kk).imark == 1
                                ntmp = ntmp + 1;
                                hp(ntmp) = text(tt_tmp-tt_ref, para.offset(j)-doff, regexprep(para.phase_mark(kk).name,'x',num2str(para.xdep,'%d')),'color',para.phase_mark(kk).color,'FontWeight','bold');
                                para.phase_mark(kk).imark = 0;
                            end
                        end
                    end
                end
            end
            
            if tr(j).visible == 1 && get(handle.h_textpara,'Value')
                str = '';
                for kk = 1:length(para.text_para)
                    if strcmpi(para.text_para(kk),'dist')
                        str = [str,'  \Delta=',num2str(tr(j).dist,'%04.2f'),'^o'];
                    elseif strcmpi(para.text_para(kk),'az')
                        str = [str,'  Az=',num2str(tr(j).az,'%03.1f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'pol')
                        if tr(j).polarity==1, pol_str = 'Up     '; else, pol_str = 'Down';end
                        str = [str,'  pol=',pol_str];  
                    elseif strcmpi(para.text_para(kk),'pq')
                        str = [str,'  pq=',tr(j).pq];  
                    elseif strcmpi(para.text_para(kk),'pha')
                        str = [str,'  pha=',tr(j).Pphase];
                    elseif strcmpi(para.text_para(kk),'toa')
                        str = [str,'  toa=',num2str(tr(j).takeoff,'%03.1f'),'^o'];
                    elseif strcmpi(para.text_para(kk),'tshift')
                        str = [str,'  tshift=',num2str(tr(j).tshift,'%03.3f')];
                    elseif strcmpi(para.text_para(kk),'baz')
                        str = [str,'  Baz=',num2str(tr(j).baz,'%03.1f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'rayp')
                        str = [str,'  Rayp=',num2str(tr(j).rayp,'%.4f'),'s/km']; 
                    elseif strcmpi(para.text_para(kk),'stla')
                        str = [str,'  Stla=',num2str(tr(j).headers.stla,'%03.3f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'stlo')
                        str = [str,'  Stlo=',num2str(tr(j).headers.stlo,'%03.3f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'snr')
                        str = [str,'  Snr=',num2str(tr(j).snr,'%.2f')]; 
                    elseif strcmpi(para.text_para(kk),'snr0')
                        str = [str,'  Snr0=',num2str(tr(j).snr0,'%.2f')]; 
                    elseif strcmpi(para.text_para(kk),'ccmean')
                        str = [str,'  CCmean=',num2str(tr(j).ccmean,'%.2f')]; 
                    elseif strcmpi(para.text_para(kk),'xcoeff0')
                        str = [str,'  Xcoeff0=',num2str(tr(j).xcoeff0,'%.2f')]; 
                    elseif strcmpi(para.text_para(kk),'evla')
                        str = [str,'  Evla=',num2str(tr(j).headers.evla,'%03.3f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'evlo')
                        str = [str,'  Evlo=',num2str(tr(j).headers.evlo,'%03.3f'),'^o']; 
                    elseif strcmpi(para.text_para(kk),'evdp')
                        str = [str,'  Evdp=',num2str(tr(j).headers.evdp,'%03.1f'),'km']; 
                    elseif strcmpi(para.text_para(kk),'mag')
                        str = [str,'  Mag=',num2str(tr(j).headers.mag,'%03.1f'),'']; 
                    end
                end
                ht(j) = text(para.x_lim(1),para.offset(j),str,'HorizontalAlignment','left','VerticalAlignment','bottom');
            end
        end
        set(handle.h_listbox, 'String', list_entries);
        
        dy = 2*doff;
        xlim(para.x_lim);
        ylim([min(para.offset(indj))-dy max(para.offset(indj))+dy]);
        xlabel(para.xlabel_name);
        ylabel(para.ylabel_name);
        
        hold on
        plot([0 0], [min(para.offset(indj))-dy max(para.offset(indj))+dy],'k-.','LineWidth',0.2);
        if para.xy_switch == 0
            view(handle.hax,0,90);
        else
            view(handle.hax,90,90);
            set(ht,'rotation',-90);
%             set(hp,'rotation',-90);
        end
        
        [natmp1,natmp2,natmp3] = fileparts(para.events{para.ievent});
        if isempty(natmp2)
            [natmp1,natmp2,natmp3] = fileparts(natmp1);
        end
        ename = regexprep([natmp2,natmp3],'_','\\_');
        title(handle.hax, [ename,'\newlineevla=',num2str(para.evla,'%.4f'),'^o, evlo=',num2str(para.evlo,'%.4f'),'^o\newlineevdp=',num2str(para.evdp,'%.1f'),' km, mag=',num2str(para.mag,'%.1f')]);
        
        set(handle.h_ievent,'String',num2str(para.ievent));
        set(handle.h_iframe,'String',num2str(para.iframe));
        
        fprintf('ievent= %d\n',para.ievent);
        fprintf('iframe= %d\n\n',para.iframe);
        uicontrol(handle.h_hot);
        figure(handle.f1);
    end

    function Pick_callback_vmodel (h,dummy)
        old_mod = para.mod;
        old_fullvmod = para.fullvmod;
        index_vmodel = get(handle.h_vmodel_list,'Value');
        para.mod     = para.vmodel_list{index_vmodel};
        [em,para.mod,para.fullvmod] = z_set_vmodel_v0(para.mod);
        if isempty(em)
            para.mod = old_mod;
            para.fullvmod = old_fullvmod;
            if ismember(para.mod,para.vmodel_list)
                idx = find(strcmp(para.mod,para.vmodel_list));
                set(handle.h_vmodel_list,'Value',idx);
            else
                set(handle.h_vmodel_list,'Value',4);
                % para.mod = 'another';
            end
            return
        end
        % fprintf('%s\n',para.mod);
        if ~exist(fullfile(para.path,'HASH','vmodels',[para.mod '.vel']),'file')
            dp = em.z;
            vp = em.vp;
            idx = find(diff(dp)<1e-6);
            dp(idx) = [];
            vp(idx) = [];
            fid = fopen(fullfile(para.path,'HASH','vmodels',[para.mod '.vel']),'w');
            for i = 1 : length(dp)
                fprintf(fid,'%.4f %.4f\n',dp(i),vp(i));
            end
            fclose(fid);
        end
        para.em = refinemodel(em, para.thmax);

        ind = find(diff(para.em.z)<1e-6);
        para.em.z(ind+1) = para.em.z(ind) + 1e-6;

        if ~isfield(para,'nevent')
            return;
        end

        Pick_callback_markphase (h, dummy);

        pfm_callback_takeoff_angle(h,dummy)
        pfm_callback_update_pfm(h,dummy);
        
    end
        
    function Pick_callback_intederi (h, dummy)
        
        if ~isfield(para,'nevent')
            return;
        end
        
        index_intederi     = get(handle.h_intederi_list,'Value');
        para.intederi_type = para.intederi_list{index_intederi};
        
        para.flag.cut    = 1;
        para.flag.filter = 1;
        para.flag.sort   = 0;
        para.flag.snr    = 1;
        Pick_callback_preprocess (h, dummy);
        Pick_callback_replot (h, dummy);
        
    end

    function Pick_callback_choosephase (h, dummy)
        
        uicontrol(handle.h_hot);
        list_phase  = get(handle.h_phase_list,'String');
        index_phase = get(handle.h_phase_list,'Value');
        para.phase  = list_phase{index_phase};
        fprintf('Phase %s selected!\n',para.phase);
        if strfind(lower(para.phase),'x')
            flag_xdep = 0;
            while flag_xdep == 0
                xdep_temp = input('Please input x depth!\n','s');
                xdep_temp = str2num(xdep_temp);
                if ~isempty(xdep_temp)
                    if xdep_temp >= 0 && xdep_temp < para.em.z_cmb
                        para.xdep = xdep_temp;
                        flag_xdep = 1;
                    else
                        fprintf('Xdep should be smaller than CMB depth!\n');
                    end
                else
                    fprintf('Xdep should be a positive number!\n');
                end
            end
        end
        
        para.phasefile = [para.listname,'_',para.phase,para.phasefileapp];
                
        if ~isfield(para,'nevent')
            return;
        end
        Pick_callback_iniplot (h, dummy);
    end

    function Pick_callback_markphase (h,dummy)                                           %% calculate phase time
              
        uicontrol(handle.h_hot);  
        if ~isfield(para,'iframe')
            return;
        end
        phase_all = get(handle.h_mark_all,'Value');
        ind_phase = get(handle.h_mark_phase,'Value');
        para.phase_show = get(handle.h_mark_show,'Value');
        para.phase_mark = [];
        if para.phase_show == 1 && ~isempty(para.nl)
            Mxdep = []; Mphase_mark = []; Mphaselist = []; Mevdp = [];
            if exist(para.taupmat,'file') 
                fprintf('\nMark all phases\n Load in phases ...\n');
                C = load(para.taupmat);
                Mxdep = C.Mxdep; Mphase_mark = C.Mphase_mark; Mphaselist = C.Mphaselist; Mevdp = C.Mevdp;
            else 
                fprintf('\nMark all phases\n Calculating ...\n');
            end
            
            if phase_all == 1
                phaselist_tmp = para.phaselist;
            else
                phaselist_tmp = para.phaselist(ind_phase);
            end
            
            for kk = 1:length(phaselist_tmp)
                indph_tmp = 0;
                if ~isempty(Mxdep)
                    for kkk = 1:length(Mphaselist)
                        if ~strfind(phaselist_tmp{kk},'x')
                            if strcmp(phaselist_tmp{kk},Mphaselist{kkk})
                                indph_tmp = kkk; break;
                            end
                        else
                            if strcmp(phaselist_tmp{kk},Mphaselist{kkk}) && para.xdep == Mxdep
                                indph_tmp = kkk; break;
                            end
                        end
                    end
                end
                
                if indph_tmp ~= 0
                    ind_depth = find(Mevdp-para.evdp<=0, 1, 'last');
                    t1_tmp1 = Mphase_mark(indph_tmp,ind_depth).t1;
                    t1_tmp2 = Mphase_mark(indph_tmp,ind_depth+1).t1;
                    d1_tmp1 = Mphase_mark(indph_tmp,ind_depth).d1;
                    d1_tmp2 = Mphase_mark(indph_tmp,ind_depth+1).d1;
                    
                    if length(t1_tmp1) ~= length(t1_tmp2)
                        t1_tmp1 = linspace(t1_tmp1(1),t1_tmp1(end),np);
                        t1_tmp2 = linspace(t1_tmp2(1),t1_tmp2(end),np);
                        d1_tmp1 = linspace(d1_tmp1(1),d1_tmp1(end),np);
                        d1_tmp2 = linspace(d1_tmp2(1),d1_tmp2(end),np);
                    end
                    rr = abs(Mevdp(ind_depth+1)-Mevdp(ind_depth));
                    r1 = abs(para.evdp - Mevdp(ind_depth))/rr;
                    r2 = abs(Mevdp(ind_depth+1) - para.evdp)/rr;
                    
                    para.phase_mark(kk).t1 = r2*t1_tmp1 + r1*t1_tmp2;
                    para.phase_mark(kk).d1 = r2*d1_tmp1 + r1*d1_tmp2;
                else
                    [rayp,taup,Xp] = phase_taup(phaselist_tmp{kk}, para.evdp, para.np, para.em, para.xdep);
                    t1 = taup + rayp.* Xp;
                    d1 = Xp*para.r2d;
                    
                    [ rayp, d1, t1 ] = y_firstarrival_interp( rayp, d1, t1 );
                    
                    d1 = rem(d1,360);
                    ind_major = find(d1>180);
                    d1(ind_major) = 360-d1(ind_major);
                    
                    para.phase_mark(kk).t1 = t1;
                    para.phase_mark(kk).d1 = d1;
                end
                para.phase_mark(kk).name = phaselist_tmp{kk};
                para.phase_mark(kk).evdp = para.evdp;
                para.phase_mark(kk).color = para.colorpool{mod(kk-1,length(para.colorpool))+1};
                para.phase_mark(kk).imark = 1;
            end
            
            [rayp,taup,Xp] = phase_taup(para.phase, para.evdp, para.np, para.em, para.xdep);
            t1 = taup + rayp.* Xp;
            d1 = Xp*para.r2d;

            [ rayp, d1, t1 ] = y_firstarrival_interp( rayp, d1, t1 );            
            d1 = rem(d1,360);
            
            para.phase_ref.t1 = t1;
            para.phase_ref.d1 = d1;
            
        end
        Pick_callback_replot (h,dummy)
    end

    function Pick_callback_sort (h, dummy)
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        index_sort = get(handle.h_sort_list,'Value');
        if length(index_sort) == 1
            para.sort_type = para.sortlist{index_sort};
            para.iframe    = 1;
            fprintf('Sort traces according to %s\n',para.sort_type);
            para.flag.cut    = 0;
            para.flag.sort   = 1;
            para.flag.filter = 0;
            para.flag.snr    = 0;
            Pick_callback_preprocess (h, dummy);
            Pick_callback_replot (h, dummy);
            set(handle.h_listbox,'Value',[]);
        end
    end

    function Pick_callback_plotype (h, dummy)

        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        index_plotype = get(handle.h_plotype_list,'Value');
        if length(index_plotype) == 1
            para.plot_type = para.plotype_list{index_plotype};
        end
        fprintf('Plot type: %s\n',para.plot_type);
        Pick_callback_replot (h,dummy)
    end

    function Pick_callback_norm (h, dummy)

        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        list_normtype  = get(handle.h_normtype_list,'String');
        index_normtype = get(handle.h_normtype_list,'Value');
        if length(index_normtype) == 1
            para.norm_type = list_normtype{index_normtype};
        end
        tmpL = str2num(get(handle.h_normwin_L,'String'));
        tmpR = str2num(get(handle.h_normwin_R,'String'));
        if ~isempty(tmpL) && ~isempty(tmpR)
            para.normwin(1) = tmpL;
            para.normwin(2) = tmpR;
            fprintf('normalization type: %s\n',para.norm_type);
            Pick_callback_replot (h, dummy);
        end
    end

    function Pick_callback_tracenumber (h, dummy)

        uicontrol(handle.h_hot);
        para.n_per_frame = floor(str2num(get(handle.h_ntrace_num,'String')));        
        if ~isfield(para,'iframe')
            return;
        end
        para.nframes = ceil (para.nl/para.n_per_frame);
        para.iframe  = 1;
        set(handle.h_listbox, 'Value', 1);
        fprintf('Number of trace per frame set to %d\n',para.n_per_frame);
        Pick_callback_replot (h, dummy);
        
        if get(handle.pfm_auto_plot_pol,'Value')
            pfm_callback_replot(h,dummy)
        end

    end

    function Pick_callback_filter (h, dummy)
                
        uicontrol(handle.h_hot);
        fl_temp    = str2num(get(handle.h_filter_fl,'String'));
        fh_temp    = str2num(get(handle.h_filter_fh,'String'));
        order_temp = str2num(get(handle.h_order,'String'));
        if ~isempty(fl_temp) && ~isempty(fh_temp) && isnumeric(order_temp)
            para.fl    = fl_temp;
            para.fh    = fh_temp;
            para.order = order_temp;
        else
            para.fl    = 0;
            para.fh    = 0;
            para.order = 0;
            fprintf('No filtering!\n');
        end
        
        if ~isfield(para,'iframe')
            return;
        end
        para.flag.cut    = 0;
        para.flag.sort   = 0;
        para.flag.filter = 1;
        para.flag.snr    = 1;
        Pick_callback_preprocess (h, dummy);
        Pick_callback_replot (h, dummy);
    end

    function Pick_callback_ampup (h, dummy)
        uicontrol(handle.h_hot);
        para.scale = para.scale * 1.25;
        Pick_callback_replot (h, dummy);
    end

    function Pick_callback_ampdown (h, dummy)
        uicontrol(handle.h_hot);
        para.scale = para.scale * 0.8;
        Pick_callback_replot (h, dummy);
    end

    function Pick_callback_timeup (h, dummy)
        
        uicontrol(handle.h_hot);
        para.x_lim = para.x_lim*0.8;
        Pick_callback_replot (h,dummy);
    end

    function Pick_callback_timedown (h, dummy)
        
        uicontrol(handle.h_hot);
        para.x_lim = para.x_lim*1.25;
        Pick_callback_replot (h,dummy);
    end

    function Pick_callback_theoplot (h, dummy)
        
        uicontrol(handle.h_hot);
        para.theo_switch = get(handle.theoplot_button,'Value');
        Pick_callback_replot (h,dummy)
        fprintf('Plot theoretical phase arrival time\n');
    end

    function Pick_callback_xyswitch (h,dummy)
        uicontrol(handle.h_hot);
        para.xy_switch = get(handle.xy_button,'Value');
        Pick_callback_replot (h,dummy);
        fprintf('X<->Y axis reverse!\n');
    end

    function Pick_callback_even (h,dummy)
        uicontrol(handle.h_hot);
        para.even_switch = get(handle.even_button,'Value');         
        fprintf('Evenly/Unevenly distributed!\n')
        Pick_callback_replot (h, dummy);
    end

    function Pick_callback_polarity (h,dummy)
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        fprintf('Polarity change!\n')
        for j = 1:para.nl
            tr(j).polarity = -1*tr(j).polarity;
        end
        Pick_callback_replot (h,dummy);
    end

    function Pick_callback_delta (h,dummy)
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        delta_tmp = str2num(get(handle.h_delta,'String'));
        if ~isempty(delta_tmp)
            fl_temp = str2num(get(handle.h_filter_fl,'String'));
            fh_temp = str2num(get(handle.h_filter_fh,'String'));
            if ~isempty(fl_temp) && ~isempty(fh_temp)
                if isinf(1/2/delta_tmp)
                    fprintf('Please check delta!\n');
                elseif 1/2/delta_tmp > max(fl_temp,fh_temp)
                    fprintf('Resampling rate %f\n',delta_tmp);
                    para.delta       = delta_tmp;
                    para.flag.cut    = 1;
                    para.flag.sort   = 0;
                    para.flag.filter = 1;
                    Pick_callback_preprocess (h,dummy)
                    Pick_callback_replot (h,dummy)
                else
                    fprintf('Please check Nyquist frequency! It should be large enough!\n');
                end
            else
                fprintf('Please check filter width!\n');
            end
        end
        
    end

    function Pick_callback_textpara(h,dummy)
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end                
        if get(handle.h_textpara,'Value') == 1            
                        
            dlg_title = 'Text parameters';
            basestr = para.text_list{1};
            for i = 2:length(para.text_list)
                basestr = [basestr,',',para.text_list{i}];
            end
            prompt = {['1st (',basestr,')'],['2nd (',basestr,')'],['3rd (',basestr,')'],['4th (',basestr,')'],['5th (',basestr,')']};
            def = para.text_para;
            if length(def) < length(prompt)
                def(length(def)+1:length(prompt)) = {''};
            else
                def = def(1:length(prompt));
            end
            options.Resize      = 'on';
            options.WindowStyle = 'normal';
            options.Interpreter = 'tex';
            % answer = inputdlg(prompt,dlg_title,length(prompt),def,options);
            answer = inputdlg(prompt,dlg_title,3,def,options);
            
            if isempty(answer)
                set(handle.h_textpara,'Value',0);
            else                
                para.text_para = {};
                num = 0;
                for i = 1:length(answer)
                    ind = find(strcmpi(para.text_list,deblank(answer{i})));
                    if ind
                        num = num + 1;
                        para.text_para(num) = para.text_list(ind(1));
                    end
                end
            end
        end
        Pick_callback_replot (h,dummy);        
    end


%% window panel functions
    function Pick_callback_window (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        timewin_tmpL   = str2num(get(handle.h_timewin_L,'String'));
        timewin_tmpR   = str2num(get(handle.h_timewin_R,'String'));
        xlim_tmpL      = str2num(get(handle.h_xlim_L,'String'));
        xlim_tmpR      = str2num(get(handle.h_xlim_R,'String'));
        signalwin_tmpL = str2num(get(handle.h_signalwin_L,'String'));
        signalwin_tmpR = str2num(get(handle.h_signalwin_R,'String'));
        noisewin_tmpL  = str2num(get(handle.h_noisewin_L,'String'));
        noisewin_tmpR  = str2num(get(handle.h_noisewin_R,'String'));
        normwin_tmpL   = str2num(get(handle.h_normwin_L,'String'));
        normwin_tmpR   = str2num(get(handle.h_normwin_R,'String'));
        
        if ~isempty(timewin_tmpL) && ~isempty(timewin_tmpR) && ~isempty(xlim_tmpL) && ~isempty(xlim_tmpR) && ~isempty(signalwin_tmpL) && ~isempty(signalwin_tmpR) && ~isempty(noisewin_tmpL) && ~isempty(noisewin_tmpR) && ~isempty(normwin_tmpL) && ~isempty(normwin_tmpR)
            para.timewin(1)   = timewin_tmpL;
            para.timewin(2)   = timewin_tmpR;
            para.x_lim(1)     = xlim_tmpL;
            para.x_lim(2)     = xlim_tmpR;
            para.signalwin(1) = signalwin_tmpL;
            para.signalwin(2) = signalwin_tmpR;
            para.noisewin(1)  = noisewin_tmpL;
            para.noisewin(2)  = noisewin_tmpR;
            para.normwin(1)   = normwin_tmpL;
            para.normwin(2)   = normwin_tmpR;
            
            para.flag.cut    = 1;
            para.flag.sort   = 0;
            para.flag.filter = 1;
            para.flag.snr    = 1;

            Pick_callback_preprocess (h, dummy);
            Pick_callback_replot (h, dummy);
        else
            fprintf('Please check time window!\n')
        end
    end


    function Pick_callback_gpick ( h,dummy)
        para.zoom = get(handle.zoom,'Enable');

        if ~isfield(para,'iframe')
            return;
        end

        [x1,y1,but1] = myginput(1,'crosshair');
        
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        [c,index_selected] = min(abs(para.offset(j1:j2)-y1));
        index_selected = j2-j1-index_selected+2;
        
        for k = j1:j2
            if length(handle.seis{k}) == 1
                set( handle.seis{k} , 'color',para.color_show,'linewidth',para.linewidth_show);
            else
                set( handle.seis{k}(1) , 'Facecolor',para.color_wig_up,'edgecolor','none','linewidth',para.linewidth_show);
                set( handle.seis{k}(2) , 'Facecolor',para.color_wig_dn,'edgecolor','none','linewidth',para.linewidth_show);
            end
        end
        
        j = j2 - index_selected + 1;
        for k = 1:length(j)
            if length(handle.seis{j(k)}) == 1
                set( handle.seis{j(k)} , 'color',para.color_selected,'linewidth',para.linewidth_selected);
            else
                set( handle.seis{j(k)}(1) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
                set( handle.seis{j(k)}(2) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
            end
        end

        set(handle.h_listbox,'Value',index_selected);    

        pfm_callback_listbox_select(h, dummy);
        handle.zoom.Enable = para.zoom;

        uicontrol(handle.h_listbox)
    end


%% I/O panel functions
    function Pick_callback_load_evlist(h,dummy)
        
        uicontrol(handle.h_hot);
        [templist, temppath] = uigetfile({'*.txt','Txt Files (*.txt)';'*.m;*.fig;*.mat;*.mdl','Matlab Files (*.m,*.fig,*.mat,*.mdl)';'*.*', 'All Files (*.*)'}, 'Load event list',para.evpathname);
        if templist == 0
            uicontrol(handle.h_hot)
        else
            para.evpathname = temppath;
            para.evlistname = templist;
            set(handle.h_evlist,'String', para.evlistname);
            para.evlist = fullfile(para.evpathname,para.evlistname);
            para.events = [];
            Pick_callback_iniplot(h,dummy)
        end
    end

    function Pick_callback_load_evlist_2(h,dummy)
        
        uicontrol(handle.h_hot);
        para.evlistname = get(handle.h_evlist,'String');
        set(handle.h_evlist,'String', para.evlistname);
        para.evlist = fullfile(para.evpathname,para.evlistname);
        para.events = [];
        
        Pick_callback_iniplot(h,dummy)
    end

    function Pick_callback_load_listname (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'ievent')
            return;
        end
        [templist, temppath] = uigetfile({'*list*', 'List Files (*list*)';'*.txt','Txt Files (*.txt)';'*.m;*.fig;*.mat;*.mdl','Matlab Files (*.m,*.fig,*.mat,*.mdl)';'*.*', 'All Files (*.*)'}, 'Load event list',para.events{para.ievent});
        
        if templist ~= 0
            if strcmp(temppath(end),'/') || strcmp(temppath(end),'\')
                temppath = temppath(1:end-1);
            end
            [temp1,temp2,temp3] = fileparts(temppath);
            evname = [temp2,temp3];
            
            ind = strfind(para.events,evname);
            tempev = find(~cellfun(@isempty,ind));
            if ~isempty(tempev)
                para.listname = templist;
                for k = 1:length(para.phaselist)
                    phasefiletail = ['_',para.phaselist{k},para.phasefileapp];
                    ltail = length(phasefiletail);
                    if length(templist)>=ltail && strcmp(templist(end-ltail+1:end),phasefiletail)
                        para.listname = templist(1:end-ltail);
                        para.phase    = para.phaselist{k};
                        set(handle.h_phase_list,'Value',k);
                        break;
                    end
                end
                
                para.phasefile = [para.listname,'_',para.phase,para.phasefileapp];
                set(handle.h_listname,'String', para.listname);
                para.ievent    = tempev(1);
                Pick_callback_iniplot(h,dummy)
            end
        else
            pfm_callback_update_pfm(h,dummy);
        end
        uicontrol(handle.h_hot)
    end

    function Pick_callback_load_listname_2 (h, dummy)
        
        uicontrol(handle.h_hot);
        para.listname = get(handle.h_listname,'String');
        for k = 1:length(para.phaselist)
            phasefiletail = ['_',para.phaselist{k},para.phasefileapp];
            ltail = length(phasefiletail);
            if length(para.listname)>=ltail && strcmp(para.listname(end-ltail+1:end),phasefiletail) % in case read in phase file
                para.listname = para.listname(1:end-ltail);
                para.phase    = para.phaselist{k};
                set(handle.h_phase_list,'Value',k);
                break;
            end
        end
        
        para.phasefile = [para.listname,'_',para.phase,para.phasefileapp];
        if ~isfield(para,'ievent')
            return;
        end
        Pick_callback_iniplot(h,dummy)
        uicontrol(handle.h_hot);
    end

    function Pick_callback_del_event (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'ievent')
            return;
        end
        fprintf('Delete Event: %s \n',para.events{para.ievent});
        fid2 = fopen(fullfile(para.events{para.ievent},para.phasefile),'w');
        fclose(fid2);
        Pick_callback_nextevent (h,dummy)
    end

    function Pick_callback_reset_event (h, dummy)
        uicontrol(handle.h_hot);
        if ~isfield(para,'ievent')
            return;
        end
        if exist(fullfile(para.events{para.ievent},para.phasefile),'file')
            delete(fullfile(para.events{para.ievent},para.phasefile));
        end
        if exist(fullfile(para.events{para.ievent},para.fms_outfile),'file')
            delete(fullfile(para.events{para.ievent},para.fms_outfile));
        end
        if exist(fullfile(para.events{para.ievent},para.CHNYTX_acceptable_fms),'file')
            delete(fullfile(para.events{para.ievent},para.CHNYTX_acceptable_fms));
        end
        if exist(fullfile(para.events{para.ievent},para.HASH_acceptable_fms),'file')
            delete(fullfile(para.events{para.ievent},para.HASH_acceptable_fms));
        end
        fprintf('Reset Event: %s\n',para.events{para.ievent});
        para.CHNYTX_out  = [];
        para.HASH_out    = [];
        pfm_reset_output_listbox(h,dummy);
        Pick_callback_iniplot (h, dummy);
    end

    function Pick_callback_save (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'ievent')
            return;
        end
        fid2 = fopen(fullfile(para.events{para.ievent},para.phasefile),'w');
%         fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz\n');
%         fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz snr0 xcoeff0\n');
        fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz snr0 xcoeff0 take-off_angle pol_x0 pol_y0 first_arrival_P-phase polarity_quality\n');
        for j=1 : para.nl
            if tr(j).visible == 1
%                 fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f\n',tr(j).filename, tr(j).tt, tr(j).tshift, tr(j).tt+tr(j).tshift, tr(j).polarity,tr(j).stnm,tr(j).netwk, tr(j).rayp, tr(j).headers.stla, tr(j).headers.stlo, tr(j).headers.stel, tr(j).headers.evla, tr(j).headers.evlo, tr(j).headers.evdp, tr(j).dist, tr(j).az, tr(j).baz);
%                 fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f\n',tr(j).filename, tr(j).tt, tr(j).tshift, tr(j).tt+tr(j).tshift, tr(j).polarity,tr(j).stnm,tr(j).netwk, tr(j).rayp, tr(j).headers.stla, tr(j).headers.stlo, tr(j).headers.stel, tr(j).headers.evla, tr(j).headers.evlo, tr(j).headers.evdp, tr(j).dist, tr(j).az, tr(j).baz, tr(j).snr0, tr(j).xcoeff0);
%                 fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s\n',tr(j).filename, tr(j).tt, tr(j).tshift, tr(j).tt+tr(j).tshift, tr(j).polarity,tr(j).stnm,tr(j).netwk, tr(j).rayp, tr(j).headers.stla, tr(j).headers.stlo, tr(j).headers.stel, tr(j).headers.evla, tr(j).headers.evlo, tr(j).headers.evdp, tr(j).dist, tr(j).az, tr(j).baz, tr(j).snr0, tr(j).xcoeff0, tr(j).takeoff, tr(j).pol_x0, tr(j).pol_y0, tr(j).Pphase);
                fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s %s\n',tr(j).filename, tr(j).tt, tr(j).tshift, tr(j).tt+tr(j).tshift, tr(j).polarity,tr(j).stnm,tr(j).netwk, tr(j).rayp, tr(j).headers.stla, tr(j).headers.stlo, tr(j).headers.stel, tr(j).headers.evla, tr(j).headers.evlo, tr(j).headers.evdp, tr(j).dist, tr(j).az, tr(j).baz, tr(j).snr0, tr(j).xcoeff0, tr(j).takeoff, tr(j).pol_x0, tr(j).pol_y0, tr(j).Pphase, tr(j).pq);
            end
        end
        fclose(fid2);
        fprintf('Save Event: %s\n initial motion of P-wave saved to file %s\n',para.events{para.ievent},para.phasefile);
        
        fid = fopen(fullfile(para.events{para.ievent},para.paraoutfile),'w');
        fprintf(fid,'#Parameters used for processing\n');
        fprintf(fid,'#filter\n');
        fprintf(fid,'filter_type = %s\n',para.filter_type);
        fprintf(fid,'fl = %f\n',para.fl);
        fprintf(fid,'fh = %f\n',para.fh);
        fprintf(fid,'order = %d\n',para.order);
        fprintf(fid,'#velocity model\n%s\n',para.fullvmod);
        fclose(fid);
        fprintf('Done!\n')
        uicontrol(handle.h_hot);
        
    end

    function Pick_callback_savefig (h, dummy)
        
        uicontrol(handle.h_hot);  
        if ~isfield(para,'ievent')
            return;
        end
        fprintf('Output figure...\n');

        
        fig_type = para.save_fig_list{get(handle.save_fig,'Value')};

        set(handle.f1,'PaperPositionMode','auto');
        ptmp = get(handle.f1,'PaperPosition');
        set(handle.f1,'Papersize',[ ptmp(3) ptmp(4)]);
        
        [a,b,c] = fileparts(para.events{para.ievent});
        if isempty(b)
            [a,b,c] = fileparts(a);
        end
        eventname_tmp = [b,c];
        
        figname_base  = ['waveform_',eventname_tmp,'_',para.phase,'_'];
        figname_base2 = ['FMS_',     eventname_tmp,'_',para.phase,'_'];
        figname_base3 = ['PBT_',     eventname_tmp,'_',para.phase,'_'];
        tmp = dir(fullfile(para.events{para.ievent},[figname_base,'*.',fig_type]));
        if isempty(tmp)
            nnum = 1;
        else
            fignames = sort({tmp.name});
            figend   = fignames{end};
            nnum     = str2num(figend(length(figname_base)+1:end-4)) + 1;
            if isempty(nnum)
                nnum = 1;
            end
        end

        fprintf('Saving figure to\n %s\n',fullfile(para.events{para.ievent}));
        save_fig_pixel = ['-r' num2str(para.save_fig_pixel,'%d')];
        % para.export_graphics = 0;
        if para.export_graphics
%             fprintf('Here\n')
        %%% call exportgraphics (Require Matlab version to be greater than or equal to Matlab2020a) 
            if strcmp(fig_type,'pdf')
                print(handle.f1,save_fig_pixel,'-fillpage','-dpdf',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.pdf']));
                exportgraphics(handle.pfm,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.pdf']),'BackgroundColor','none','ContentType','vector');
                exportgraphics(handle.pbt,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.pdf']),'BackgroundColor','none','ContentType','vector');
    
            elseif strcmp(fig_type,'jpg')
                print(handle.f1,save_fig_pixel,'-djpeg',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.jpg']));
                exportgraphics(handle.pfm,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.jpg']),'Resolution',para.save_fig_pixel);
                exportgraphics(handle.pbt,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.jpg']),'Resolution',para.save_fig_pixel);
                
            elseif strcmp(fig_type,'png')
                print(handle.f1,save_fig_pixel,'-dpng',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.png']));
                exportgraphics(handle.pfm,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.png']),'Resolution',para.save_fig_pixel);
                exportgraphics(handle.pbt,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.png']),'Resolution',para.save_fig_pixel);
            else
                warning('The image output format is incorrect!')
                return
            end
        else
            if strcmp(fig_type,'pdf')
                print(handle.f1,save_fig_pixel,'-fillpage','-dpdf',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.pdf']));
    
                newfig = figure('visible','off');copyobj(handle.pfm,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-fillpage','-dpdf',fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.pdf']));
                close(newfig);
    
                newfig = figure('visible','off');copyobj(handle.pbt,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-fillpage','-dpdf',fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.pdf']));
                close(newfig)
    
            elseif strcmp(fig_type,'jpg')
                print(handle.f1,save_fig_pixel,'-djpeg',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.jpg']));
    
                newfig = figure('visible','off');copyobj(handle.pfm,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-djpeg',fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.jpg']));
                close(newfig);
    
                newfig = figure('visible','off');copyobj(handle.pbt,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-djpeg',fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.jpg']));
                close(newfig)
            elseif strcmp(fig_type,'png')
                print(handle.f1,save_fig_pixel,'-dpng',fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.png']));
    
                newfig = figure('visible','off');copyobj(handle.pfm,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-dpng',fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.png']));
                close(newfig);
    
                newfig = figure('visible','off');copyobj(handle.pbt,newfig);wh = get(newfig,'position');set(newfig,'position',[wh(1),wh(2),min(wh(3:4)),min(wh(3:4))]);
                newgca = findobj(newfig,'type','axes');set(newgca, 'position', [0.01,0.01,0.98,0.98]);
                print(newfig,save_fig_pixel,'-dpng',fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.png']));
                close(newfig)
            else
                warning('The image output format is incorrect!')
                return
            end
        end
        %%%  call export_fig function(requires export_fig software package and installation of gs)
%         if strcmp(fig_type,'pdf')
%             export_fig(handle.f1,'-pdf',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.pdf']));
%             export_fig(handle.pfm,'-pdf',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.pdf']));
%             export_fig(handle.pbt,'-pdf',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.pdf']));
%         elseif strcmp(fig_type,'jpg')
%             export_fig(handle.f1,'-jpg',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.jpg']));
%             export_fig(handle.pfm,'-jpg',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.jpg']));
%             export_fig(handle.pbt,'-jpg',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.jpg']));
%         elseif strcmp(fig_type,'png')
%             export_fig(handle.f1,'-png',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base,num2str(nnum,'%02d'),'.png']));
%             export_fig(handle.pfm,'-png',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base2,num2str(nnum,'%02d'),'.png']));
%             export_fig(handle.pbt,'-png',save_fig_pixel,fullfile(para.events{para.ievent},[figname_base3,num2str(nnum,'%02d'),'.png']));
%         else
%             warning('The image output format is incorrect!')
%             return
%         end
        fprintf('Done!\n')
        uicontrol(handle.h_hot); 
    end

    function Pick_callback_copyphasefile (h,dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        apptext        = get(handle.h_copyphasefile,'String');
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j  = j2 - index_selected + 1;
        
        listname_new  = [para.listname,apptext];
        phasefile_new = [para.listname,apptext,'_',para.phase,'.txt'];
        
        fprintf('Generate new listname: %s\n',listname_new);
        fprintf('Generate new phasefile: %s\n',phasefile_new);
        
        if length(j) < 1 % copy the entire phasefile
            copyfile(fullfile(para.events{para.ievent},para.listname),fullfile(para.events{para.ievent},listname_new));
            if exist(fullfile(para.events{para.ievent},para.phasefile),'file')
                copyfile(fullfile(para.events{para.ievent},para.phasefile),fullfile(para.events{para.ievent},phasefile_new));
            end
            return;
        end
        
        fid1 = fopen(fullfile(para.events{para.ievent},listname_new),'w');
        fid2 = fopen(fullfile(para.events{para.ievent},phasefile_new),'w');
        %         fprintf(fid1,'#filename\n');
%         fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz\n');
%         fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz snr0 xcoeff0\n');
        fprintf(fid2,'#filename theo_tt tshift obs_tt polarity stnm netwk rayp stla stlo stel evla evlo evdp dist az baz take-off_angle pol_x0 pol_y0 snr0 xcoeff0 first_arrival_P-phase\n');
        for kk = 1:length(j)
            if tr(j(kk)).visible == 1
                fprintf(fid1,'%s\n',tr(j(kk)).filename);
%                 fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f\n',tr(j(kk)).filename, tr(j(kk)).tt, tr(j(kk)).tshift, tr(j(kk)).tt+tr(j(kk)).tshift, tr(j(kk)).polarity,tr(j(kk)).stnm,tr(j(kk)).netwk, tr(j(kk)).rayp, tr(j(kk)).headers.stla, tr(j(kk)).headers.stlo, tr(j(kk)).headers.stel, tr(j(kk)).headers.evla, tr(j(kk)).headers.evlo, tr(j(kk)).headers.evdp, tr(j(kk)).dist, tr(j(kk)).az, tr(j(kk)).baz);
%                 fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f %f %f\n',tr(j(kk)).filename, tr(j(kk)).tt, tr(j(kk)).tshift, tr(j(kk)).tt+tr(j(kk)).tshift, tr(j(kk)).polarity,tr(j(kk)).stnm,tr(j(kk)).netwk, tr(j(kk)).rayp, tr(j(kk)).headers.stla, tr(j(kk)).headers.stlo, tr(j(kk)).headers.stel, tr(j(kk)).headers.evla, tr(j(kk)).headers.evlo, tr(j(kk)).headers.evdp, tr(j(kk)).dist, tr(j(kk)).az, tr(j(kk)).baz, tr(j(kk)).snr0, tr(j(kk)).xcoeff0);
                fprintf(fid2,'%s %f %f %f %d %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %s\n',tr(j).filename, tr(j).tt, tr(j).tshift, tr(j).tt+tr(j).tshift, tr(j).polarity,tr(j).stnm,tr(j).netwk, tr(j).rayp, tr(j).headers.stla, tr(j).headers.stlo, tr(j).headers.stel, tr(j).headers.evla, tr(j).headers.evlo, tr(j).headers.evdp, tr(j).dist, tr(j).az, tr(j).baz, tr(j).takeoff, tr(j).pol_x0, tr(j).pol_y0, tr(j).snr0, tr(j).xcoeff0, tr(j).Pphase);
            end
        end
        fclose(fid1);
        fclose(fid2);
    end


%% Events & frames functions
    function Pick_callback_nextpage (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        para.iframe = para.iframe + 1;
        if para.iframe < 1 ,
            para.iframe = 1;
        end
        if para.iframe > para.nframes,
            para.iframe = para.nframes;
        end
        set(handle.h_listbox,'Value',[]);
        Pick_callback_replot (h, dummy);

        pfm_callback_select_one_to_trace_and_listbox(h, dummy);
        pfm_callback_change_page_plot_select_one(h,dummy);
        
    end

    function Pick_callback_lastpage (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        para.iframe = para.nframes;
        set(handle.h_listbox,'Value',[]);
        Pick_callback_replot (h, dummy);
        
        pfm_callback_select_one_to_trace_and_listbox(h,dummy);
        pfm_callback_change_page_plot_select_one(h,dummy);
    end

    function Pick_callback_firstpage (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        para.iframe = 1;
        set(handle.h_listbox,'Value',[]);
        Pick_callback_replot (h, dummy);

        pfm_callback_select_one_to_trace_and_listbox(h,dummy);
        pfm_callback_change_page_plot_select_one(h,dummy);
    end

    function Pick_callback_prepage (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        para.iframe = para.iframe - 1;
        if para.iframe < 1 ,
            para.iframe = 1;
        end
        if para.iframe > para.nframes,
            para.iframe = para.nframes;
        end
        set(handle.h_listbox,'Value',[]);
        Pick_callback_replot (h, dummy);

        pfm_callback_select_one_to_trace_and_listbox(h,dummy);
        pfm_callback_change_page_plot_select_one(h,dummy);
    end

    function Pick_callback_preevent (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'nevent')
            return;
        end
        if para.ievent ~= 1
            [ind, flag_file] = find_event_list_phase(para.ievent-1, para.events, para.listname, para.phasefile,'backward');
        else
            [ind, flag_file] = find_event_list_phase(para.ievent, para.events, para.listname, para.phasefile,'backward');
        end
        
        if isempty(ind)
            %             fprintf('No previous event found! Go to the first event\n');
            para.ievent = 1;
            Pick_callback_firstevent (h, dummy)
        else
            para.ievent = ind;
            Pick_callback_iniplot (h, dummy)
        end
    end

    function Pick_callback_nextevent (h, dummy)
               
        uicontrol(handle.h_hot); 
        if ~isfield(para,'nevent')
            return;
        end
        if para.ievent ~= para.nevent
            [ind, flag_file] = find_event_list_phase(para.ievent+1, para.events, para.listname, para.phasefile,'forward');
        else
            [ind, flag_file] = find_event_list_phase(para.ievent, para.events, para.listname, para.phasefile,'forward');
        end
        
        if isempty(ind)
            %             fprintf('No next event found! Go to the last event\n');
            para.ievent = para.nevent;
            Pick_callback_lastevent (h, dummy)
        else
            para.ievent = ind;
            Pick_callback_iniplot (h, dummy)
        end
    
    end

    function Pick_callback_lastevent (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'nevent')
            return;
        end        
        para.ievent = para.nevent;
        [ind, flag_file] = find_event_list_phase(para.ievent, para.events, para.listname, para.phasefile,'backward');
        if isempty(ind)
            %             fprintf('\nNo event found!\n');
            set(handle.hax,'Visible','off');
            return;
        else
            para.ievent = ind;
        end
        Pick_callback_iniplot (h, dummy)

    end

    function Pick_callback_firstevent (h, dummy)
        
        if ~isfield(para,'nevent')
            return;
        end
        para.ievent = 1;
        [ind, flag_file] = find_event_list_phase(para.ievent, para.events, para.listname, para.phasefile,'forward');
        if isempty(ind)
            %             fprintf('\nNo event found!\n');
            set(handle.hax,'Visible','off');
            return;
        else
            para.ievent = ind;
        end
        Pick_callback_iniplot (h, dummy)
    end

    function Pick_callback_ievent (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'nevent')
            set(handle.h_ievent,'String','0');
            return;
        end
        para.ievent = floor(str2num(get(handle.h_ievent,'String')));
        Pick_callback_iniplot (h, dummy);
    end

    function Pick_callback_iframe (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            set(handle.h_iframe,'String','0');
            return;
        end
        para.iframe = floor(str2num(get(handle.h_iframe,'String')));
        Pick_callback_replot (h, dummy);

        pfm_callback_select_one_to_trace_and_listbox(h,dummy);
        pfm_callback_change_page_plot_select_one(h,dummy)
    end

    function Pick_callback_delframe (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        list_entries = get(handle.h_listbox,'String');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j = j1:j2;
        for kk = 1: length(j)
            set( handle.seis{j(kk)} , 'visible','off');
            tr(j(kk)).visible = 0;
            list_entries{kk}=[];
        end
        
        set(handle.h_listbox, 'String', list_entries);
        para.iframe = para.iframe + 1;  %% plot next frame
        if para.iframe > para.nframes,
            para.iframe = para.nframes;
        end
        Pick_callback_replot (h, dummy); %% update figure

        pfm_callback_update_pfm_2(h,dummy)
        
    end


%% Listbox and others functions
    function Pick_callback_listbox (h, dummy)
               
        if ~isfield(para,'iframe')
            return;
        end
        
        %         list_entries = get(h_listbox,'String');
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        %         j = j1 -1 + index_selected;
        j = j2 - index_selected + 1;
        for k = j1:j2
            if length(handle.seis{k}) == 1
                set( handle.seis{k} , 'color',para.color_show,'linewidth',para.linewidth_show);
            else
                set( handle.seis{k}(1) , 'Facecolor',para.color_wig_up,'edgecolor','none','linewidth',para.linewidth_show);
                set( handle.seis{k}(2) , 'Facecolor',para.color_wig_dn,'edgecolor','none','linewidth',para.linewidth_show);
            end
        end
        for k = 1:length(j)
            if length(handle.seis{j(k)}) == 1
                set( handle.seis{j(k)} , 'color',para.color_selected,'linewidth',para.linewidth_selected);
            else
                set( handle.seis{j(k)}(1) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
                set( handle.seis{j(k)}(2) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
            end
        end
        
        if get(handle.pfm_auto_plot_pol,'Value')
            pfm_callback_listbox_select(h, dummy);
        end
    end

    function Pick_callback_listbox_no_pfm (h, dummy)
               
        if ~isfield(para,'iframe')
            return;
        end
        
        %         list_entries = get(h_listbox,'String');
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        %         j = j1 -1 + index_selected;
        j = j2 - index_selected + 1;
        for k = j1:j2
            if length(handle.seis{k}) == 1
                set( handle.seis{k} , 'color',para.color_show,'linewidth',para.linewidth_show);
            else
                set( handle.seis{k}(1) , 'Facecolor',para.color_wig_up,'edgecolor','none','linewidth',para.linewidth_show);
                set( handle.seis{k}(2) , 'Facecolor',para.color_wig_dn,'edgecolor','none','linewidth',para.linewidth_show);
            end
        end
        for k = 1:length(j)
            if length(handle.seis{j(k)}) == 1
                set( handle.seis{j(k)} , 'color',para.color_selected,'linewidth',para.linewidth_selected);
            else
                set( handle.seis{j(k)}(1) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
                set( handle.seis{j(k)}(2) , 'edgecolor',para.color_selected,'linewidth',para.linewidth_selected);
            end
        end
        
    end

    function Pick_short_cut_listbox ( src, evnt)
                
        if ~isfield(para,'iframe') || ~isprop(evnt,'Key') %~isfield(evnt,'Key') 
            return;
        end
        k = evnt.Key;

        list_entries = get(handle.h_listbox,'String');
        index_selected = get(handle.h_listbox,'Value');

        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j = j2 - index_selected + 1;
        if strcmp (k, 'backspace') || strcmp(k,'delete')
            for kk = 1: length(j)
                set( handle.seis{j(kk)} , 'visible','off');
                tr(j(kk)).visible = 0;
                fprintf('Delete station %s\n',[tr(j(kk)).netwk,'.',tr(j(kk)).stnm]);
                list_entries{index_selected(kk)}=[];
            end
            set(handle.h_listbox, 'String', list_entries);
            set(handle.h_listbox, 'Value',index_selected);
            %     return;
        elseif strcmp (k, 'f')
            Pick_callback_flip(src, evnt)
        elseif strcmp (k, 's')
            Pick_callback_showtrace(src, evnt)
        elseif strcmp (k, 'd')
            Pick_callback_deltrace(src, evnt)
        elseif strcmp (k, 'escape')
            uicontrol(handle.h_hot);
            set(handle.h_listbox,'Value',[]);
        % elseif strcmp (k, 'alt') %|| (~isempty(evnt.Modifier) && ( strcmpi(k,'0') && strcmpi(evnt.Modifier{:},'command')))
        elseif strcmp (k, 'alt') || (~isempty(evnt.Modifier) && ( strcmpi(k,'0') && ismember('option',evnt.Modifier)))
            uicontrol(handle.h_hot);
        else
            % if ~isempty(evnt.Modifier) && (strcmp(evnt.Modifier{:},'control') || strcmp(evnt.Modifier{:},'command')) && strcmp (k, 'leftarrow')
            if ~isempty(evnt.Modifier) && (ismember('control',evnt.Modifier) || ismember('command',evnt.Modifier)) && strcmp (k, 'leftarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift + tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
            % elseif ~isempty(evnt.Modifier) && (strcmp(evnt.Modifier{:},'control') || strcmp(evnt.Modifier{:},'command')) && strcmp (k, 'rightarrow')
            elseif ~isempty(evnt.Modifier) && (ismember('control',evnt.Modifier) || ismember('command',evnt.Modifier)) && strcmp (k, 'rightarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift - tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
            elseif ~isempty(evnt.Modifier) && length(evnt.Modifier)==1 && strcmp(evnt.Modifier{:},'shift') && strcmp (k, 'leftarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift + 100*tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
            elseif ~isempty(evnt.Modifier) && length(evnt.Modifier)==1 && strcmp(evnt.Modifier{:},'shift') && strcmp (k, 'rightarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift - 100*tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
                
            elseif isempty(evnt.Modifier) && strcmp (k, 'leftarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift + 10*tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
            elseif isempty(evnt.Modifier) && strcmp (k, 'rightarrow')
                for kk = 1:length(j)
                    tr(j(kk)).dtshift = tr(j(kk)).dtshift - 10*tr(j(kk)).delta;
                    tr(j(kk)).tshift  = tr(j(kk)).tshift + tr(j(kk)).dtshift;
                end
            else
                uicontrol(handle.h_listbox)
                return;
            end
            Pick_callback_replot(src, evnt);
            uicontrol(handle.h_listbox);
        end
        Pick_callback_listbox_no_pfm (src, evnt)
            % uicontrol(handle.h_listbox)
    end

    function Pick_callback_deltrace (h, dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        list_entries = get(handle.h_listbox,'String');
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        j = j2 - index_selected + 1;
        for kk = 1: length(j)
            set( handle.seis{j(kk)} , 'visible','off');
            tr(j(kk)).visible = 0;
            fprintf('Delete station %s\n',[tr(j(kk)).netwk,'.',tr(j(kk)).stnm]);
            list_entries{index_selected(kk)}=[];
        end

        
        set(handle.h_listbox, 'String', list_entries);

        pfm_callback_update_pfm_2(h,dummy)

        uicontrol(handle.h_listbox);
    end

    function Pick_callback_showtrace (h, dummy)
        
        % uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        list_entries = get(handle.h_listbox,'String');
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        %         j = j1 -1 + index_selected;
        j = j2 - index_selected + 1;
        indtmp = get(handle.h_listbox_list,'Value');
        for kk = 1: length(j)
            set( handle.seis{j(kk)} , 'visible','on');%,'linewidth',2);
            tr(j(kk)).visible = 1;
            
            if strcmpi(para.listbox_list{indtmp},'nstnm')
                list_entries{index_selected(kk)} = [tr(j(kk)).netwk,'.',tr(j(kk)).stnm];
            elseif strcmpi(para.listbox_list{indtmp},'stnm')
                list_entries{index_selected(kk)} = tr(j(kk)).stnm;
            elseif strcmpi(para.listbox_list{indtmp},'fname')
                list_entries{index_selected(kk)} = tr(j(kk)).filename;
            end
        end
        
        set(handle.h_listbox, 'String', list_entries);

        pfm_callback_update_pfm_2(h,dummy)
        uicontrol(handle.h_listbox)
        set(handle.h_listbox,'Value', index_selected);
    end

    function Pick_callback_flip (h,dummy)
        
        uicontrol(handle.h_hot);
        if ~isfield(para,'iframe')
            return;
        end
        index_selected = get(handle.h_listbox,'Value');
        j1 = (para.iframe -1) * para.n_per_frame +1;
        j2 = j1 + para.n_per_frame -1;
        j2 = min( j2, para.nl);
        
        %         j = j1 -1 + index_selected;
        j = j2 - index_selected + 1;

        for kk = 1:length(j)
            tr(j(kk)).polarity = -1*tr(j(kk)).polarity;
        end

        Pick_callback_replot(h,dummy)
        set(handle.h_listbox, 'Value',index_selected);

        pfm_callback_update_pfm_2(h,dummy)

        uicontrol(handle.h_listbox)
    end

%% Hot keys
    function Pick_short_cut(src, evnt)
        
        uicontrol(handle.h_hot);  

        if strcmpi(evnt.Key,'i')
            Pick_callback_iniplot(src,evnt)
        elseif strcmpi(evnt.Key,'b') %|| strcmpi(evnt.Key,'backspace')
            Pick_callback_preevent(src,evnt)
        elseif strcmpi(evnt.Key,'n') %|| strcmpi(evnt.Key,'space')
            Pick_callback_nextevent(src,evnt)
        elseif strcmpi(evnt.Key,'comma')
            Pick_callback_prepage(src,evnt)
        elseif strcmpi(evnt.Key,'period')
            Pick_callback_nextpage(src,evnt)
        elseif strcmpi(evnt.Key,'c')
            pfm_callback_CHNYTX_cal_plot(src,evnt)
        elseif strcmpi(evnt.Key,'h')
            pfm_callback_HASH_cal_list(src,evnt);
        elseif strcmpi(evnt.Key,'t')
            pfm_callback_cal_TWO_method(src,evnt)
        elseif strcmpi(evnt.Key,'o')
            pfm_callback_compare_output(src,evnt)
        elseif strcmpi(evnt.Key,'s')
            Pick_callback_save(src,evnt)
        elseif strcmpi(evnt.Key,'r')
            Pick_callback_reset_event(src,evnt)
        elseif strcmpi(evnt.Key,'equal')
            Pick_callback_ampup(src,evnt)
        elseif strcmpi(evnt.Key,'hyphen')
            Pick_callback_ampdown(src,evnt)
        elseif strcmpi(evnt.Key,'leftbracket')
            Pick_callback_timeup(src,evnt)
        elseif strcmpi(evnt.Key,'rightbracket')
            Pick_callback_timedown(src,evnt)
        elseif strcmpi(evnt.Key,'f')
            Pick_callback_polarity(src,evnt)
        elseif strcmpi(evnt.Key,'e')            
            if get(handle.even_button,'Value') == 1
                set(handle.even_button,'Value',0);
            else
                set(handle.even_button,'Value',1);
            end
            Pick_callback_even(src,evnt)
        elseif strcmpi(evnt.Key,'g')
            Pick_callback_gpick(src,evnt)
        % elseif strcmpi(evnt.Key,'alt') || (~isempty(evnt.Modifier) && ( strcmpi(evnt.Key,'0') && strcmpi(evnt.Modifier{:},'command')))
        %     uicontrol(handle.h_listbox)
        % elseif ~isempty(evnt.Modifier) && strcmp(evnt.Modifier{:},'control') && strcmpi(evnt.Key,'d')
        %     Pick_callback_del_event(src,evnt)
        
        elseif strcmpi(evnt.Key,'alt') || (~isempty(evnt.Modifier) && ( strcmpi(evnt.Key,'0') && ismember('option',evnt.Modifier)))
            uicontrol(handle.h_listbox)
        elseif ~isempty(evnt.Modifier) && ismember('control',evnt.Modifier) && strcmpi(evnt.Key,'d')
            Pick_callback_del_event(src,evnt)
        else
        end
    end
end
%                       CrazyBeachball END
% ======================================================================= %