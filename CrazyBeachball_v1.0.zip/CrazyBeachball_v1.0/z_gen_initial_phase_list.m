function z_gen_initial_phase_list()
% ======================================================================= %
% The script is used to generate an initial phase list, where the first 
% motion of all stations is upward, for CrazyBeachball.
% 
% You can replace the polarities in the output file with the results 
% obtained from machine learning methods and use them in CrazyBeachball 
% to automatically invert the source mechanism solution and perform 
% quality control.
%
%                                              Xianwei Zeng, 2024/06/01
% ======================================================================= %

%%% event list for Crazybeachball
evlist_file = './evs_info/fms_demo_evlist.txt'; 
%%% velocity model, the format is same as the input of Crazybeachball
vmodel = './Utilities/ray1d/vmodels/ak135.txt'; %%
%%% reference phase
phase = 'PF';
%%% filename list
channel_file = 'list_z';

z_gen_initial_phase_list_fun(evlist_file,vmodel,phase,channel_file)

end
