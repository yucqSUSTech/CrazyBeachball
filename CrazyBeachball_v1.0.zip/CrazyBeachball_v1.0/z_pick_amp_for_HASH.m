function z_pick_amp_for_HASH()
% ======================================================================= %
% The P-wave amplitude is measured on the Cartesian sum of the radial and 
% vertical components within a time window (p_win) after arrival time.
% The S-wave amplitede is the maximum amplitude on all three channels 
% within a time window after the apparent S arrival.
%
% Input:
%       1. Phase file: hypoDD.pha 
%       2. Events list: fm_demo_evlist.txt
%       3. Seismic data: events set with sac format(The reference time 
%          may not necessarily be the time of earthquake occurrence)
%       
% Output:
%       amplitude list: HASH.amp ( save in each event dir )
%
%                                              Xianwei Zeng  03/16/2024
% ======================================================================= %
sv_ampfile_name = 'HASH.amp';

ev_list_file = './evs_info/fms_demo_evlist.txt';  % events list
ev_pha_file  = './evs_info/hypoDD.pha';           % phase list

Z_channel_char = '.HHZ';  % characteristic characters, using wildcard
R_channel_char = replace(Z_channel_char,'Z','R');
T_channel_char = replace(Z_channel_char,'Z','T');

ifvel = 1; % type of seismograms
%%% 1 -> velocity seismograms
%%% 0 -> displacement seismograms

ev_dir_name = 1; 
%%% 1 -> YYMMDDTmmhhssZ
% for example: 
% event line: # 2011 03 23 15 34 18.742 23.52364 99.15353 7.262 3.6 0 0 0 1
% event dir: 20110323T153418Z
%%% 2 -> evid
% event line: # 2011 03 23 15 34 18.742 23.52364 99.15353 7.262 3.6 0 0 0 1
% event dir: 1

freq_min = 1;   % filter setting
freq_max = 15;

p_win = 0.5;      % P-phase time window
s_win = 2  ;      % S-phase time window
n_win = 0.2;      % noise time window
b_win = 0.2;      % time window between P/S and noise time window

% When p_win is greater than (Ts-Tp)*P_S_ratio,
% set p_win to (Ts-Tp)*P_S_ratio.
P_S_ratio = 0.5;

path(path,genpath(pwd));

fid = fopen(ev_list_file);
C = textscan(fid,'%s','CommentStyle','#');
fclose(fid);
ev_list = C{1};

pha = {};
fid = fopen(ev_pha_file);
C = textscan(fid,'%s %f %d %s %d %d %f %f %f %f %f %s %s %s %s');
fclose(fid);

if ev_dir_name==1
    for i = 1 : length(C{1})
        if strcmp( C{1}{i},'#')
            evid = ['ev' sprintf('%d%02d%02sT%02d%02d%02dZ',...
                C{2}(i),C{3}(i),C{4}{i},C{5}(i),C{6}(i),floor(C{7}(i)))];
            pha.(evid).kztime = datetime(C{2}(i),C{3}(i),str2double(C{4}{i}),C{5}(i),C{6}(i),C{7}(i));
        else
            pha.(evid).(C{1}{i}).(C{4}{i}) = C{2}(i);
        end
    end
elseif ev_dir_name==2
    for i = 1 : length(C{1})
        if strcmp( C{1}{i},'#')
            evid = ['ev' C{15}{i}];
            pha.(evid).kztime = datetime(C{2}(i),C{3}(i),str2double(C{4}{i}),C{5}(i),C{6}(i),C{7}(i));
        else
            pha.(evid).(C{1}{i}).(C{4}{i}) = C{2}(i);
        end
    end
end

% parfor i = 1 : length(ev_list)
for i = 1 : length(ev_list)
    ev_dir = ev_list{i};
    [~,dirname] = fileparts(ev_dir);
    fprintf('Processing --- %s\n',dirname)
    evid = ['ev' dirname];
    kztime = pha.(evid).kztime;

    files = dir(fullfile(ev_dir,['*' Z_channel_char]));
    files = {files.name};
    
    if isempty(files)
        warning('Please check the special characters in the sac file name:\n%s',ev_dir);
        continue
    end

    fid0 = fopen(fullfile(ev_dir,sv_ampfile_name),'w');
    
    for j = 1 : length(files)
        filez = files{j};
        filer = replace(filez,Z_channel_char,R_channel_char);
        filet = replace(filez,Z_channel_char,T_channel_char);

        [headz,dataz] = irdsac(fullfile(ev_dir,filez));
        stnm = deblank(reshape(headz.kstnm,1,[]));
        net = deblank(reshape(headz.knetwk,1,[]));

        if ~isfield(pha.(evid),stnm) || length(fieldnames(pha.(evid).(stnm)))~=2 || max(dataz)-min(dataz)==0
            continue
        end

        if ifvel
            dataz = y_intederi(dataz,headz.delta,'int');
        end
        dataz = detrend(dataz);
        dataz = dataz.* tukeywin(length(dataz), 0.1);
        dataz = filtering(dataz,headz.delta,freq_min,freq_max);

        evtimez = datetime(headz.nzyear,1,1,headz.nzhour,headz.nzmin,headz.nzsec+headz.nzmsec/1000)+headz.nzjday-1;
        
        if ~exist(fullfile(ev_dir,filer),'file') || ~exist(fullfile(ev_dir,filet),'file')
            continue
        end

        [headr,datar] = irdsac(fullfile(ev_dir,filer));
        [headt,datat] = irdsac(fullfile(ev_dir,filet));

        if max(datar)==min(datar) || max(datat)==min(datat)
            continue
        end

        evtimer = datetime(headr.nzyear,1,1,headr.nzhour,headr.nzmin,headr.nzsec+headr.nzmsec/1000)+headr.nzjday-1;
        datar = detrend(datar);
        datar = datar.* tukeywin(length(datar), 0.1);
        datar = filtering(datar,headr.delta,freq_min,freq_max);

        evtimet = datetime(headt.nzyear,1,1,headt.nzhour,headt.nzmin,headt.nzsec+headt.nzmsec/1000)+headt.nzjday-1;
        datat = detrend(datat);
        datat = datat.* tukeywin(length(datat), 0.1);
        datat = filtering(datat,headt.delta,freq_min,freq_max);


        evdtz = seconds(kztime-evtimez);
        evdtr = seconds(kztime-evtimer);
        evdtt = seconds(kztime-evtimet);
        
        ptz = evdtz-headz.b+pha.(evid).(stnm).P;
        ptr = evdtr-headr.b+pha.(evid).(stnm).P;
        
        stz = evdtz-headz.b+pha.(evid).(stnm).S;
        str = evdtr-headr.b+pha.(evid).(stnm).S;
        stt = evdtt-headt.b+pha.(evid).(stnm).S;

        if (pha.(evid).(stnm).S-pha.(evid).(stnm).P)*P_S_ratio<p_win
            p_win_p = (pha.(evid).(stnm).S-pha.(evid).(stnm).P)*P_S_ratio;
            b_win_s = 0.1;
        else
            b_win_s = b_win;
            p_win_p = p_win;
        end

        p_amp = sqrt(((max(dataz(round(ptz/headz.delta):round((ptz+p_win_p)/headz.delta)))-...
            min(dataz(round(ptz/headz.delta):round((ptz+p_win_p)/headz.delta))))/2)^2+...
            +((max(datar(round(ptr/headr.delta):round((ptr+p_win_p)/headr.delta)))-...
            min(datar(round(ptr/headr.delta):round((ptr+p_win_p)/headr.delta))))/2)^2);

        p_amp_n = max((max(dataz(round((ptz-b_win-n_win)/headz.delta):round((ptz-b_win)/headz.delta)))-...
            min(dataz(round((ptz-b_win-n_win)/headz.delta):round((ptz-b_win)/headz.delta))))/2,...
            (max(datar(round((ptr-b_win-n_win)/headr.delta):round((ptr-b_win)/headr.delta)))-...
            min(datar(round((ptr-b_win-n_win)/headr.delta):round((ptr-b_win)/headr.delta))))/2);

        [s_amp,max_idx] = max([(max(dataz(round(stz/headz.delta):round((stz+s_win)/headz.delta)))-...
            min(dataz(round(stz/headz.delta):round((stz+s_win)/headz.delta))))/2, ...
            (max(datar(round(str/headr.delta):round((str+s_win)/headr.delta)))-...
            min(datar(round(str/headr.delta):round((str+s_win)/headr.delta))))/2,...
            (max(datat(round(stt/headt.delta):round((stt+s_win)/headt.delta)))-...
            min(datat(round(stt/headt.delta):round((stt+s_win)/headt.delta))))/2]);

        s_amps_n = [(max(dataz(round((stz-b_win_s-n_win)/headz.delta):round((stz-b_win_s)/headz.delta)))-...
            min(dataz(round((stz-b_win_s-n_win)/headz.delta):round((stz-b_win_s)/headz.delta))))/2,...
            (max(datar(round((str-b_win_s-n_win)/headr.delta):round((str-b_win_s)/headr.delta)))-...
            min(datar(round((str-b_win_s-n_win)/headr.delta):round((str-b_win_s)/headr.delta))))/2,...
            (max(datat(round((stt-b_win_s-n_win)/headt.delta):round((stt-b_win_s)/headt.delta)))-...
            min(datat(round((stt-b_win_s-n_win)/headt.delta):round((stt-b_win_s)/headt.delta))))/2];
        s_amp_n = s_amps_n(max_idx);

        ratio = 90000/max([p_amp,p_amp_n,s_amp_n,s_amp]);
        fprintf(fid0,'%s %10.3f %10.3f %10.3f %10.3f\n',[net '.' stnm],p_amp_n*ratio,p_amp*ratio,s_amp_n*ratio,s_amp*ratio);
        % fprintf(fid0,'%s %10.3f %10.3f %10.3f %10.3f\n',[net '.' stnm],p_amp_n*ratio,p_amp*ratio,p_amp_n*ratio,s_amp*ratio);
        % ratio = 1;
        % fprintf(fid0,'%s %.10f %.10f %.10f %.10f\n',[net '.' stnm],p_amp_n*ratio,p_amp*ratio,s_amp_n*ratio,s_amp*ratio);
    end
    fclose(fid0);
end
fprintf('Done!\n');
end