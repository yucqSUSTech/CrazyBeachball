CH：
CrazyBeachball中提供的HASH_v1.2对原始HASH做了略微修改，
主要是增加了路径的字符长度和修改了Makefile。

注意：
如果在编译的过程中出现了‘uncert_subs.f’中的‘rota’变量报错的情况，
有两个解决方法:
    一是将Makefile中第41行注释掉并去掉第42行注释后重新编译。
    二是可以考虑将‘uncert_subs_o.f’替换为‘uncert_subs.f’后重新编译。
    “注意uncert_subs_o.f为原始的HASH代码，uncert_subs.f是为了解决这个bug而修改后的版本，
    如果以上方法都会出现编译报错的情况，请联系作者。”

原版HASH可以从以下链接获取：
    https://www.usgs.gov/node/279393


EN:
The version of HASH (v1.2) provided in CrazyBeachball includes 
slight modifications to the original HASH, primarily increasing 
the character length allowed for file paths and updating the Makefile.

Note: 
If an error occurs related to the 'rota' variable in 'uncert_subs.f' 
during compilation, there are two possible solutions:
    1. Comment out line 41 in the Makefile and uncomment line 42, then recompile.
    2. Replacing 'uncert_subs.f' with 'uncert_subs_o.f' and recompile.
    “Note that uncert_subs_o.f is the original HASH code, while uncert_subs.f is 
    the modified version to fix this bug. If compilation errors still occur with 
    the above methods, please contact the author.”

The original HASH can be obtained from the following link:
    https://www.usgs.gov/node/279393