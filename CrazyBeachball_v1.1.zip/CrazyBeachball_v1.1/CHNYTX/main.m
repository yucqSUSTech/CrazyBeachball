%% main control

% process all dat files in data dirpath.
% move finished dat files into done dirpath.

%set data path, done path
% dirpath = '../data';
dirpath = 'F:\yunnan2\third_mechanism\single';
prepath = fileparts(dirpath);
filepath = [dirpath,'/*.dat'];
% donepath = '../done';
% donepath = 'F:\yunnan2\earthquake_greater_2\second_part\MPFMS_done';
files = dir(filepath);
nevent = size(files,1);

%% readin parameters
fprintf('Reading in parameters!\n');
[NN_threshold,nzenith,nrotation,w2,dangle,discrepancy_range,...
    min_number,max_number,max_cluster_num,RA_range,jack_knife,.....
    DIS_good,DIS_bad,RMS_good] = para;


%% grid point test main program
for i=1:nevent
    fprintf('\n%s\n',files(i).name);
    %deal with one event at a time
    Grid_point_test([dirpath,'/',files(i).name],...
        NN_threshold,nzenith,nrotation,w2,dangle,...
        discrepancy_range,min_number,max_number,...
        max_cluster_num,RA_range,jack_knife,DIS_good,...
        DIS_bad,RMS_good);
    % move finished dat files into done dirpath
%     movefile([dirpath,'/',files(i).name],fullfile(prepath,'done'));
%     strr = split(files(i).name,'.');
% %     if ~exist(fullfile(out_path,strr{1}))
% %         mkdir(fullfile(out_path,strr{1}));
% %     end
%     movefile(fullfile(dirpath,[strr{1} '*.jpg']),fullfile(prepath,'jpg'));
%     movefile(fullfile(dirpath,[strr{1} '*']),fullfile(prepath,'output'));
%     close all
end

