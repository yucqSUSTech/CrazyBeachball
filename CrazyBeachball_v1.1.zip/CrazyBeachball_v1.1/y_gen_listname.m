function y_gen_listname

% generate a list of events & lists of sac files in each event directory.  
% evlist: a list of events
% listz/liste/listn: lists of z/e/n-component sac files

% Chunquan Yu, 2020/08/01
% yucq@sustech.edu.cn


%% event list
% parent event directory: better to use absolute directory
parentdir = pwd;

% data demo: fm
evdir = fullfile(parentdir,'data_demo/fms_data'); % event directory
evid = '20*'; % event id for searching events, using wildcard
evlist = fullfile(parentdir,'evs_info','fms_demo_evlist.txt');

%% sacfile list
% id for searching z/r/t-component sac files, using wildcard
saczid = '*.HHZ';
sacrid = '*.HHR';
sactid = '*.HHT';

% output sac file listname
listz = 'list_z';
listr = 'list_r';
listt = 'list_t';


%% Main
events = dir(fullfile(evdir,evid));
nevent = length(events);
fid = fopen(evlist,'w');
for i = 1:nevent
    if strcmp(events(i).name,'.') || strcmp(events(i).name,'..')
        continue;
    end
    fprintf(fid,'%s\n',fullfile(evdir,events(i).name));
        
    if exist('saczid','var')
        sacz = dir(fullfile(evdir,events(i).name,saczid));
        nsacz = length(sacz);
        if nsacz >= 1
            fidz = fopen(fullfile(evdir,events(i).name,listz),'w');
            for j = 1:nsacz
                fprintf(fidz,'%s\n',sacz(j).name);
            end
            fclose(fidz);
        end
    end
    
    if exist('sacrid','var')
        sacr = dir(fullfile(evdir,events(i).name,sacrid));
        nsacr = length(sacr);
        if nsacr >= 1
            fidr = fopen(fullfile(evdir,events(i).name,listr),'w');
            for j = 1:nsacr
                fprintf(fidr,'%s\n',sacr(j).name);
            end
            fclose(fidr);
        end
    end
    
     if exist('sactid','var')
        sact = dir(fullfile(evdir,events(i).name,sactid));
        nsact = length(sact);
        if nsact >= 1
            fidt = fopen(fullfile(evdir,events(i).name,listt),'w');
            for j = 1:nsact
                fprintf(fidt,'%s\n',sact(j).name);
            end
            fclose(fidt);
        end
     end
    
end

fclose(fid);
fprintf('Event list generated!\n');


end
