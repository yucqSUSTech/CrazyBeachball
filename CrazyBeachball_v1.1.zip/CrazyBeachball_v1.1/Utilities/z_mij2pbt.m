function [  p ,b ,t ] = z_mij2pbt(varargin)%( mij ,mode)
% ======================================================================= %
% For all coordinate system:
%                              x: North
%                              y: East
%                              z: Vertical
%  Required subfunctions:
%                          xyz2AzIh.m
%  mode:
%  if mode is equal to 1, the output is spherical coordinates (AZ and IH)
%  if mode is equal to 2, the output is Cartesian coordinates (X, Y ,Z)
%  if mode is equal to 3, the output is spherical coordinates (AZ and PL)
%
%  mij:
%      | m11 m12 m13 |
%      | m12 m22 m23 |  or | m11 m12 m13 m22 m23 m33|
%      | m13 m23 m33 |

% PAZ: 
%      azimuth of P axis ; 
% PIh: 
%      angle between P axis and vertival axis;
% TAZ: 
%      azimuth of T axis ; 
% TIh: 
%      angle between T axis and vertival axis;
% BAZ: 
%      azimuth of B axis ; 
% BIh: 
%      angle between B axis and vertival axis;
% ======================================================================= %
%  example :
%              mij2pbt(mij)  or  mij2pbt(mij,mode)
%          or  mij2pbt([m11 m12 m13 m22 m23 m33])
%          or  mij2pbt([m11 m12 m13 m22 m23 m33],mode)
%          or  mij2pbt(m11, m12, m13, m22, m23, m33)
%          or  mij2pbt(m11, m12, m13, m22, m23, m33,mode)
%
%                                                       ZengXW 2022/9/5
% ======================================================================= %

if nargin == 1
    mij = varargin{1};
    if size(mij,1)==3 && size(mij,2)==3
        S11 = mij(1,1);    S12 = mij(1,2);    S13 = mij(1,3);    S22 = mij(2,2);    S23 = mij(2,3);    S33 = mij(3,3);
        n = 1;
    elseif size(mij,2)==6
        n = size(mij,1);
        S11 = mij(:,1);    S12 = mij(:,2);    S13 = mij(:,3);    S22 = mij(:,4);    S23 = mij(:,5);    S33 = mij(:,6);
    else
        error('Input parameter error!')
    end
    mode = 1;
elseif nargin==2
    mij = varargin{1};
    if size(mij,1)==3 && size(mij,2)==3
        S11 = mij(1,1);    S12 = mij(1,2);    S13 = mij(1,3);    S22 = mij(2,2);    S23 = mij(2,3);    S33 = mij(3,3);
        n = 1;
    elseif size(mij,2)==6
        n = size(mij,1);
        S11 = mij(:,1);    S12 = mij(:,2);    S13 = mij(:,3);    S22 = mij(:,4);    S23 = mij(:,5);    S33 = mij(:,6);
    else
        error('Input parameter error!')
    end
    mode = varargin{2};
elseif nargin==6
    S11 = varargin{1};S12 = varargin{2};S13 = varargin{3};
    S22 = varargin{4};S23 = varargin{5};S33 = varargin{6};
    n = size(S11,1);
    mode = 1;
elseif nargin==7
    S11 = varargin{1};S12 = varargin{2};S13 = varargin{3};
    S22 = varargin{4};S23 = varargin{5};S33 = varargin{6};
    n = size(S11,1);
    mode = varargin{7};
else
    error('Input parameter error!')
end

    
%prelocation
PAZ=zeros(n,1);PIh=zeros(n,1);
BAZ=zeros(n,1);BIh=zeros(n,1);
TAZ=zeros(n,1);TIh=zeros(n,1);

for i = 1:n    
%     S11 = mij(i,1);    S12 = mij(i,2);    S13 = mij(i,3);    S22 = mij(i,4);    S23 = mij(i,5);    S33 = mij(i,6);
    S_matrix = [S11(i,1) S12(i,1) S13(i,1) ; S12(i,1) S22(i,1) S23(i,1) ; S13(i,1) S23(i,1) S33(i,1)];
    
    [V,~] = eig(S_matrix); 
    p = [V(1,1),V(2,1),V(3,1)];
    b = [V(1,2),V(2,2),V(3,2)];
    t = cross(p,b);
    if mode ==2
        return
    elseif mode ==1
%     fprintf('%f,%f,%f\n',t(1),t(2),t(3));
    
        [PAZ(i),PIh(i)] = xyz2AzIh(p);
        [BAZ(i),BIh(i)] = xyz2AzIh(b);
        [TAZ(i),TIh(i)] = xyz2AzIh(t);
        p = [PAZ(i),PIh(i)];
        b = [BAZ(i),BIh(i)];
        t = [TAZ(i),TIh(i)];
    else
        error('Input mode error!')
    end
end
end
