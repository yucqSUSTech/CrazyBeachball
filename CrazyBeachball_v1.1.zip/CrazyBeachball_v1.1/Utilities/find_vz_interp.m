function [vz] = find_vz_interp(dp,vp,evdp)
% ======================================================================= %
%  find velocity value at a given depth in the velocity model
%                                               Xianwei Zeng, 2023/4/1
% ======================================================================= %

    [~,idx] = min(abs(dp-evdp));
    if dp(idx)<evdp
        vz = interp1([dp(idx),dp(idx+1)],[vp(idx),vp(idx+1)],evdp,'linear');
    elseif dp(idx)>evdp
        vz = interp1([dp(idx-1),dp(idx)],[vp(idx-1),vp(idx)],evdp,'linear');
    elseif dp(idx)==evdp
        if dp(idx+1)==evdp
            vz = vp(idx+1);
        else
            vz = vp(idx);
        end
    end

%     for i = 1 : length(dp)-1
%         if evdp>=dp(i) && evdp<dp(i+1)
%             vz = interp1([dp(i),dp(i+1)],[vp(i),vp(i+1)],evdp,'linear');
%         end
%     end
end